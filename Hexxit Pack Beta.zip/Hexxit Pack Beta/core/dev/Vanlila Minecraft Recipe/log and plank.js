VanillaRecipe.addCraftingRecipe("plank_dark", {
        type: "shapeless",
        ingredients: [
            { item: "block:twDarkLog" }
        ],
        result: {
            item: "block:tw_planks_dark_wood",
            count: 4
        }
    }, true);
    //
    VanillaRecipe.addCraftingRecipe("plank_mangrove", {
        type: "shapeless",
        ingredients: [
            { item: "block:twMangroveLog" }
        ],
        result: {
            item: "block:tw_planks_mangrove",
            count: 4
        }
    }, true);
    //
    VanillaRecipe.addCraftingRecipe("plank_canopy", {
        type: "shapeless",
        ingredients: [
            { item: "block:twCanopyLog" }
        ],
        result: {
            item: "block:tw_planks_canopy",
            count: 4
        }
    }, true);
    //
    VanillaRecipe.addCraftingRecipe("plank_oak", {
        type: "shapeless",
        ingredients: [
            { item: "block:twTwilightOakLog" }
        ],
        result: {
            item: "block:tw_planks_twilight_oak",
            count: 4
        }
    }, true);
    //
    VanillaRecipe.addCraftingRecipe("plank_mine", {
        type: "shapeless",
        ingredients: [
            { item: "block:twMiningLog" }
        ],
        result: {
            item: "block:tw_planks_mine",
            count: 4
        }
    }, true);
    //
    VanillaRecipe.addCraftingRecipe("plank_sort", {
        type: "shapeless",
        ingredients: [
            { item: "block:twSortingLog" }
        ],
        result: {
            item: "block:tw_planks_sort",
            count: 4
        }
    }, true);
    //
    VanillaRecipe.addCraftingRecipe("plank_time", {
        type: "shapeless",
        ingredients: [
            { item: "block:twTimeLog" }
        ],
        result: {
            item: "block:tw_planks_time",
            count: 4
        }
    }, true);
    //
    VanillaRecipe.addCraftingRecipe("plank_trans", {
        type: "shapeless",
        ingredients: [
            { item: "block:twTransformationLog" }
        ],
        result: {
            item: "block:tw_planks_trans",
            count: 4
        }
    }, true);
    //
    //
    //
    