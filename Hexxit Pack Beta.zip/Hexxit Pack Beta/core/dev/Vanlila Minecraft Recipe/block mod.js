VanillaRecipe.addCraftingRecipe("infinity_ingot", {
        type: "shapeless",
        ingredients: [
            { item: "block:infBlock" }
        ],
        result: {
            item: "item:infinityingot",
            count: 9
        }
    }, true);