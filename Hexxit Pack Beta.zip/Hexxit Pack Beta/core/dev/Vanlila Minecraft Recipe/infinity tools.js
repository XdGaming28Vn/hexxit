VanillaRecipe.addCraftingRecipe("inf_1", {
        type: "shapeless",
        ingredients: [
            { item: "item:cosmPickaxe" }
        ],
        result: {
            item: "item:cosmhammer",
            count: 1
        }
    }, true);
    
    VanillaRecipe.addCraftingRecipe("inf_2", {
        type: "shapeless",
        ingredients: [
            { item: "item:cosmhammer" }
        ],
        result: {
            item: "item:cosmPickaxe",
            count: 1
        }
    }, true);
   
   VanillaRecipe.addCraftingRecipe("inf_3", {
        type: "shapeless",
        ingredients: [
            { item: "item:cosmPickaxe" }
        ],
        result: {
            item: "item:cosmdes",
            count: 1
        }
    }, true);
    VanillaRecipe.addCraftingRecipe("inf_4", {
        type: "shapeless",
        ingredients: [
            { item: "item:cosmdes" }
        ],
        result: {
            item: "item:cosmPickaxe",
            count: 1
        }
    }, true);
    
    VanillaRecipe.addCraftingRecipe("inf_5", {
        type: "shapeless",
        ingredients: [
            { item: "item:cosmdes" }
        ],
        result: {
            item: "item:cosmhammer",
            count: 1
        }
    }, true);
    
    VanillaRecipe.addCraftingRecipe("inf_6", {
        type: "shapeless",
        ingredients: [
            { item: "item:cosmhammer" }
        ],
        result: {
            item: "item:cosmdes",
            count: 1
        }
    }, true);
    
    