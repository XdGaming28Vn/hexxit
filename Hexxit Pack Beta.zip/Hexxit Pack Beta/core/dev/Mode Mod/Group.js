Item.addCreativeGroup("Skill Untimed", Translation.translate("Skill Untimed"), [
	ItemID.fire_skill_untimed,
	 ItemID.ice_skill_untimed,
	 ItemID.lightning_skill_untimed,
]);

Item.addCreativeGroup("Skill Legend", Translation.translate("Skill Legend"), [
	ItemID.fire_skill_legend,
	 ItemID.ice_skill_legend,
	 ItemID.lightning_skill_legend,
]);







Item.addCreativeGroup("Key Boss", Translation.translate("Key Boss"), [
	ItemID.keyNaga,
	 ItemID.keyHydra,
	 ItemID.keyLich,
	 ItemID.keyUghast,
	 ItemID.keyMinoshroom,
	ItemID.keySnowQueen,
	 
]);
//infinity 
Item.addCreativeGroup("singularity and ingot", Translation.translate("singularity"), [
	ItemID.infinityingot,
	ItemID.fieryblood,
	ItemID.livingmetal,
	ItemID.fint,
	ItemID.diamondHexical,
	ItemID.steeleaf,
	ItemID.ironwood,
	ItemID.bo1,
	ItemID.bo2,
	ItemID.bo3,
	ItemID.bo4,
	 ItemID.bo5,
	 ItemID.bo6,
	 ItemID.bo7,
	 ItemID.bo8,
	 ItemID.bo9,
	ItemID.essenceHexical,
	 
	 
	 ItemID.hexibiscusItem,
	 
	 
	 ItemID.page,
]);
//magic run

// sword
Item.addCreativeGroup("sword giant & magic", Translation.translate("sword giant & magic"), [
	 ItemID.wooden_giant_sword,
	 ItemID.stone_giant_sword,
	 ItemID.iron_giant_sword,
	 ItemID.gold_giant_sword,
	 ItemID.diamond_giant_sword,
	 ItemID.emerald_giant_sword,
	 ItemID.ender_giant_sword,
	 ItemID.livingmetal_giant_sword,
	ItemID.bone_giant_sword, 
ItemID.netherrack_giant_sword, 
ItemID.quartz_giant_sword,
 ItemID.obsidian_giant_sword,
 ItemID.netherite_giant_sword, 
	ItemID.wither_giant_sword, 
	ItemID.dragon_giant_sword, 
	 
]);



Item.addCreativeGroup("all twilight forest tools", Translation.translate("all twilight forest tools"), [
	ItemID.v1,
	ItemID.v2,
	ItemID.v3,
	ItemID.v4,
	ItemID.pick,
    ItemID.minotauraxe,
]);
Item.addCreativeGroup("infinity tools", Translation.translate("infinity tools"), [
	ItemID.cosmSword,
	ItemID.cosmPickaxe,
	ItemID.cosmAxe,
	ItemID.cosmShovel,
	ItemID.cosmdes,
    ItemID.cosmhammer,
]);



//magic stick




Item.addCreativeGroup("Trophy", Translation.translate("Trophy"), [
	ItemID.ughastTrophy,
	ItemID.lichTrophy,
	ItemID.nagaTrophy,
	ItemID.hydraTrophy,
	
]);

Item.addCreativeGroup("Helmet hexxit", Translation.translate("Helmet hexxit"), [
     ItemID.infinity_helmet,
	ItemID.sageHelmet,
	ItemID.scaleHelmet,
	ItemID.thiefHelmet,
	ItemID.tribalHelmet,
	ItemID.armor1,
	ItemID.lol,
	 ItemID.st1,
	ItemID.fieryH,
	ItemID.stoneHelmet,
	ItemID.snowHelmet,
	ItemID.slimeHelmet,
	ItemID.dirtHelmet,
	ItemID.netherHelmet,
	ItemID.cobblestoneHelmet,
	ItemID.caneHelmet,
	 ItemID.brickHelmet,
	 ItemID.quartzHelmet,
	 ItemID.redstoneHelmet,
	ItemID.logHelmet,
	 ItemID.planksHelmet,
	 ItemID.dioriteHelmet,
	 ItemID.graniteHelmet,
	 ItemID.emeraldHelmet,
	 ItemID.lapisHelmet,
	 ItemID.coalHelmet,
	
]);

Item.addCreativeGroup("Chestplate hexxit ", Translation.translate(" Chestplate hexxit "), [
	ItemID.infinity_chestplate,
ItemID.sageChestplate,
	ItemID.scaleChestplate,
	ItemID.thiefChestplate,
	ItemID.tribalChestplate,
	ItemID.armor2,
	ItemID.loz,
	ItemID.st2,
	ItemID.fieryC,
	ItemID.stoneChestplate,
	ItemID.snowChestplate,
	ItemID.slimeChestplate,
	ItemID.dirtChestplate,
	ItemID.netherChestplate,
	 ItemID.cobblestoneChestplate,
	 ItemID.caneChestplate,
	 ItemID.brickChestplate,
	ItemID.quartzChestplate,
	 ItemID.redstoneChestplate,
	 ItemID.logChestplate,
	 ItemID.planksChestplate,
	ItemID.dioriteChestplate,
	 ItemID.graniteChestplate,
	ItemID.emeraldChestplate,
	 ItemID.lapisChestplate,
	 ItemID.coalChestplate,
]);

Item.addCreativeGroup("Leggings hexxit", Translation.translate("leggings hexxit"), [
	ItemID.infinity_leggings,
    ItemID.sageLeggings,
	ItemID.scaleLeggings,
	ItemID.thiefLeggings,
	ItemID.tribalLeggings,
	ItemID.armor3,
	ItemID.st3,
	ItemID.fieryL,
	ItemID.stoneLeggings,
	ItemID.snowLeggings,
	ItemID.slimeLeggings,
	ItemID.dirtLeggings,
	ItemID.netherLeggings,
	ItemID.cobblestoneLeggings,
	ItemID.caneLeggings,
	ItemID.brickLeggings,
	ItemID.quartzLeggings,
	ItemID.redstoneLeggings,
	ItemID.logLeggings,
	ItemID.planksLeggings,
	ItemID.dioriteLeggings,
	ItemID.graniteLeggings,
	ItemID.emeraldLeggings,
	ItemID.lapisLeggings,
	ItemID.coalLeggings,
]);

Item.addCreativeGroup("Boots hexxit", Translation.translate("Boots hexxit"), [
	ItemID.infinity_boots,
ItemID. sageBoots,
	ItemID.scaleBoots,
	ItemID.thiefBoots,
	ItemID.tribalBoots,
	ItemID.armor4,
	ItemID.st4,
	ItemID.fieryB,
	ItemID.stoneBoots,
	ItemID.snowBoots,
	ItemID.slimeBoots,
	ItemID.dirtBoots,
	ItemID.netherBoots,
	ItemID.cobblestoneBoots,
	ItemID.caneBoots,
	ItemID.brickBoots,
	ItemID.quartzBoots,
	ItemID.redstoneBoots,
	ItemID.logBoots,
	ItemID.planksBoots,
	ItemID.dioriteBoots,
	ItemID.graniteBoots,
	ItemID.emeraldBoots,
	ItemID.lapisBoots,
	ItemID.coalBoots,
]);






Item.addCreativeGroup("Log", Translation.translate("Log"), [
	BlockID.twDarkLog,
	 BlockID.twMangroveLog,
	BlockID.twCanopyLog,
	 BlockID.twTwilightOakLog,
	BlockID.twMiningLog,
	 BlockID.twSortingLog,
	BlockID.twTimeLog,
	 BlockID.twTransformationLog,
]);
Item.addCreativeGroup("Plank", Translation.translate("Plank"), [
	BlockID.tw_planks_dark_wood,
	 BlockID.tw_planks_mangrove,
	BlockID.tw_planks_canopy,
	 BlockID.tw_planks_twilight_oak,
	BlockID.tw_planks_mine,
	 BlockID.tw_planks_sort,
	BlockID.tw_planks_time,
	 BlockID.tw_planks_trans,
]);



