Recipes.addShaped({id: ItemID.wooden_giant_sword, count: 1, data: 0}, [
		"oqq",
		"qqq",
		"mqa"
	], ['o', ItemID.page, 0,'m', 280, 0,'q', 5, 1]);

Recipes.addShaped({id: ItemID.wooden_giant_sword, count: 1, data: 0}, [
		"oqq",
		"qqq",
		"mqa"
	], ['o', ItemID.page, 0,'m', 280, 0,'q', 5, 2]);
	
	 Recipes.addShaped({id: ItemID.wooden_giant_sword, count: 1, data: 0}, [
		"oqq",
		"qqq",
		"mqa"
	], ['o', ItemID.page, 0,'m', 280, 0,'q', 5, 3]);
	
	 Recipes.addShaped({id: ItemID.wooden_giant_sword, count: 1, data: 0}, [
		"oqq",
		"qqq",
		"mqa"
	], ['o', ItemID.page, 0,'m', 280, 0,'q', 5, 4]);
	
	 Recipes.addShaped({id: ItemID.wooden_giant_sword, count: 1, data: 0}, [
		"oqq",
		"qqq",
		"mqa"
	], ['o', ItemID.page, 0,'m', 280, 0,'q', 5, 5]);


//stm
