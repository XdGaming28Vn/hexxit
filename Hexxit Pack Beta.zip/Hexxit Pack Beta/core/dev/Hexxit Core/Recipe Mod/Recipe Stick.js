Recipes.addShaped({id: 280, count: 4, data: 0}, [
		"axx",
		"axx",
		"xxx"
	], ['a', BlockID.tw_planks_sort, 0]);
	//
	 Recipes.addShaped({id: 280, count: 4, data: 0}, [
		"axx",
		"axx",
		"xxx"
	], ['a', BlockID.tw_planks_time, 0]);
	//
	 Recipes.addShaped({id: 280, count: 4, data: 0}, [
		 "axx",
		"axx",
		"xxx"
	], ['a', BlockID.tw_planks_trans, 0]);
	 Recipes.addShaped({id: 280, count: 4, data: 0}, [
		 "axx",
		"axx",
		"xxx"
	], ['a', BlockID.tw_planks_dark_wood, 0]);
	// 
       Recipes.addShaped({id: 280, count: 4, data: 0}, [
		 "axx",
		"axx",
		"xxx"
	], ['a', BlockID.tw_planks_mangrove, 0]);
	// 
     Recipes.addShaped({id: 280, count: 4, data: 0}, [
		 "axx",
		"axx",
		"xxx"
	], ['a', BlockID.tw_planks_canopy, 0]);
	// 
      Recipes.addShaped({id: 280, count: 4, data: 0}, [
		 "axx",
		"axx",
		"xxx"
	], ['a', BlockID.tw_planks_twilight_oak, 0]);
	// 
     Recipes.addShaped({id: 280, count: 4, data: 0}, [
		 "axx",
		"axx",
		"xxx"
	], ['a', BlockID.tw_planks_mine, 0]);
	//
	 Recipes.addShaped({id: ItemID.fint, count: 4, data: 0}, [
		 "ab",
		"ccc",
		"xxx"
	], ['a', ItemID.fieryblood, 0,'b', 265, 0]);