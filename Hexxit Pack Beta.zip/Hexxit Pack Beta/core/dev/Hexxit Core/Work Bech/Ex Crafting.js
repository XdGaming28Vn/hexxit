



IDRegistry.genBlockID("extCraft");
Block.createBlockWithRotation("extCraft", [{
	name: "Extrеme Crafting \n Update: Infinity",
	texture: [["crafting", 2],
 ["craftingtop", 0],
 ["craftingside", 0],
  ["craftingside", 0],
   ["craftingside", 0],
    ["craftingside", 0]],
	inCreative: true
}], "opaque");
Block.setDestroyTime(BlockID.extCraft, 4);
ToolAPI.registerBlockMaterial(BlockID.extCraft, "stone", 3, true);


var ext_crafting = new UI.StandartWindow({
    standart: {
        header: {text: {text: Translation.translate("Extrеme Table")}},
        inventory: {standart:true},
        background: {standart: true},
    },
    drawing: [{
        type: "bitmap",
        bitmap: "plus",
        x: 450,
        y: 170,
        scale: 4
    },{
    	type: "bitmap",
        bitmap: "arrow",
        x: 640,
        y: 170,
        scale: 4
   },{
   	type: "bitmap",
       bitmap: "infinity",
       x: 350,
       y: 90,
       scale: 5
    },{
       type: "text",
       text: Translation.translate("Upgrade  Infinity Armor and tools..."),
       x: 435,
       y: 130,
       font: {color: Color.BLACK},
       scale: 1
    }],
    elements:{
        "inputSlot0":{x:350, y:170, type:"slot"},
        "inputSlot1":{x:550, y:170, type:"slot"/*, bitmap: "ingotplace"*/},

        "outputSlot":{x:750, y:170, type:"slot"}
    }
});

TileEntity.registerPrototype(BlockID.extCraft, {
	useNetworkItemContainer: true,
	
	getScreenName: function(player, coords) {
        return "main";
    },
    getScreenByName: function(screenName) {
        return ext_crafting;
    },
    
    init: function () {
    	this.container.setSlotAddTransferPolicy("outputSlot", function(container, name, id, amount, data, extra, playerUid){return 0;})//result slot
    
        this.container.setSlotAddTransferPolicy("inputSlot0", function(container, name, id, amount, data, extra, playerUid)
		{
			if (container.getSlot("inputSlot0").count == 1) {
				return 0;
			}else{
				return 1;
			}
		}) //base slot
		
		this.container.setSlotAddTransferPolicy("inputSlot1", function(container, name, id, amount, data, extra, playerUid)
		{
			if (container.getSlot("inputSlot1").count == 1) {
				return 0;
			}else{
				return 1;
			}
		}) //netherite slot
		
		this.container.setSlotGetTransferPolicy("outputSlot", function(container, name, id, amount, data, extra, playerUid)
		{
			container.getSlot("inputSlot1").id = 0
			container.getSlot("inputSlot1").count = 0
			container.getSlot("inputSlot0").id = 0
			container.getSlot("inputSlot0").count = 0
			return 1;
		})
    },
    
    destroy: function(){
    	this.container.getSlot("outputSlot").id = 0
		this.container.getSlot("outputSlot").count = 0
    },
	
	tick: function(){
		var baseSlot = this.container.getSlot("inputSlot0");
		var netheriteSlot = this.container.getSlot("inputSlot1");
		var resultSlot = this.container.getSlot("outputSlot");
		var extraTemp;
		var extraData;
		
		
		if(baseSlot.id == 310 && IDRegistry.getNameByID(netheriteSlot.id) == "infinityingot") {
			extraTemp = baseSlot.extra
			extraData = baseSlot.data
			resultSlot.id = ItemID.infinity_helmet
			resultSlot.count = 1;
			this.container.setSlot("outputSlot", this.container.getSlot("outputSlot").id, 1, extraData, extraTemp);
			//fiery  chestplate
		} else if(baseSlot.id == 311 && IDRegistry.getNameByID(netheriteSlot.id) == "infinityingot") {
			extraTemp = baseSlot.extra
			extraData = baseSlot.data
			resultSlot.id = ItemID.infinity_chestplate
			resultSlot.count = 1;
			this.container.setSlot("outputSlot", this.container.getSlot("outputSlot").id, 1, extraData, extraTemp);
			//fiery  leggings
		} else if(baseSlot.id == 312 && IDRegistry.getNameByID(netheriteSlot.id) == "infinityingot") {
			extraTemp = baseSlot.extra
			extraData = baseSlot.data
			resultSlot.id = ItemID.infinity_leggings
			resultSlot.count = 1;
			this.container.setSlot("outputSlot", this.container.getSlot("outputSlot").id, 1, extraData, extraTemp);
			//fiery  boots
		} else if(baseSlot.id == 313 && IDRegistry.getNameByID(netheriteSlot.id) == "infinityingot") {
			extraTemp = baseSlot.extra
			extraData = baseSlot.data
			resultSlot.id = ItemID.infinity_boots
			resultSlot.count = 1;
			this.container.setSlot("outputSlot", this.container.getSlot("outputSlot").id, 1, extraData, extraTemp);
			//magic1 sword
		
		
			//
			 } else if(baseSlot.id == 277 && IDRegistry.getNameByID(netheriteSlot.id) == "infinityingot") {
			extraTemp = baseSlot.extra
			extraData = baseSlot.data
			resultSlot.id = ItemID.cosmShovel
			resultSlot.count = 1;
			this.container.setSlot("outputSlot", this.container.getSlot("outputSlot").id, 1, extraData, extraTemp);
			//
			 } else if(baseSlot.id == 279 && IDRegistry.getNameByID(netheriteSlot.id) == "infinityingot") {
			extraTemp = baseSlot.extra
			extraData = baseSlot.data
			resultSlot.id = ItemID.cosmAxe
			resultSlot.count = 1;
			this.container.setSlot("outputSlot", this.container.getSlot("outputSlot").id, 1, extraData, extraTemp);
			//
		 } else if(baseSlot.id == 276 && IDRegistry.getNameByID(netheriteSlot.id) == "infinityingot") {
			extraTemp = baseSlot.extra
			extraData = baseSlot.data
			resultSlot.id = ItemID.cosmSword
			resultSlot.count = 1;
			this.container.setSlot("outputSlot", this.container.getSlot("outputSlot").id, 1, extraData, extraTemp);
			} else if(baseSlot.id == 278 && IDRegistry.getNameByID(netheriteSlot.id) == "infinityingot") {
			extraTemp = baseSlot.extra
			extraData = baseSlot.data
			resultSlot.id = ItemID.cosmPickaxe
			resultSlot.count = 1;
			this.container.setSlot("outputSlot", this.container.getSlot("outputSlot").id, 1, extraData, extraTemp);
		}else{
			resultSlot.id = 0
			resultSlot.count = 0;
			this.container.setSlot("outputSlot", this.container.getSlot("outputSlot").id, 0, 0);
		}
        
		//visual final
		if (baseSlot.count == 0) {
			this.container.setSlot("inputSlot0", 0, 0, 0);
		}
		if (netheriteSlot.count == 0) {
			this.container.setSlot("inputSlot1", 0, 0, 0);
		}
		this.container.validateAll()
	}
});
//recipe 
Recipes.addShaped({id: BlockID.extCraft, count: 1, data: 0}, [
		"ooo",
		"ana",
		"aaa"
	], ['n', ItemID.infinityingot, 0,'a', 42, 0,'o', 57, 0]);


