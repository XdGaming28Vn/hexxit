var SBInventory = {
    isEnabled: false,
    container: new UI.Container(),
    windowContainer: new UI.Container(),
    buttonWindow: new UI.Window({
        location: {
            x: -170,
            y: -180,
            width: 50,
            height: 50
        },
        drawing:[
            {type: "background", color: 0}
        ],
        elements:{
            "fuckButton":{type: "button", x: 0, y: 0, scale: 31, bitmap: "icon", clicker:{onClick:function(){
                SBInventory.windowContainer.openAs(SBInventory.Window);
            }}}
        }
    }), 
    Window: new UI.StandartWindow({
        standart:{
			header: {text: {text: "Skill Tools Update"}},
            backgroud:{
                standart: true
            },
            inventory:{
                standart: true
            }
        },
        elements:{
		"inputSlot0": {type: "slot", x: 430, y: 180, size: 71}, 
		"inputSlot1": {type: "slot", x: 520, y: 180, size: 71},
		"image_0": {type: "image", x: 611, y: 180, bitmap: "arrow", scale: 4.5},
		"outputSlot": {type: "slot", x: 720, y: 180, size: 71, isValid:RecipeTE.outputSlotValid}
        } 
    }),
    open:function(){
        if(!this.isEnabled){
            this.container.openAs(this.buttonWindow);
            this.isEnabled = true;
        }
    },
    close:function(){
        if(this.isEnabled){
            this.container.close();
            this.isEnabled = false;
        }
    }
};

SBInventory.buttonWindow.setAsGameOverlay(true);

Callback.addCallback("NativeGuiChanged", function (screenName) {
	//alert(screenName);
    if(screenName == "inventory_screen"){
        SBInventory.open();
    }else if(SBInventory.isEnabled){
        SBInventory.close();
    }
});


var getSlot = SBInventory.windowContainer.getSlot;
var clearSlot = SBInventory.windowContainer.clearSlot;
Callback.addCallback("tick", function (){
if(SBInventory.isEnabled&&SBInventory.windowContainer.isOpened()){
 
   if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.dragon_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.fire_skill_untimed
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.dragon_giant_sword_fire_untimed, 1, 0);
}
 if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.dragon_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.ice_skill_untimed
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.dragon_giant_sword_ice_untimed, 1, 0);
}
//Legend Recipe
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.wooden_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.ice_skill_legend
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.wooden_giant_sword_ice_legend, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.stone_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.ice_skill_legend
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.stone_giant_sword_ice_legend, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.iron_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.ice_skill_legend
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.iron_giant_sword_ice_legend, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.gold_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.ice_skill_legend
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.gold_giant_sword_ice_legend, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.diamond_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.ice_skill_legend
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.diamond_giant_sword_ice_legend, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.emerald_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.ice_skill_legend
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.emerald_giant_sword_ice_legend, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.ender_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.ice_skill_legend
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.ender_giant_sword_ice_legend, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.livingmetal_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.ice_skill_legend
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.livingmetal_giant_sword_ice_legend, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.quartz_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.ice_skill_legend
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.quartz_giant_sword_ice_legend, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.netherrack_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.ice_skill_legend
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.netherrack_giant_sword_ice_legend, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.bone_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.ice_skill_legend
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.bone_giant_sword_ice_legend, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.obsidian_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.ice_skill_legend
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.obsidian_giant_sword_ice_legend, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.netherite_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.ice_skill_legend
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.netherite_giant_sword_ice_legend, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.wither_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.ice_skill_legend
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.wither_giant_sword_ice_legend, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.dragon_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.ice_skill_legend
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.dragon_giant_sword_ice_legend, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.wooden_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.fire_skill_legend
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.wooden_giant_sword_fire_legend, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.stone_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.fire_skill_legend
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.stone_giant_sword_fire_legend, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.iron_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.fire_skill_legend
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.iron_giant_sword_fire_legend, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.gold_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.fire_skill_legend
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.gold_giant_sword_fire_legend, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.diamond_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.fire_skill_legend
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.diamond_giant_sword_fire_legend, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.emerald_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.fire_skill_legend
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.emerald_giant_sword_fire_legend, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.ender_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.fire_skill_legend
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.ender_giant_sword_fire_legend, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.livingmetal_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.fire_skill_legend
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.livingmetal_giant_sword_fire_legend, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.quartz_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.fire_skill_legend
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.quartz_giant_sword_fire_legend, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.netherrack_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.fire_skill_legend
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.netherrack_giant_sword_fire_legend, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.bone_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.fire_skill_legend
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.bone_giant_sword_fire_legend, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.obsidian_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.fire_skill_legend
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.obsidian_giant_sword_fire_legend, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.netherite_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.fire_skill_legend
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.netherite_giant_sword_fire_legend, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.wither_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.fire_skill_legend
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.wither_giant_sword_fire_legend, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.dragon_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.fire_skill_legend
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.dragon_giant_sword_fire_legend, 1, 0);
}//untimed
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.wooden_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.ice_skill_untimed
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.wooden_giant_sword_ice_untimed, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.stone_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.ice_skill_untimed
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.stone_giant_sword_ice_untimed, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.iron_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.ice_skill_untimed
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.iron_giant_sword_ice_untimed, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.gold_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.ice_skill_untimed
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.gold_giant_sword_ice_untimed, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.diamond_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.ice_skill_untimed
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.diamond_giant_sword_ice_untimed, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.emerald_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.ice_skill_untimed
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.emerald_giant_sword_ice_untimed, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.ender_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.ice_skill_untimed
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.ender_giant_sword_ice_untimed, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.livingmetal_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.ice_skill_untimed
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.livingmetal_giant_sword_ice_untimed, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.quartz_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.ice_skill_untimed
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.quartz_giant_sword_ice_untimed, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.netherrack_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.ice_skill_untimed
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.netherrack_giant_sword_ice_untimed, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.bone_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.ice_skill_untimed
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.bone_giant_sword_ice_untimed, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.obsidian_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.ice_skill_untimed
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.obsidian_giant_sword_ice_untimed, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.netherite_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.ice_skill_untimed
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.netherite_giant_sword_ice_untimed, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.wither_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.ice_skill_untimed
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.wither_giant_sword_ice_untimed, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.dragon_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.ice_skill_untimed
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.dragon_giant_sword_ice_untimed, 1, 0);
}
//fire
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.wooden_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.fire_skill_untimed
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.wooden_giant_sword_fire_untimed, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.stone_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.fire_skill_untimed
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.stone_giant_sword_fire_untimed, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.iron_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.fire_skill_untimed
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.iron_giant_sword_fire_untimed, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.gold_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.fire_skill_untimed
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.gold_giant_sword_fire_untimed, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.diamond_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.fire_skill_untimed
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.diamond_giant_sword_fire_untimed, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.emerald_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.fire_skill_untimed
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.emerald_giant_sword_fire_untimed, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.ender_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.fire_skill_untimed
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.ender_giant_sword_fire_untimed, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.livingmetal_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.fire_skill_untimed
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.livingmetal_giant_sword_fire_untimed, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.quartz_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.fire_skill_untimed
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.quartz_giant_sword_fire_untimed, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.netherrack_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.fire_skill_untimed
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.netherrack_giant_sword_fire_untimed, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.bone_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.fire_skill_untimed
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.bone_giant_sword_fire_untimed, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.obsidian_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.fire_skill_untimed
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.obsidian_giant_sword_fire_untimed, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.netherite_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.fire_skill_untimed
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.netherite_giant_sword_fire_untimed, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.wither_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.fire_skill_untimed
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.wither_giant_sword_fire_untimed, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.dragon_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.fire_skill_untimed
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.dragon_giant_sword_fire_untimed, 1, 0);
}



}
});

