IDRegistry.genItemID("sageHelmet");
Item.createArmorItem("sageHelmet", "Sage Helmet \n Skill:§aTrue", {name: "sagehelmet"}, {type: "helmet", armor: 3, durability: 1500, texture: "armor/sagelayer_1.png"});

IDRegistry.genItemID("sageChestplate");
Item.createArmorItem("sageChestplate", "Sage Chestplate \n Skill:§aTrue", {name: "sagechest"}, {type: "chestplate", armor: 8, durability: 1500, texture: "armor/sagelayer_1.png"});

IDRegistry.genItemID("sageLeggings");
Item.createArmorItem("sageLeggings", "Sage Leggings \n Skill:§aTrue", {name: "sagelegs"}, {type: "leggings", armor: 6, durability: 1500, texture: "armor/sagelayer_2.png"});

IDRegistry.genItemID("sageBoots");
Item.createArmorItem("sageBoots", "Sage Boots \n Skill:§aTrue", {name: "sageboots"}, {type: "boots", armor: 3, durability: 176, texture: "armor/sagelayer_1.png"});


//2
IDRegistry.genItemID("scaleHelmet");
Item.createArmorItem("scaleHelmet", "Scale Helmet \n Skill:§aTrue", {name: "scalehelmet"}, {type: "helmet", armor: 3, durability: 1500, texture: "armor/scalelayer_1.png"});

IDRegistry.genItemID("scaleChestplate");
Item.createArmorItem("scaleChestplate", "Scale Chestplate \n Skill:§aTrue", {name: "scalechest"}, {type: "chestplate", armor: 8, durability: 1500, texture: "armor/scalelayer_1.png"});

IDRegistry.genItemID("scaleLeggings");
Item.createArmorItem("scaleLeggings", "Scale Leggings \n Skill:§aTrue", {name: "scalelegs"}, {type: "leggings", armor: 6, durability: 1500, texture: "armor/scalelayer_2.png"});

IDRegistry.genItemID("scaleBoots");
Item.createArmorItem("scaleBoots", "Scale Boots \n Skill:§aTrue", {name: "scaleboots"}, {type: "boots", armor: 3, durability: 176, texture: "armor/scalelayer_1.png"});

//3
IDRegistry.genItemID("thiefHelmet");
Item.createArmorItem("thiefHelmet", "Thief Helmet \n Skill:§aTrue", {name: "thiefhelmet"}, {type: "helmet", armor: 3, durability: 1500, texture: "armor/thieflayer_1.png"});

IDRegistry.genItemID("thiefChestplate");
Item.createArmorItem("thiefChestplate", "Thief Chestplate \n Skill:§aTrue", {name: "thiefchest"}, {type: "chestplate", armor: 8, durability: 1500, texture: "armor/thieflayer_1.png"});

IDRegistry.genItemID("thiefLeggings");
Item.createArmorItem("thiefLeggings", "Thief Leggings \n Skill:§aTrue", {name: "thieflegs"}, {type: "leggings", armor: 6, durability: 1500, texture: "armor/thieflayer_2.png"});

IDRegistry.genItemID("thiefBoots");
Item.createArmorItem("thiefBoots", "Thief Boots \n Skill:§aTrue", {name: "thiefboots"}, {type: "boots", armor: 3, durability: 1500, texture: "armor/thieflayer_1.png"});

//4
IDRegistry.genItemID("tribalHelmet");
Item.createArmorItem("tribalHelmet", "Tribal Helmet \n Skill:§aTrue", {name: "tribalhelmet"}, {type: "helmet", armor: 3, durability: 1500, texture: "armor/tribalhelm.png"});

IDRegistry.genItemID("tribalChestplate");
Item.createArmorItem("tribalChestplate", "Tribal Chestplate \n Skill:§aTrue", {name: "tribalchest"}, {type: "chestplate", armor: 8, durability: 1500, texture: "armor/triballayer_1.png"});

IDRegistry.genItemID("tribalLeggings");
Item.createArmorItem("tribalLeggings", "Tribal Leggings \n Skill:§aTrue", {name: "triballegs"}, {type: "leggings", armor: 6, durability: 1500, texture: "armor/triballayer_2.png"});

IDRegistry.genItemID("tribalBoots");
Item.createArmorItem("tribalBoots", "Tribal Boots \n Skill:§aTrue", {name: "tribalboots"}, {type: "boots", armor: 3, durability: 1500, texture: "armor/triballayer_1.png"});


Callback.addCallback("GenerateChunk", function(chunkX, chunkZ){
	var coords = GenerationUtils.randomCoords(chunkX, chunkZ, 64, 128);
	coords = GenerationUtils.findSurface(coords.x, coords.y, coords.z);
	if(Math.random()< __config__.access("HexGenNumber") ){
		if((World.getBiome((chunkX + 0.5) * 16, (chunkZ + 0.5) * 16)==id)){
			World.setBlock(coords.x, coords.y + 1, coords.z, BlockID.hexibiscus, 0);
		}
	}
});

Recipes.addShaped({id: ItemID.diamondHexical, count: 1, data: 0}, [
	" b ",
	"bab",
	" b "
], ['a', 264, 0, 'b', ItemID.essenceHexical, 0]);
Recipes.addShaped({id: ItemID.sageHelmet, count: 1, data: 0}, [
	" b ",
	"cac",
	"d d"
], ['a', ItemID.diamondHexical, 0,'b', 340, 0,'c', 49, 0, 'd',35,0]);

Recipes.addShaped({id: ItemID.sageChestplate, count: 1, data: 0}, [
	"c c",
	"dad",
	"cbc"
], ['a', ItemID.diamondHexical, 0, 'b', 35, 0,'c', 266, 0, 'd',340,0]);

Recipes.addShaped({id: ItemID.sageLeggings, count: 1, data: 0}, [
	"bcb",
	"dad",
	"b b"
], ['a', ItemID.diamondHexical, 0,'b', 266, 0,'c', 35, 0, 'd',340,0]);

Recipes.addShaped({id: ItemID.sageBoots, count: 1, data: 0}, [
	"bab",
	"c c",
	"   "
], ['a', ItemID.diamondHexical, 0,'b', 340, 0, 'c',35,0]);

Recipes.addShaped({id: ItemID.scaleHelmet, count: 1, data: 0}, [
	"bbb",
	"cac"
], ['a', ItemID.diamondHexical, 0,'b', 49, 0,'c', 266, 0]);

Recipes.addShaped({id: ItemID.scaleChestplate, count: 1, data: 0}, [
	"c c",
	"bab",
	"cbc"
], ['a', ItemID.diamondHexical, 0, 'b', 49, 0,'c', 266, 0]);

Recipes.addShaped({id: ItemID.scaleLeggings, count: 1, data: 0}, [
	"bbb",
	"cac",
	"b b"
], ['a', ItemID.diamondHexical, 0,'b', 49, 0,'c', 266, 0]);

Recipes.addShaped({id: ItemID.scaleBoots, count: 1, data: 0}, [
	"bab",
	"b b"
], ['a', ItemID.diamondHexical, 0,'b', 49, 0]);


Recipes.addShaped({id: ItemID.thiefHelmet, count: 1, data: 0}, [
	"bbb",
	"bab"
], ['a', ItemID.diamondHexical, 0,'b', 35, 14]);

Recipes.addShaped({id: ItemID.thiefChestplate, count: 1, data: 0}, [
	"b b",
	"cac",
	"ccc"
], ['a', ItemID.diamondHexical, 0, 'b', 35, 14,'c', 334, 0]);

Recipes.addShaped({id: ItemID.thiefLeggings, count: 1, data: 0}, [
	"bab",
	"bcb",
	"b b"
], ['a', ItemID.diamondHexical, 0,'b', 334, 0,'c', 287, 0]);

Recipes.addShaped({id: ItemID.thiefBoots, count: 1, data: 0}, [
	"cac",
	"b b"
], ['a', ItemID.diamondHexical, 0, 'b', 35, 7,'c', 334, 0]);


Recipes.addShaped({id: ItemID.tribalHelmet, count: 1, data: 0}, [
	"bbb",
	"bab"
], ['a', ItemID.diamondHexical, 0,'b', 352, 0]);

Recipes.addShaped({id: ItemID.tribalChestplate, count: 1, data: 0}, [
	"c c",
	"bab",
	"cbc"
], ['a', ItemID.diamondHexical, 0, 'b', 334, 0,'c', 265, 0]);

Recipes.addShaped({id: ItemID.tribalLeggings, count: 1, data: 0}, [
	"bbb",
	"cac",
	"b b"
], ['a', ItemID.diamondHexical, 0,'b', 334, 0,'c', 265, 0]);

Recipes.addShaped({id: ItemID.tribalBoots, count: 1, data: 0}, [
	"cac",
	"b b"
], ['a', ItemID.diamondHexical, 0,'b', 334, 0,'c', 287, 0]);



/*

var sageArmor = false;
var scaleArmor = false;
var thiefArmor = false;
var tribalArmor = false;
Callback.addCallback("tick", function(){
	if(World.getThreadTime()%120 == 0){
		if(World.getBlock(Player.getPosition().x-0.5, Player.getPosition ().y-0.8, Player.getPosition ().z-0.6).id == BlockID.hexibiscus){
			Entity.addEffect(Player.get(), Native.PotionEffect.absorption, 0, 20*5);
			Entity.addEffect(Player.get(), Native.PotionEffect.regeneration, 0, 20*5);
		}
	}
	var armor = [Player.getArmorSlot(0), Player.getArmorSlot(1), Player.getArmorSlot(2), Player.getArmorSlot(3)];
	if(World.getThreadTime()%50 == 0){
		if(armor[0].id == ItemID.sageHelmet&&armor[1].id == ItemID.sageChestplate&&armor[2].id == ItemID.sageLeggings&&armor[3].id == ItemID.sageBoots){
			sageArmor = true;
			Entity.addEffect(Player.get(), Native.PotionEffect.waterBreathing, 0, 20*15);
			Entity.addEffect(Player.get(), Native.PotionEffect.absorption, 2, 20*15);
			Entity.addEffect(Player.get(), Native.PotionEffect.fireResistance, 1, 20*15);
			Entity.addEffect(Player.get(), Native.PotionEffect.nightVision, 0, 20*15);
		}else if(sageArmor) Entity.clearEffects (Player.get()), sageArmor = false;
		
		if(armor[0].id == ItemID.scaleHelmet&&armor[1].id == ItemID.scaleChestplate&&armor[2].id == ItemID.scaleLeggings&&armor[3].id == ItemID.scaleBoots){
			scaleArmor = true;
			Entity.addEffect(Player.get(), Native.PotionEffect.damageBoost, 0, 20*15);
			Entity.addEffect(Player.get(), Native.PotionEffect.damageResistance, 0, 20*15);
			Entity.addEffect(Player.get(), Native.PotionEffect.fireResistance, 1, 20*15);
		}else if(scaleArmor) Entity.clearEffects (Player.get()), scaleArmor = false;

		if(armor[0].id == ItemID.thiefHelmet&&armor[1].id == ItemID.thiefChestplate&&armor[2].id == ItemID.thiefLeggings&&armor[3].id == ItemID.thiefBoots){
			thiefArmor = true;
			Entity.addEffect(Player.get(), Native.PotionEffect.nightVision, 0, 20*15);
			Entity.addEffect(Player.get(), Native.PotionEffect.movementSpeed, 2, 20*15);
			Entity.addEffect(Player.get(), Native.PotionEffect.damageBoost, 0, 20*15);
			Entity.addEffect(Player.get(), Native.PotionEffect.jump, 0, 20*15);
		}else if(thiefArmor) Entity.clearEffects (Player.get()), thiefArmor = false;

		if(armor[0].id == ItemID.tribalHelmet&&armor[1].id == ItemID.tribalChestplate&&armor[2].id == ItemID.tribalLeggings&&armor[3].id == ItemID.tribalBoots){
			tribalArmor = true;
			Entity.addEffect(Player.get(), Native.PotionEffect.nightVision, 0, 20*15);
			Entity.addEffect(Player.get(), Native.PotionEffect.digSpeed, 1, 20*15);
			Entity.addEffect(Player.get(), Native.PotionEffect.jump, 2, 20*15);
		}else if(tribalArmor) Entity.clearEffects (Player.get()), tribalArmor = false;
	}


});
*/
//1
IDRegistry.genItemID("st1");
IDRegistry.genItemID("st2");
IDRegistry.genItemID("st3");
IDRegistry.genItemID("st4");

Item.createArmorItem("st1", " steeleaf Helmet", {name: "sh1"}, {type: "helmet", armor: 3, durability: 1100, texture: "armor/sk1_1.png"});
Item.createArmorItem("st2", " steeleaf Chestplate", {name: "sh2"}, {type: "chestplate", armor: 4, durability: 1100, texture: "armor/sk1_1.png"});
Item.createArmorItem("st3", " steeleaf Leggings", {name: "sh3"}, {type: "leggings", armor: 4, durability: 1100, texture: "armor/sk2_2.png"});
Item.createArmorItem("st4", " steeleaf Boots", {name: "sh4"}, {type: "boots", armor: 3, durability: 1100, texture: "armor/sk1_1.png"});



Recipes.addShaped({id: ItemID.st1, count: 1, data: 0}, [
	"xxx",
	"xox",
	"ooo"
], ['x', ItemID.steeleaf, 0]);

Recipes.addShaped({id: ItemID.st2, count: 1, data: 0}, [
	"xox",
	"xxx",
	"xxx"
], ['x', ItemID.steeleaf, 0]);

Recipes.addShaped({id: ItemID.st3, count: 1, data: 0}, [
	"xxx",
	"xox",
	"xox"
], ['x', ItemID.steeleaf, 0]);

Recipes.addShaped({id: ItemID.st4, count: 1, data: 0}, [
	"ooo",
	"xox",
	"xox"
], ['x', ItemID.steeleaf, 0]);



IDRegistry.genItemID("lol");
IDRegistry.genItemID("loz");

Item.createArmorItem("lol", " fantom Helmet", {name: "fantom1"}, {type: "helmet", armor: 6, durability: 1100, texture: "armor/fan1_1.png"});
Item.createArmorItem("loz", " fantom Chestplate", {name: "fantom2"}, {type: "chestplate", armor: 9, durability: 1100, texture: "armor/fan1_1.png"});

IDRegistry.genItemID("armor1");
IDRegistry.genItemID("armor2");
IDRegistry.genItemID("armor3");
IDRegistry.genItemID("armor4");

Item.createArmorItem("armor1", " ironwood Helmet", {name: "cr1"}, {type: "helmet", armor: 3, durability: 1100, texture: "armor/cr1_1.png"});
Item.createArmorItem("armor2", " ironwood Chestplate", {name: "cr2"}, {type: "chestplate", armor: 4, durability: 1100, texture: "armor/cr1_1.png"});
Item.createArmorItem("armor3", " ironwood Leggings", {name: "cr3"}, {type: "leggings", armor: 4, durability: 1100, texture: "armor/cr2_2.png"});
Item.createArmorItem("armor4", " ironwood Boots", {name: "cr4"}, {type: "boots", armor: 3, durability: 1100, texture: "armor/cr1_1.png"});



Recipes.addShaped({id: ItemID.armor1, count: 1, data: 0}, [
	"xxx",
	"xox",
	"ooo"
], ['x', ItemID.ironwood, 0]);

Recipes.addShaped({id: ItemID.armor2, count: 1, data: 0}, [
	"xox",
	"xxx",
	"xxx"
], ['x', ItemID.ironwood, 0]);

Recipes.addShaped({id: ItemID.armor3, count: 1, data: 0}, [
	"xxx",
	"xox",
	"xox"
], ['x', ItemID.ironwood, 0]);

Recipes.addShaped({id: ItemID.armor4, count: 1, data: 0}, [
	"ooo",
	"xox",
	"xox"
], ['x', ItemID.ironwood, 0]);
//fiery
IDRegistry.genItemID("fieryH");
IDRegistry.genItemID("fieryC");
IDRegistry.genItemID("fieryL");
IDRegistry.genItemID("fieryB");

Item.createArmorItem("fieryH", "Fiery Helmet \n Skill:§aTrue", {name: "FH1"}, {type: "helmet", armor: 6, durability: 1100, texture: "armor/FA1_1.png"});
Item.createArmorItem("fieryC", "Fiery Chestplate \n Skill:§aTrue", {name: "FC2"}, {type: "chestplate", armor: 7, durability: 1100, texture: "armor/FA1_1.png"});
Item.createArmorItem("fieryL", "Fiery Leggings \n Skill:§aTrue", {name: "FL3"}, {type: "leggings", armor: 7, durability: 1100, texture: "armor/FA2_2.png"});
Item.createArmorItem("fieryB", "Fiery Boots \n Skill:§aTrue", {name: "FB4"}, {type: "boots", armor: 6, durability: 1100, texture: "armor/FA1_1.png"});

Item.setGlint("fieryH", true);
Item.setGlint("fieryC", true);
Item.setGlint("fieryL", true);
Item.setGlint("fieryB", true);

Recipes.addShaped({id: ItemID.fieryH, count: 1, data: 0}, [
	"xxx",
	"xox",
	"ooo"
], ['x', ItemID.fint, 0]);

Recipes.addShaped({id: ItemID.fieryC, count: 1, data: 0}, [
	"xox",
	"xxx",
	"xxx"
], ['x', ItemID.fint, 0]);

Recipes.addShaped({id: ItemID.fieryL, count: 1, data: 0}, [
	"xxx",
	"xox",
	"xox"
], ['x', ItemID.fint, 0]);

Recipes.addShaped({id: ItemID.fieryB, count: 1, data: 0}, [
	"ooo",
	"xox",
	"xox"
], ['x', ItemID.fint, 0]);
//var armor all
