

IDRegistry.genItemID("infinity_helmet");
IDRegistry.genItemID("infinity_chestplate");
IDRegistry.genItemID("infinity_leggings");
IDRegistry.genItemID("infinity_boots");
//IDRegistry.genItemID("fff");

Item.createArmorItem("infinity_helmet",
"infinity_helmet \n Armor:§cNull \n §aSkill:§aTrue",{name:"infinity_helmet"},{type: "helmet",armor:null,durability:1111110,texture: "armor/infinity1_1.png"});
Item.createArmorItem("infinity_chestplate",
"infinity_chestplate \n Armor:§cNull \n §aSkill:§aTrue",{name:"infinity_chestplate"},{type: "chestplate",armor:null,durability:1111110,texture: "armor/infinity1_1.png"});
Item.createArmorItem("infinity_leggings",
"infinity_leggings \n Armor:§cNull \n §aSkill:§aTrue",{name:"infinity_leggings"},{type: "leggings",armor:null,durability:11111100,texture: "armor/infinity2_2.png"});
Item.createArmorItem("infinity_boots",
"infinity_boots \n Armor:§cNull \n §aSkill:§aTrue",{name:"infinity_boots"},{type: "boots",armor:null,durability:11111100,texture: "armor/infinity2_2.png"});

Callback.addCallback('EntityHurt', function (attacker, victim, damageValue, damageType, someBool1, someBool2) {
let item = Player.getCarriedItem();
if(victim== Player.get()){
if(item.id==ItemID.cosmSword){
Game.prevent();
  }
 }
 if(victim== Player.get()){
   if(Entity.getArmorSlot(Player.get(), 0).id == ItemID.infinity_helmet &&Entity.getArmorSlot(Player.get(), 1).id == ItemID.infinity_chestplate &&Entity.getArmorSlot(Player.get(), 2).id == ItemID.infinity_leggings &&Entity.getArmorSlot(Player.get(), 3).id == ItemID.infinity_boots){
  Game.prevent();
  }
}});


Callback.addCallback("tick", function(){
    var helmet = Player.getArmorSlot(0);
    var chest = Player.getArmorSlot(1);
    var legs = Player.getArmorSlot(2);
    var boots = Player.getArmorSlot(3);
    var pos = Player.getPosition();
if (helmet.id == ItemID.infinity_helmet && chest.id == ItemID.infinity_chestplate && legs.id == ItemID.infinity_leggings && boots.id == ItemID.infinity_boots) {
    
    Entity.addEffect(Player.get(), Native.PotionEffect.regeneration, 25, 20);
    
   }
});



