IDRegistry.genItemID( "wooden_giant_sword" );
Item.createItem("wooden_giant_sword", "Wooden Sword \n Rarity: Craftable \n Lv: Basic Level \n Skill: No \n Damage: +5", {
         name: "wooden_sword_giant", meta: 0
}, {stack: 1});

ToolAPI.addToolMaterial("oak planks", {durability: 340, level: 1, efficiency: 4, damage: 5, enchantability: 30});
ToolAPI.setTool(ItemID.wooden_giant_sword, "oak planks", ToolType.sword);

Recipes.addShaped({id: ItemID.wooden_giant_sword, count: 1, data: 0}, [
		"oqq",
		"qqq",
		"mqa"
	], ['o', ItemID.page, 0,'m', 280, 0,'q', 5, 0]);





IDRegistry.genItemID("stone_giant_sword");
Item.createItem("stone_giant_sword", "Stone Sword \n Rarity: Craftable \n Lv: Basic Level \n Skill: No \n Damage: +6", {
    name: "stone_sword_giant", meta: 0
}, {stack: 1});

ToolAPI.addToolMaterial("stone", {durability: 700, level: 2, efficiency: 4, damage: 6, enchantability: 30});
ToolAPI.setTool(ItemID.stone_giant_sword, "stone", ToolType.sword);

Recipes.addShaped({id: ItemID.stone_giant_sword, count: 1, data: 0}, [
		"ohh",
		"hhh",
		"vhp"
	], ['v', 280, 0,'h', 4, 0,'o', ItemID.page, 0]);
	


IDRegistry.genItemID("iron_giant_sword");
Item.createItem("iron_giant_sword", "Iron Sword  \n Rarity: Craftable \n Lv: Basic Level \n Skill: No \n Damage: +7", {
name: "iron_sword_giant", meta: 0
}, {stack: 1});

ToolAPI.addToolMaterial("iron ingot", {durability: 970, level: 3, efficiency: 4, damage: 7, enchantability: 30});
ToolAPI.setTool(ItemID.iron_giant_sword, "iron ingot", ToolType.sword);

Recipes.addShaped({id: ItemID.iron_giant_sword, count: 1, data: 0}, [
		"oll",
		"lll",
		"klp"
	], ['k', 280, 0,'l', 265, 0,'o', ItemID.page, 0]);
	


IDRegistry.genItemID("gold_giant_sword");
Item.createItem("gold_giant_sword", "Gold Sword \n Rarity: Craftable \n Lv: Basic Level \n Skill: No \n Damage: +5", {
name: "gold_sword_giant", meta: 0
}, {stack: 1});

ToolAPI.addToolMaterial("gold ingot", {durability: 340, level: 3, efficiency: 4, damage: 5, enchantability: 30});
ToolAPI.setTool(ItemID.gold_giant_sword, "gold ingot", ToolType.sword);

Recipes.addShaped({id: ItemID.gold_giant_sword, count: 1, data: 0}, [
		"oee",
		"eee",
		"yep"
	], ['y', 280, 0,'e', 266, 0,'o', ItemID.page, 0]);
	


IDRegistry.genItemID("diamond_giant_sword");
Item.createItem("diamond_giant_sword", "Diamond Sword \n Rarity: Craftable \n Lv: Basic Level \n Skill: No \n Damage: +11", {
      name: "diamond_sword_giant", meta: 0
}, {stack: 1});

ToolAPI.addToolMaterial("diamond", {durability: 2500, level: 4, efficiency: 4, damage: 11, enchantability: 30});
ToolAPI.setTool(ItemID.diamond_giant_sword, "diamond", ToolType.sword);

Recipes.addShaped({id: ItemID.diamond_giant_sword, count: 1, data: 0}, [
		"opp",
		"ppp",
		"fpx"
	], ['f', 280, 0,'p',264,0,'o', ItemID.page, 0]);



IDRegistry.genItemID("emerald_giant_sword");
Item.createItem("emerald_giant_sword", "Emerald Sword \n Rarity: Craftable \n Lv: Basic Level \n Skill: No \n Damage: +14", {
    name: "emerald_sword_giant", meta: 0
}, {stack: 1});

ToolAPI.addToolMaterial("emerald", {durability: 2600, level: 4, efficiency: 4, damage: 14, enchantability: 30});
ToolAPI.setTool(ItemID.emerald_giant_sword, "emerald", ToolType.sword);

Recipes.addShaped({id: ItemID.emerald_giant_sword, count: 1, data: 0}, [
		"onn",
		"nnn",
		"lnp"
	], ['l', 280, 0,'n',388,0,'o', ItemID.page, 0]);
	


IDRegistry.genItemID("ender_giant_sword");
Item.createItem("ender_giant_sword", "Ender Sword \n Rarity: Craftable \n Lv: Basic Level \n Skill: No \n Damage: +17", {
    name: "ender_sword_giant", meta: 0
}, {stack: 1});

ToolAPI.addToolMaterial("diamond", {durability: 2800, level: 4, efficiency: 4, damage: 17, enchantability: 30});
ToolAPI.setTool(ItemID.ender_giant_sword, "diamond", ToolType.sword);

Recipes.addShaped({id: ItemID.ender_giant_sword, count: 1, data: 0}, [
		"okk",
		"kek",
		"nkp"
	], ['e', 381, 0,'n', 369, 0,'k', 49, 0,'o', ItemID.page, 0]);





IDRegistry.genItemID("livingmetal_giant_sword");
Item.createItem("livingmetal_giant_sword", " Living Metal Sword \n Rarity: Craftable \n Lv: Basic Level \n Skill: No \n Damage: +20", {
     name: "livingmetal_sword_giant", meta: 0
}, {stack: 1});

ToolAPI.addToolMaterial("livingmetal", {durability: 3200, level: 4, efficiency: 4, damage: 20, enchantability: 30});
ToolAPI.setTool(ItemID.livingmetal_giant_sword, "livingmetal", ToolType.sword);

Recipes.addShaped({id: ItemID.livingmetal_giant_sword, count: 1, data: 0}, [
		"oxx",
		"xxx",
		"zxp"
	], ['x', ItemID.livingmetal, 0,'z', 280, 0,'o', ItemID.page, 0]);



	
	
	
	
	IDRegistry.genItemID("quartz_giant_sword");
Item.createItem("quartz_giant_sword", "Quartz Giant Sword \n Rarity: Craftable \n Lv: Basic Level \nSkill: No \n Damage: +6", {
     name: "quartz_giant_sword", meta: 0
}, {stack: 1});

ToolAPI.addToolMaterial("bone", {durability: 500, level: 4, efficiency: 4, damage: 6, enchantability: 30});
ToolAPI.setTool(ItemID.quartz_giant_sword, "bone", ToolType.sword);
	
	Recipes.addShaped({id: ItemID.quartz_giant_sword, count: 1, data: 0}, [
		"ohh",
		"hhh",
		"vhp"
	], ['v', 280, 0,'h', 406, 0,'o', ItemID.page, 0]);
	
	
	
	
	
	IDRegistry.genItemID("netherrack_giant_sword");
Item.createItem("netherrack_giant_sword", "Netherrack Giant Sword \n Rarity: Craftable \n Lv: Basic Level \n Skill: No \n Damage: +6", {
     name: "netherrack_giant_sword", meta: 0
}, {stack: 1});

ToolAPI.addToolMaterial("bone", {durability: 700, level: 4, efficiency: 4, damage: 6, enchantability: 30});
ToolAPI.setTool(ItemID.netherrack_giant_sword, "bone", ToolType.sword);
	
	Recipes.addShaped({id: ItemID.netherrack_giant_sword, count: 1, data: 0}, [
		"ohh",
		"hhh",
		"vhp"
	], ['v', 280, 0,'h', 87, 0,'o', ItemID.page, 0]);
	
	
	
	
	
	IDRegistry.genItemID("bone_giant_sword");
Item.createItem("bone_giant_sword", "Bone Giant Sword \n Rarity: Craftable \n Lv: Basic Level \n Skill: No \n Damage: +13", {
    name: "bone_giant_sword", meta: 0
}, {stack: 1});

ToolAPI.addToolMaterial("bone", {durability: 790, level: 4, efficiency: 4, damage: 13, enchantability: 30});
ToolAPI.setTool(ItemID.bone_giant_sword, "bone", ToolType.sword);
	
	Recipes.addShaped({id: ItemID.bone_giant_sword, count: 1, data: 0}, [
		"ohh",
		"hkh",
		"vhp"
	], ['v', 280, 0,'h', 352, 0,'o', ItemID.page, 0,'k', 397, 0]);
	
	
	
	

	IDRegistry.genItemID("obsidian_giant_sword");
Item.createItem("obsidian_giant_sword", "Obsidian Giant Sword \n Rarity: Craftable \n Lv: Basic Level \n Skill: No \n Damage: +15", {
     name: "obsidian_giant_sword", meta: 0
}, {stack: 1});

ToolAPI.addToolMaterial("bone", {durability: 2000, level: 4, efficiency: 4, damage: 15, enchantability: 30});
ToolAPI.setTool(ItemID.obsidian_giant_sword, "bone", ToolType.sword);

Recipes.addShaped({id: ItemID.obsidian_giant_sword, count: 1, data: 0}, [
		"ohh",
		"hhh",
		"vhp"
	], ['v', 280, 0,'h', 49, 0,'o', ItemID.page, 0]);
	
	
IDRegistry.genItemID("netherite_giant_sword");
Item.createItem("netherite_giant_sword", "Netherite Giant Sword \n Rarity: Craftable \n Lv: Basic Level \n Skill: No \n Damage: +18", {
     name: "netherite_giant_sword", meta: 0
}, {stack: 1});

ToolAPI.addToolMaterial("bone", {durability: 2000, level: 4, efficiency: 4, damage: 18, enchantability: 30});
ToolAPI.setTool(ItemID.netherite_giant_sword, "bone", ToolType.sword);

IDRegistry.genItemID("wither_giant_sword");
Item.createItem("wither_giant_sword", "Wither Giant Sword \n Rarity: Craftable \n Lv: Basic Level \n Skill: No \n Damage: +43", {
     name: "wither_giant_sword", meta: 0
}, {stack: 1});

ToolAPI.addToolMaterial("bone", {durability: 790, level: 4, efficiency: 4, damage: 43, enchantability: 30});
ToolAPI.setTool(ItemID.wither_giant_sword, "bone", ToolType.sword);
	
	
	Recipes.addShaped({id: ItemID.wither_giant_sword, count: 1, data: 0}, [
		"ohh",
		"hkh",
		"vhp"
	], ['h', 49, 0,'v', 280, 0,'o', ItemID.page, 0,'k', 397, 1]);
	
	
	
	
	
	
	
	
	IDRegistry.genItemID("dragon_giant_sword");
Item.createItem("dragon_giant_sword", "Dragon Giant Sword \n Rarity: Craftable \n Lv: Untimed \n Skill: No \n Damage: +70", {
    name: "dragon_giant_sword", meta: 0
}, {stack: 1});

ToolAPI.addToolMaterial("bone", {durability: 3000, level: 4, efficiency: 4, damage: 70, enchantability: 30});
ToolAPI.setTool(ItemID.dragon_giant_sword, "bone", ToolType.sword);
	
	 Recipes.addShaped({id: ItemID.dragon_giant_sword, count: 1, data: 0}, [
		"ohh",
		"akh",
		"vap"
	], ['v', 280, 0,'a', ItemID.livingmetal, 0,'o', ItemID.page, 0,'k', 122, 0,'h', 49, 0]);