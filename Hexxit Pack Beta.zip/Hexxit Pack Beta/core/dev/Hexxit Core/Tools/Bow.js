


ToolAPI.addToolMaterial("infinity_bow", {durability:99999,level:6,efficiency:32747,damage:2147483647,enchantability:999});
IDRegistry.genItemID ("infinity_bow");
Item.createItem("infinity_bow", "§cCosm Bow \n Rarity: Extrеme Crafting \n Mode: Fly \n Lv: the ultimate level \n Damage: 1000",{name:"infinity_bow",meta:0},{stack:1});
Item.setToolRender(ItemID.infinity_bow,true);

Callback.addCallback('ProjectileHitEntity', function (projectile, entity) {
//当抛出的实体击中生物时调用。
let item = Player.getCarriedItem();
if(item.id == ItemID.infinity_bow){
Entity.setHealth(entity, 99999999);
Game.prevent();
}});




Item.registerNoTargetUseFunction("infinity_bow", function(item){
if(item.id == ItemID.infinity_bow){
 let 子弹 = Player.getPosition();
let 力量 = Entity.getLookVector(Player.get());
//发射的实体
var 子弹1 = Entity.spawn(子弹.x,子弹.y,子弹.z,Native.EntityType.IRON_GOLEM);
Entity.setVelocity(子弹1,8*力量.x,8*力量.y,8*力量.z);
}});
