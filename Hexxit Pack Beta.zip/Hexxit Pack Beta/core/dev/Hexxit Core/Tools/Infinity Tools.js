function addUsageChangeCallback(id, replacement) {
	makeSimplifiedCallback(function(name, item) {
		if (name == "ItemUse" && !Entity.getSneaking(Player.get())) return;
		makeReplaceable(item, id, replacement);
	}, "ItemUse", "ItemUseNoTarget");
}

IDRegistry.genItemID("cosmSword");
Item.createItem("cosmSword", "§cSword of the Infinity \n Rarity: Extrеme Crafting \n Mode: Fly \n Lv: Creativity Level \n Damage: §bI§cN§aF§6I§dN§fI§9T§8Y", {
	name: "cosm_sword", meta: 0
}, { stack: 1 });
Item.setEnchantType("cosmSword", 16, 999999999);

ToolAPI.addToolMaterial("cosmsw", {
	durability: 999999999,
	level: 7, efficiency: 6,
	damage: 999999,
	enchantability: 14
});
ToolAPI.setTool(ItemID.cosmSword, "cosmsw", ToolType.sword);
Item.setToolRender(ItemID.cosmSword, true);


//
IDRegistry.genItemID("cosmPickaxe");
Item.createItem("cosmPickaxe", "§cWorld Braker \n Rarity: Extrеme Crafting \n Mode: Destroy \n Lv: Creativity Level \n Damage: 1000", {
	name: "infinity_pickaxe", meta: 0
}, { stack: 1 });
Item.setEnchantType("cosmPickaxe", 18, 10);

ToolAPI.addToolMaterial("cosmpi", {
	durability: 999999999,
	level: 10, efficiency: 10000,
	damage: 1000, enchantability: 14
});
ToolAPI.setTool(ItemID.cosmPickaxe, "cosmpi", ToolType.pickaxe);
Item.setToolRender(ItemID.cosmPickaxe, true);
//


IDRegistry.genItemID("cosmhammer");
Item.createItem("cosmhammer", "§cinfinity hammer \n Rarity: Extrеme Crafting \n Mode: Destroy&9×9 \n Lv: Creativity Level \n Damage: 1000", {
	name: "infinity_hammer", meta: 0
}, { stack: 1 });
ToolAPI.setTool(ItemID.cosmhammer, "cosmpi", ToolType.pickaxe);
Item.setToolRender(ItemID.cosmhammer, true);



Callback.addCallback("DestroyBlock", function(coords, block, player) {
	if (Player.getCarriedItem().id == ItemID.cosmhammer) {
		var side = coords.side, x = 8, y = 9, z = 7;
		if (side == 4 || side == 5) x = 0;
		if (side == 1 || side == 6) y = 0;
		if (side == 2 || side == 3) z = 0;
		for (var xx = coords.x - x; xx <= coords.x + x; xx++) {
			for (var yy = coords.y - y; yy <= coords.y + y; yy++) {
				for (var zz = coords.z - z; zz <= coords.z + z; zz++) {
					if (World.getBlockID(xx, yy, zz) !== 7) {
						World.setBlock(xx, yy, zz, 0);
					}
				}
			}
		}
	}
});

IDRegistry.genItemID("cosmShovel");
Item.createItem("cosmShovel", "§cPlanet Eater \n Rarity: Extrеme Crafting \n Lv: Creativity Level \n Damage: 1000", {
	name: "infinity_shovel", meta: 0
}, { stack: 1 });

ToolAPI.addToolMaterial("cosmsh", {
	durability: 999999999,
	level: 8, efficiency: 1000,
	damage: 1000,
	enchantability: 14
});
ToolAPI.setTool(ItemID.cosmShovel, "cosmsh", ToolType.shovel);
Item.setToolRender(ItemID.cosmShovel, true);

IDRegistry.genItemID("cosmdes");
Item.createItem("cosmdes", "§cdestroyer \n Rarity: Extrеme Crafting \n Mode: Destroy&9×9 \n Lv: Creativity Level \n Damage: 1000", {
	name: "infinity_destroyer", meta: 0
}, { stack: 1 });
ToolAPI.setTool(ItemID.cosmdes, "cosmsh", ToolType.pickaxe);
Item.setToolRender(ItemID.cosmdes, true);



var DESTROYER_BLOCKS = [14, 15, 16, 21, 56, 73, 129, 49, 7];
DESTROYER_BLOCKS.hasId = function(id) {
	return this.indexOf(id) != -1;
};

Callback.addCallback("DestroyBlock", function(coords, block, player) {
	if (Player.getCarriedItem().id == ItemID.cosmdes) {
		var side = coords.side, x = 8, y = 9, z = 7;
		if (side == 4 || side == 5) x = 0;
		if (side == 1 || side == 6) y = 0;
		if (side == 2 || side == 3) z = 0;
		for (var xx = coords.x - x; xx <= coords.x + x; xx++) {
			for (var yy = coords.y - y; yy <= coords.y + y; yy++) {
				for (var zz = coords.z - z; zz <= coords.z + z; zz++) {
					if (!DESTROYER_BLOCKS.hasId(World.getBlockID(xx, yy, zz))) {
						World.setBlock(xx, yy, zz, 0);
					}
				}
			}
		}
	}
});

IDRegistry.genItemID("cosmAxe");
Item.createItem("cosmAxe", "§cNature's Ruin \n Rarity: Extrеme Crafting \n Lv: Creativity Level \n Damage: 1000", {
	name: "infinity_axe", meta: 0
}, { stack: 1 });

ToolAPI.addToolMaterial("cosmaxe", {
	durability: 999999999,
	level: 9, efficiency: 1000,
	damage: 1000, enchantability: 14
});
ToolAPI.setTool(ItemID.cosmAxe, "cosmaxe", ToolType.axe);
Item.setToolRender(ItemID.cosmAxe, true);
//
Block.setDestroyTime(ItemID.cosmSword, 3);
//



