IDRegistry.genItemID("bag_skill");
Item.createItem("bag_skill", "§bSkill Bag \n Drop: Skill Item \n §6Legend: 7/100 \n §dUntimed: 5/100", {name: "bag"});

function dropBag(coords){
 if (!Math.floor(Math.random()*10)) World.drop(coords.x, coords.y, coords.z, ItemID.bag_skill, 1, 0);
}

var TREASURE = [
    {chance: 70, id: ItemID.bag_skill, data: 0},
    
    {chance: 1, id: ItemID.fire_skill_untimed, data: 0},
    {chance: 1, id: ItemID.ice_skill_untimed, data: 0},
    
    
    {chance: 2, id: ItemID.fire_skill_legend, data: 0},
    {chance: 2, id: ItemID.ice_skill_legend, data: 0},
    

    
    
];

function getTreasureDropItem(){
    var total = 0;
    for (var i in TREASURE){
        total += TREASURE[i].chance;
    }
    var random = Math.random() * total * 1.4;
    var current = 0;
    for (var i in TREASURE){
        var drop = TREASURE[i];
        if (current < random && current + drop.chance > random){
            return drop;
        }
        current += drop.chance;
    }

    return {id: 0, data: 0};
}

Item.registerUseFunction("bag_skill", function(coords, item, block){
    var drop = getTreasureDropItem();
    World.drop(coords.relative.x + 0.5, coords.relative.y + 0.1, coords.relative.z + 0.5, drop.id, 1, drop.data);
    item.count--;
    if(!item.count){item.id = 0;}
    Player.setCarriedItem(item.id, item.count, 0);
});
Callback.addCallback("EntityDeath", function(entity){
var E = Entity.getType(entity);
var coords = Entity.getPosition(entity);
var Q = Math.round(Math.random() * 9);
 if(E == 34 || E == 32 || E == 47 || E == 38 || E == 33 || E == 35 || E == 40 || E == 44 ){
   if(Q == 8){
      World.drop(coords.x, coords.y, coords.z, ItemID.bag_skill, 1, 0);
}
}
});

