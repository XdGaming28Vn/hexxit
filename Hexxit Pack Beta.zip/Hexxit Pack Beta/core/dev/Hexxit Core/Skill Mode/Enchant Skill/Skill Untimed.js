IDRegistry.genItemID("fire_skill_untimed");
Item.createItem("fire_skill_untimed", "§dSkill Fire \n Rarity: Bag \n Chance: 5/100 \n Skill: Fire \n Lv: untimed \n Attack: +5 \n Tools: Sword", {name: "skill_fire", meta: 0}, {stack: 1}, {inCreative: false})

IDRegistry.genItemID("ice_skill_untimed");
Item.createItem("ice_skill_untimed", "§dSkill Ice \n Rarity: Bag \n Chance: 5/100 \n Skill: Ice \n Lv: untimed \n Attack: +5 \n Tools: Sword", {name: "skill_ice", meta: 0}, {stack: 1}, {inCreative: false})


                                 //function
//fire
Callback.addCallback("PlayerAttack", function (player, victim) { 
var item = Entity.getCarriedItem(player);
if(item.id==ItemID.fire_skill_untimed){
Entity.setFire(victim, 180, true);
} 
});

Item.registerUseFunction("fire_skill_untimed", function(coords, item, block, player)
{
let b = BlockSource.getDefaultForActor(player);
if(b.getBlock(coords.x, coords.y + 1, coords.z).id==0){
b.setBlock(coords.x, coords.y + 1, coords.z, 51, 0);
}
}
);

//ice
Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.ice_skill_untimed){ 
Entity.addEffect(victim, Native.PotionEffect.movementSlowdown, 30, 30, true, true); 
}
});

Item.registerUseFunction("ice_skill_untimed", function(coords, item, block, player)
{
let c = BlockSource.getDefaultForActor(player);
if(c.getBlock(coords.x, coords.y + 1, coords.z).id==0){
c.setBlock(coords.x, coords.y + 1, coords.z, 78, 0);
}
}
);

//lightning










                               //glint
Item.setGlint("ice_skill_untimed", true);
Item.setGlint("fire_skill_untimed", true);
                               
                               
                               
                               
                               
           
                  