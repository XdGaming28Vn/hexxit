//{∆}
UIbuttons.setButton(ItemID.infinity_chestplate, "button_speed_lv_untimed");
UIbuttons.setButton(ItemID.fieryC, "button_skill_resistance");
UIbuttons.setButton(ItemID.cosmSword, "button_skill_sword");


//<\>


UIbuttons.setButton(ItemID.sageChestplate, "button_sagearmor");
UIbuttons.setButton(ItemID.scaleChestplate, "button_scalearmor");
UIbuttons.setButton(ItemID.thiefChestplate, "button_thiefarmor");
UIbuttons.setButton(ItemID.tribalChestplate, "button_tribalarmor");





