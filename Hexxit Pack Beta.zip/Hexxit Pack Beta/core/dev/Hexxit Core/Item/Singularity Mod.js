IDRegistry.genItemID("infinityingot");
Item.createItem("infinityingot", "infinity ingot ", {name: "ifi", meta: 0}, {stack: 64})
IDRegistry.genItemID("bo1");
Item.createItem("bo1", " singularity gold ", {name: "sin1", meta: 0}, {stack: 64})
IDRegistry.genItemID("bo2");
Item.createItem("bo2", " singularity iron", {name: "sin2", meta: 0}, {stack: 64})
IDRegistry.genItemID("bo3");
Item.createItem("bo3", " singularity lapis ", {name: "sin3", meta: 0}, {stack: 64})
IDRegistry.genItemID("bo4");
Item.createItem("bo4", " singularity emerald ", {name: "sin4", meta: 0}, {stack: 64})
IDRegistry.genItemID("bo5");
Item.createItem("bo5", " singularity redstone ", {name: "sin5", meta: 0}, {stack: 64})
IDRegistry.genItemID("bo6");
Item.createItem("bo6", " singularity diamond Hexical  ", {name: "sin6", meta: 0}, {stack: 64})
IDRegistry.genItemID("bo7");
Item.createItem("bo7", " singularity diamond  ", {name: "sin7", meta: 0}, {stack: 64})
IDRegistry.genItemID("bo8");
Item.createItem("bo8", " singularity  ", {name: "sin8", meta: 0}, {stack: 64})
IDRegistry.genItemID("bo9");
Item.createItem("bo9", "  neutron ingot  ", {name: "sin9", meta: 0}, {stack: 64})
//craft

Recipes.addShaped({id: ItemID.infinityingot, count: 1, data: 0}, [
		"bbb",
		"ooo",
		"bbb"
	], ['b', ItemID.bo9, 0,'o', ItemID.bo8, 0]);

Recipes.addShaped({id: ItemID.bo9, count: 2, data: 0}, [
		"bbb",
		"ooo",
		"bbb"
	], ['b', 49, 0,'o', 265, 0]);


Recipes.addShaped({id: ItemID.bo1, count: 1, data: 0}, [
	"xxx",
	"xxx",
	"xxx"
], ['g', ItemID.bo7, 0, 'x', 41, 0]);

Recipes.addShaped({id: ItemID.bo2, count: 1, data: 0}, [
	"xxx",
	"xxx",
	"xxx"
], ['g', ItemID.bo3, 0, 'x', 42, 0]);

Recipes.addShaped({id: ItemID.bo3, count: 1, data: 0}, [
	"xxx",
	"xxx",
	"xxx"
], ['x', 22, 0]);

Recipes.addShaped({id: ItemID.bo4, count: 1, data: 0}, [
	"xxx",
	"xxx",
	"xxx"
], ['x', 133, 0]);

Recipes.addShaped({id: ItemID.bo5, count: 1, data: 0}, [
	"xxx",
	"xxx",
	"xxx"
], ['x', 152, 0]);

Recipes.addShaped({id: ItemID.bo8, count: 1, data: 0}, [
	"abc",
	"nhx",
	"kmm"
], ['a', ItemID.bo1, 0,'b', ItemID.bo2, 0,'c', ItemID.bo3, 0,'n', ItemID.bo4, 0,'h', ItemID.bo5, 0,'x', ItemID.bo6, 0,'k', ItemID.bo7, 0]);

Recipes.addShaped({id: ItemID.bo6, count: 1, data: 0}, [
	"xxx",
	"xxx",
	"xxx"
], ['x', ItemID.diamondHexical, 0]);

Recipes.addShaped({id: ItemID.bo7, count: 1, data: 0}, [
	"xxx",
	"xxx",
	"xxx"
], ['x', 57, 0]);


