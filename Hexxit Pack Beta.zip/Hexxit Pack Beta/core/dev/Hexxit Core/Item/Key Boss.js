IDRegistry.genItemID("keyNaga");
Item.createItem("keyNaga", "Key Naga Boss", {name: "key_boss", meta: 0}, {stack: 1})

	 IDRegistry.genItemID("keyHydra");
Item.createItem("keyHydra", "Key Hydra Boss", {name: "key_boss", meta: 0}, {stack: 1})

	 IDRegistry.genItemID("keyLich");
Item.createItem("keyLich", "Key Lich Boss", {name: "key_boss", meta: 0}, {stack: 1})

	 IDRegistry.genItemID("keyMinoshroom");
Item.createItem("keyMinoshroom", "Key Minoshroom Boss", {name: "key_boss", meta: 0}, {stack: 1})

	 IDRegistry.genItemID("keyUghast");
Item.createItem("keyUghast", "Key Ughast Boss", {name: "key_boss", meta: 0}, {stack: 1})

IDRegistry.genItemID("keySnowQueen");
Item.createItem("keySnowQueen", "Key Snow Queen Boss", {name: "key_boss", meta: 0}, {stack: 1})



Item.setGlint("keyNaga", true);
Item.setGlint("keyHydra", true);
Item.setGlint("keyLich", true);
Item.setGlint("keyMinoshroom", true);
Item.setGlint("keyUghast", true);
Item.setGlint("keySnowQueen", true);

	