IDRegistry.genItemID( "wooden_giant_sword_ice_legend" );
Item.createItem("wooden_giant_sword_ice_legend", "§6Wooden Giant Sword \n Rarity: Craftable \n Lv: Legend \n Skill: Ice Legend \n Damage: +8", {
         name: "wooden_sword_giant", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("oak planks", {durability: 340, level: 1, efficiency: 4, damage: 8, enchantability: 30});
ToolAPI.setTool(ItemID.wooden_giant_sword_ice_legend, "oak planks", ToolType.sword);





IDRegistry.genItemID( "cobblestone_giant_sword_ice_legend" );
Item.createItem("cobblestone_giant_sword_ice_legend", "§6Stone Giant Sword \n Rarity: Craftable \n Lv: Legend \n Skill: Ice Legend \n Damage: +9", {
    name: "stone_sword_giant", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("stone", {durability: 700, level: 2, efficiency: 4, damage: 9, enchantability: 30});
ToolAPI.setTool(ItemID.cobblestone_giant_sword_ice_legend, "stone", ToolType.sword);


	


IDRegistry.genItemID( "iron_giant_sword_ice_legend" );
Item.createItem("iron_giant_sword_ice_legend", "§6Iron Giant Sword  \n Rarity: Craftable \n Lv: Legend \n Skill: Ice Legend \n Damage: +10", {
name: "iron_sword_giant", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("iron ingot", {durability: 970, level: 3, efficiency: 4, damage: 10, enchantability: 30});
ToolAPI.setTool(ItemID.iron_giant_sword_ice_legend, "iron ingot", ToolType.sword);




IDRegistry.genItemID( "gold_giant_sword_ice_legend" );
Item.createItem("gold_giant_sword_ice_legend", "§6Gold Giant Sword \n Rarity: Craftable \n Lv: Legend \n Skill: Ice Legend \n Damage: +8", {
name: "gold_sword_giant", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("gold ingot", {durability: 340, level: 3, efficiency: 4, damage: 8, enchantability: 30});
ToolAPI.setTool(ItemID.gold_giant_sword_ice_legend, "gold ingot", ToolType.sword);


	


IDRegistry.genItemID( "diamond_giant_sword_ice_legend" );
Item.createItem("diamond_giant_sword_ice_legend", "§6Diamond Giant Sword \n Rarity: Craftable \n Lv: Legend \n Skill: Ice Legend \n Damage: +14", {
      name: "diamond_sword_giant", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("diamond", {durability: 2500, level: 4, efficiency: 4, damage: 14, enchantability: 30});
ToolAPI.setTool(ItemID.diamond_giant_sword_ice_legend, "diamond", ToolType.sword);




IDRegistry.genItemID( "emerald_giant_sword_ice_legend" );
Item.createItem("emerald_giant_sword_ice_legend", "§6Emeral Giant Sword \n Rarity: Craftable \n Lv: Legend \n Skill: Ice Legend \n Damage: +17", {
    name: "emerald_sword_giant", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("emerald", {durability: 2600, level: 4, efficiency: 4, damage: 17, enchantability: 30});
ToolAPI.setTool(ItemID.emerald_giant_sword_ice_legend, "emerald", ToolType.sword);


	


IDRegistry.genItemID( "ender_giant_sword_ice_legend" );
Item.createItem("ender_giant_sword_ice_legend", "§6Ender Giant Sword \n Rarity: Craftable \n Lv: Legend \n Skill: Ice Legend \n Damage: +20", {
    name: "ender_sword_giant", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("diamond", {durability: 2800, level: 4, efficiency: 4, damage: 20, enchantability: 30});
ToolAPI.setTool(ItemID.ender_giant_sword_ice_legend, "diamond", ToolType.sword);





IDRegistry.genItemID( "livingmetal_giant_sword_ice_legend" );
Item.createItem("livingmetal_giant_sword_ice_legend", " §6Living Metal Giant Sword \n Rarity: Craftable \n Lv: Legend \n Skill: Ice Legend \n Damage: +23", {
     name: "livingmetal_sword_giant", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("livingmetal", {durability: 3200, level: 4, efficiency: 4, damage: 23, enchantability: 30});
ToolAPI.setTool(ItemID.livingmetal_giant_sword_ice_legend, "livingmetal", ToolType.sword);




	
	
	
	
	IDRegistry.genItemID( "quartz_giant_sword_ice_legend" );
Item.createItem("quartz_giant_sword_ice_legend", "§6Quartz Giant Sword \n Rarity: Craftable \n Lv: Legend \nSkill: Ice Legend \n Damage: +9", {
     name: "quartz_giant_sword", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("bone", {durability: 500, level: 4, efficiency: 4, damage: 9, enchantability: 30});
ToolAPI.setTool(ItemID.quartz_giant_sword_ice_legend, "bone", ToolType.sword);
	
	
	
	
	
	
	
	IDRegistry.genItemID( "netherrack_giant_sword_ice_legend" );
Item.createItem("netherrack_giant_sword_ice_legend", "§6Netherrack Giant Sword \n Rarity: Craftable \n Lv: Legend \n Skill: Ice Legend \n Damage: +9", {
     name: "netherrack_giant_sword", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("bone", {durability: 700, level: 4, efficiency: 4, damage: 9, enchantability: 30});
ToolAPI.setTool(ItemID.netherrack_giant_sword_ice_legend, "bone", ToolType.sword);
	
	
	
	
	
	
	IDRegistry.genItemID( "bone_giant_sword_ice_legend" );
Item.createItem("bone_giant_sword_ice_legend", "§6Bone Giant Sword \n Rarity: Craftable \n Lv: Legend \n Skill: Ice Legend \n Damage: +16", {
    name: "bone_giant_sword", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("bone", {durability: 790, level: 4, efficiency: 4, damage: 16, enchantability: 30});
ToolAPI.setTool(ItemID.bone_giant_sword_ice_legend, "bone", ToolType.sword);
	
	
	
	
	

	IDRegistry.genItemID( "obsidian_giant_sword_ice_legend" );
Item.createItem("obsidian_giant_sword_ice_legend", "§6Obsidian Giant Sword \n Rarity: Craftable \n Lv: Legend \n Skill: Ice Legend \n Damage: +18", {
     name: "obsidian_giant_sword", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("bone", {durability: 2000, level: 4, efficiency: 4, damage: 18, enchantability: 30});
ToolAPI.setTool(ItemID.obsidian_giant_sword_ice_legend, "bone", ToolType.sword);


	
	
IDRegistry.genItemID( "netherite_giant_sword_ice_legend" );
Item.createItem("netherite_giant_sword_ice_legend", "§6Netherite Giant Sword \n Rarity: Craftable \n Lv: Legend \n Skill: Ice Legend \n Damage: +21", {
     name: "netherite_giant_sword", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("bone", {durability: 2000, level: 4, efficiency: 4, damage: 21, enchantability: 30});
ToolAPI.setTool(ItemID.netherite_giant_sword_ice_legend, "bone", ToolType.sword);

IDRegistry.genItemID( "wither_giant_sword_ice_legend" );
Item.createItem("wither_giant_sword_ice_legend", "§6Wither Giant Sword \n Rarity: Craftable \n Lv: Legend \n Skill: Ice Legend \n Damage: +46", {
     name: "wither_giant_sword", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("bone", {durability: 790, level: 4, efficiency: 4, damage: 46, enchantability: 30});
ToolAPI.setTool(ItemID.wither_giant_sword_ice_legend, "bone", ToolType.sword);
	
	
	
	
	
	
	
	
	
	
	IDRegistry.genItemID( "dragon_giant_sword_ice_legend" );
Item.createItem("dragon_giant_sword_ice_legend", "§6Dragon Giant Sword \n Rarity: Craftable \n Lv: Legend \n Skill: Ice Legend \n Damage: +73", {
    name: "dragon_giant_sword", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("bone", {durability: 3000, level: 4, efficiency: 4, damage: 73, enchantability: 30});
ToolAPI.setTool(ItemID.dragon_giant_sword_ice_legend, "bone", ToolType.sword);
	
	 // giấy bạc
	
	
	 Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.wooden_giant_sword_ice_legend){ 
Entity.addEffect(victim, Native.PotionEffect.movementSlowdown, 20, 20, true, true); 
}
});




Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.cobblestone_giant_sword_ice_legend){ 
Entity.addEffect(victim, Native.PotionEffect.movementSlowdown, 20, 20, true, true); 
}
});
	
	
	
	
	Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.iron_giant_sword_ice_legend){ 
Entity.addEffect(victim, Native.PotionEffect.movementSlowdown, 20, 20, true, true); 
}
});
	
	
	 Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.gold_giant_sword_ice_legend){ 
Entity.addEffect(victim, Native.PotionEffect.movementSlowdown, 20, 20, true, true); 
}
});
	
	
	
	 Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.diamond_giant_sword_ice_legend){ 
Entity.addEffect(victim, Native.PotionEffect.movementSlowdown, 20, 20, true, true); 
}
});
	
	
	
	 Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.emerald_giant_sword_ice_legend){ 
Entity.addEffect(victim, Native.PotionEffect.movementSlowdown, 20, 20, true, true); 
}
});
	
	
	
	 Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.ender_giant_sword_ice_legend){ 
Entity.addEffect(victim, Native.PotionEffect.movementSlowdown, 20, 20, true, true); 
}
});
	
	
	
	 Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.livingmetal_giant_sword_ice_legend){ 
Entity.addEffect(victim, Native.PotionEffect.movementSlowdown, 20, 20, true, true); 
}
});
	
	
	
	 Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.quartz_giant_sword_ice_legend){ 
Entity.addEffect(victim, Native.PotionEffect.movementSlowdown, 20, 20, true, true); 
}
});
	
	
	
	 Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.netherrack_giant_sword_ice_legend){ 
Entity.addEffect(victim, Native.PotionEffect.movementSlowdown, 20, 20, true, true); 
}
});
	
	
	
	 Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.bone_giant_sword_ice_legend){ 
Entity.addEffect(victim, Native.PotionEffect.movementSlowdown, 20, 20, true, true); 
}
});
	
	
	
	 Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.obsidian_giant_sword_ice_legend){ 
Entity.addEffect(victim, Native.PotionEffect.movementSlowdown, 20, 20, true, true); 
}
});
	

	 Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.netherite_giant_sword_ice_legend){ 
Entity.addEffect(victim, Native.PotionEffect.movementSlowdown, 20, 20, true, true); 
}
});
	
	
	
	 Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.wither_giant_sword_ice_legend){ 
Entity.addEffect(victim, Native.PotionEffect.movementSlowdown, 20, 20, true, true); 
}
});
	
	
	
	 Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.dragon_giant_sword_ice_legend){ 
Entity.addEffect(victim, Native.PotionEffect.movementSlowdown, 20, 20, true, true); 
}
});
	
	
	
	
	
	
	
	