IDRegistry.genItemID( "wooden_giant_sword_ice_untimed" );
Item.createItem("wooden_giant_sword_ice_untimed", "§dWooden Giant Sword \n Rarity: Craftable \n Lv: Untimed \n Skill: Ice Untimed \n Damage: +10", {
         name: "wooden_sword_giant", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("oak planks", {durability: 340, level: 1, efficiency: 4, damage: 10, enchantability: 30});
ToolAPI.setTool(ItemID.wooden_giant_sword_ice_untimed, "oak planks", ToolType.sword);





IDRegistry.genItemID( "stone_giant_sword_ice_untimed" );
Item.createItem("stone_giant_sword_ice_untimed", "§dStone Giant Sword \n Rarity: Craftable \n Lv: Untimed \n Skill: Ice Untimed \n Damage: +11", {
    name: "stone_sword_giant", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("stone", {durability: 700, level: 2, efficiency: 4, damage: 11, enchantability: 30});
ToolAPI.setTool(ItemID.stone_giant_sword_ice_untimed, "stone", ToolType.sword);


	


IDRegistry.genItemID( "iron_giant_sword_ice_untimed" );
Item.createItem("iron_giant_sword_ice_untimed", "§dIron Giant Sword  \n Rarity: Craftable \n Lv: Untimed \n Skill: Ice Untimed \n Damage: +12", {
name: "iron_sword_giant", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("iron ingot", {durability: 970, level: 3, efficiency: 4, damage: 12, enchantability: 30});
ToolAPI.setTool(ItemID.iron_giant_sword_ice_untimed, "iron ingot", ToolType.sword);




IDRegistry.genItemID( "gold_giant_sword_ice_untimed" );
Item.createItem("gold_giant_sword_ice_untimed", "§dGold Giant Sword \n Rarity: Craftable \n Lv: Untimed \n Skill: Ice Untimed \n Damage: +10", {
name: "gold_sword_giant", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("gold ingot", {durability: 340, level: 3, efficiency: 4, damage: 10, enchantability: 30});
ToolAPI.setTool(ItemID.gold_giant_sword_ice_untimed, "gold ingot", ToolType.sword);


	


IDRegistry.genItemID( "diamond_giant_sword_ice_untimed" );
Item.createItem("diamond_giant_sword_ice_untimed", "§dDiamond Giant Sword \n Rarity: Craftable \n Lv: Untimed \n Skill: Ice Untimed \n Damage: +16", {
      name: "diamond_sword_giant", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("diamond", {durability: 2500, level: 4, efficiency: 4, damage: 16, enchantability: 30});
ToolAPI.setTool(ItemID.diamond_giant_sword_ice_untimed, "diamond", ToolType.sword);




IDRegistry.genItemID( "emerald_giant_sword_ice_untimed" );
Item.createItem("emerald_giant_sword_ice_untimed", "§dEmeral Giant Sword \n Rarity: Craftable \n Lv: Untimed \n Skill: Ice Untimed \n Damage: +19", {
    name: "emerald_sword_giant", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("emerald", {durability: 2600, level: 4, efficiency: 4, damage: 19, enchantability: 30});
ToolAPI.setTool(ItemID.emerald_giant_sword_ice_untimed, "emerald", ToolType.sword);


	


IDRegistry.genItemID( "ender_giant_sword_ice_untimed" );
Item.createItem("ender_giant_sword_ice_untimed", "§dEnder Giant Sword \n Rarity: Craftable \n Lv: Untimed \n Skill: Ice Untimed \n Damage: +22", {
    name: "ender_sword_giant", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("diamond", {durability: 2800, level: 4, efficiency: 4, damage: 22, enchantability: 30});
ToolAPI.setTool(ItemID.ender_giant_sword_ice_untimed, "diamond", ToolType.sword);





IDRegistry.genItemID( "livingmetal_giant_sword_ice_untimed" );
Item.createItem("livingmetal_giant_sword_ice_untimed", " §dLiving Metal Giant Sword \n Rarity: Craftable \n Lv: Untimed \n Skill: Ice Untimed \n Damage: +25", {
     name: "livingmetal_sword_giant", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("livingmetal", {durability: 3200, level: 4, efficiency: 4, damage: 25, enchantability: 30});
ToolAPI.setTool(ItemID.livingmetal_giant_sword_ice_untimed, "livingmetal", ToolType.sword);




	
	
	
	
	IDRegistry.genItemID( "quartz_giant_sword_ice_untimed" );
Item.createItem("quartz_giant_sword_ice_untimed", "§dQuartz Giant Sword \n Rarity: Craftable \n Lv: Untimed \nSkill: Ice Untimed \n Damage: +11", {
     name: "quartz_giant_sword", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("bone", {durability: 500, level: 4, efficiency: 4, damage: 11, enchantability: 30});
ToolAPI.setTool(ItemID.quartz_giant_sword_ice_untimed, "bone", ToolType.sword);
	
	
	
	
	
	
	
	IDRegistry.genItemID( "netherrack_giant_sword_ice_untimed" );
Item.createItem("netherrack_giant_sword_ice_untimed", "§dNetherrack Giant Sword \n Rarity: Craftable \n Lv: Untimed \n Skill: Ice Untimed \n Damage: +11", {
     name: "netherrack_giant_sword", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("bone", {durability: 700, level: 4, efficiency: 4, damage: 11, enchantability: 30});
ToolAPI.setTool(ItemID.netherrack_giant_sword_ice_untimed, "bone", ToolType.sword);
	
	
	
	
	
	
	IDRegistry.genItemID( "bone_giant_sword_ice_untimed" );
Item.createItem("bone_giant_sword_ice_untimed", "§dBone Giant Sword \n Rarity: Craftable \n Lv: Untimed \n Skill: Ice Untimed \n Damage: +18", {
    name: "bone_giant_sword", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("bone", {durability: 790, level: 4, efficiency: 4, damage: 18, enchantability: 30});
ToolAPI.setTool(ItemID.bone_giant_sword_ice_untimed, "bone", ToolType.sword);
	
	
	
	
	

	IDRegistry.genItemID( "obsidian_giant_sword_ice_untimed" );
Item.createItem("obsidian_giant_sword_ice_untimed", "§dObsidian Giant Sword \n Rarity: Craftable \n Lv: Untimed \n Skill: Ice Untimed \n Damage: +20", {
     name: "obsidian_giant_sword", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("bone", {durability: 2000, level: 4, efficiency: 4, damage: 20, enchantability: 30});
ToolAPI.setTool(ItemID.obsidian_giant_sword_ice_untimed, "bone", ToolType.sword);


	
	
IDRegistry.genItemID( "netherite_giant_sword_ice_untimed" );
Item.createItem("netherite_giant_sword_ice_untimed", "§dNetherite Giant Sword \n Rarity: Craftable \n Lv: Untimed \n Skill: Ice Untimed \n Damage: +23", {
     name: "netherite_giant_sword", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("bone", {durability: 2000, level: 4, efficiency: 4, damage: 23, enchantability: 30});
ToolAPI.setTool(ItemID.netherite_giant_sword_ice_untimed, "bone", ToolType.sword);

IDRegistry.genItemID( "wither_giant_sword_ice_untimed" );
Item.createItem("wither_giant_sword_ice_untimed", "§dWither Giant Sword \n Rarity: Craftable \n Lv: Untimed \n Skill: Ice Untimed \n Damage: +49", {
     name: "wither_giant_sword", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("bone", {durability: 790, level: 4, efficiency: 4, damage: 49, enchantability: 30});
ToolAPI.setTool(ItemID.wither_giant_sword_ice_untimed, "bone", ToolType.sword);
	
	
	
	
	
	
	
	
	
	
	IDRegistry.genItemID( "dragon_giant_sword_ice_untimed" );
Item.createItem("dragon_giant_sword_ice_untimed", "§dDragon Giant Sword \n Rarity: Craftable \n Lv: Untimed \n Skill: Ice Untimed \n Damage: +75", {
    name: "dragon_giant_sword", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("bone", {durability: 3000, level: 4, efficiency: 4, damage: 75, enchantability: 30});
ToolAPI.setTool(ItemID.dragon_giant_sword_ice_untimed, "bone", ToolType.sword);
	
	 // giấy bạc
	
	
	 Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.wooden_giant_sword_ice_untimed){ 
Entity.addEffect(victim, Native.PotionEffect.movementSlowdown, 100, 100, true, true); 
}
});




Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.stone_giant_sword_ice_untimed){ 
Entity.addEffect(victim, Native.PotionEffect.movementSlowdown, 100, 100, true, true); 
}
});
	
	
	
	
	Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.iron_giant_sword_ice_untimed){ 
Entity.addEffect(victim, Native.PotionEffect.movementSlowdown, 100, 100, true, true); 
}
});
	
	
	 Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.gold_giant_sword_ice_untimed){ 
Entity.addEffect(victim, Native.PotionEffect.movementSlowdown, 100, 100, true, true); 
}
});
	
	
	
	 Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.diamond_giant_sword_ice_untimed){ 
Entity.addEffect(victim, Native.PotionEffect.movementSlowdown, 100, 100, true, true); 
}
});
	
	
	
	 Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.emerald_giant_sword_ice_untimed){ 
Entity.addEffect(victim, Native.PotionEffect.movementSlowdown, 100, 100, true, true); 
}
});
	
	
	
	 Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.ender_giant_sword_ice_untimed){ 
Entity.addEffect(victim, Native.PotionEffect.movementSlowdown, 100, 100, true, true); 
}
});
	
	
	
	 Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.livingmetal_giant_sword_ice_untimed){ 
Entity.addEffect(victim, Native.PotionEffect.movementSlowdown, 100, 100, true, true); 
}
});
	
	
	
	 Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.quartz_giant_sword_ice_untimed){ 
Entity.addEffect(victim, Native.PotionEffect.movementSlowdown, 100, 100, true, true); 
}
});
	
	
	
	 Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.netherrack_giant_sword_ice_untimed){ 
Entity.addEffect(victim, Native.PotionEffect.movementSlowdown, 100, 100, true, true); 
}
});
	
	
	
	 Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.bone_giant_sword_ice_untimed){ 
Entity.addEffect(victim, Native.PotionEffect.movementSlowdown, 100, 100, true, true); 
}
});
	
	
	
	 Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.obsidian_giant_sword_ice_untimed){ 
Entity.addEffect(victim, Native.PotionEffect.movementSlowdown, 100, 100, true, true); 
}
});
	

	 Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.netherite_giant_sword_ice_untimed){ 
Entity.addEffect(victim, Native.PotionEffect.movementSlowdown, 100, 100, true, true); 
}
});
	
	
	
	 Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.wither_giant_sword_ice_untimed){ 
Entity.addEffect(victim, Native.PotionEffect.movementSlowdown, 100, 100, true, true); 
}
});
	
	
	
	 Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.dragon_giant_sword_ice_untimed){ 
Entity.addEffect(victim, Native.PotionEffect.movementSlowdown, 100, 100, true, true); 
}
});
	

