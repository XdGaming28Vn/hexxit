
IMPORT("RecipeTileEntityLib");
IMPORT("ToolLib");
IMPORT("PortalUtils");
IMPORT("TileRender");
IMPORT("VanillaRecipe");
VanillaRecipe.setResourcePath(__dir__ + "assets/textures/");



alert("Hexxit Pack 3.6 By XD GAMING \n Youtube XD GAMING");


