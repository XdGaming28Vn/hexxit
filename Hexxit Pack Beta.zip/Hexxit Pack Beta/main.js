/*
BUILD INFO:
  dir: core/dev
  target: main.js
  files: 52
*/



// file: IMPORT LIB.Js

alert("Hexxit Pack 3.6 By XD GAMING \n Youtube XD GAMING");



importLib("DefenseCore", "*");
IMPORT("RecipeTileEntityLib");
IMPORT("ToolLib");
IMPORT("PortalUtils");
IMPORT("TileRender");
IMPORT("VanillaRecipe");
VanillaRecipe.setResourcePath(__dir__ + "assets/textures/");






// file: Mod API/TileRender.js




let BlockSide = Native.BlockSide;
const Color = android.graphics.Color;

function randomInt(min, max){ 
return Math.floor(Math.random() * (max - min + 1)) + min; 
}


let TileRender = {
    setLogTypeRender: function (blockID) {
        Callback.addCallback("ItemUse", function (coords, item, block) {
            let place = coords.relative;
            let tile1 = World.getBlock(place.x, place.y, place.z);
            if (World.cantileBeReplaced(tile1.id, tile1.data) && item.id === blockID) {
                Game.prevent();
                if (coords.side == BlockSide.DOWN || coords.side == BlockSide.UP) {
                    World.setBlock(coords.relative.x, coords.relative.y, coords.relative.z, item.id, 0);
                }
                else if (coords.side == BlockSide.NORTH || coords.side == BlockSide.SOUTH) {
                    World.setBlock(coords.relative.x, coords.relative.y, coords.relative.z, item.id, 1);
                }
                else if (coords.side == BlockSide.WEST || coords.side == BlockSide.EAST) {
                    World.setBlock(coords.relative.x, coords.relative.y, coords.relative.z, item.id, 2);
                }
            }
            return true;
        })
    },
    setSlabTypeRender: function (blockID, fullBlockID) {
        Callback.addCallback("ItemUse", function (position, item, block) {
            if (item.id == blockID) {
                Game.prevent();
                if (block.id == item.id && block.data == 0 && position.side == BlockSide.UP) {
                    World.setBlock(position.x, position.y, position.z, fullBlockID, 0);
                    return true;
                }
                if (block.id == item.id && block.data == 1 && position.side == BlockSide.DOWN) {
                    World.setBlock(position.x, position.y, position.z, fullBlockID, 0);
                    return true;
                }
                let place = World.cantileBeReplaced(block.id, block.data) ? position : position.relative;
                let tileID = World.getBlockID(place.x, place.y, place.z);
                let tileDATA = World.getBlockData(place.x, place.y, place.z);

                if (position.vec.y - place.y < 0.5) {
                    if (tileID == blockID && tileDATA == 1) {
                        World.setBlock(place.x, place.y, place.z, fullBlockID, 0);
                        return true;
                    }
                    World.setBlock(place.x, place.y, place.z, item.id, item.data);
                }
                else {
                    if (tileID == blockID && tileDATA == 0) {
                        World.setBlock(place.x, place.y, place.z, fullBlockID, 0);
                        return true;
                    }
                    World.setBlock(place.x, place.y, place.z, item.id, 1);
                }
                return true;
            }
        })
        Block.setBlockShape(blockID, { x: 0, y: 0, z: 0 }, { x: 1, y: 0.5, z: 1 }, 0);
        Block.setBlockShape(blockID, { x: 0, y: 0.5, z: 0 }, { x: 1, y: 1, z: 1 }, 1);
    }
}




// file: Hexxit Core/Skill Mode/Armor Button/Skill Armor.js





var currentUIscreen;
Callback.addCallback("NativeGuiChanged", function(screenName){
	currentUIscreen = screenName;
	if(screenName != "hud_screen" && screenName != "in_game_play_screen"){
		if(UIbuttons.container){
			UIbuttons.container.close();
			UIbuttons.container = null;
		}
	}
});

var UIbuttons = {
	isEnabled: false,
	nightvision: false,
	container: null,
	Window: new UI.Window({
		location: {
			x: 925,
			y: UI.getScreenHeight()/2-75,
			width: 75,
			height: 300
		},
		drawing: [{type: "background", color: 0}],
		elements: {}
	}),
	
	setButton: function(id, name){
		armorData[id] = name;
	},
	registerButton: function(name, properties){
		buttonContent[name] = properties;
	}
}

var armorData = {};

var buttonMap = {
	button_skill_resistance: false,
	button_speed_lv_untimed: false,
	button_fly: false,
	button_skill_sword: false,
	
}

var buttonContent = {
	button_skill_resistance: {
			y: 1500,
			type: "button",
			bitmap: "skill_resistance_off",
			bitmap2: "skill_resistance_on",
			scale: 20,
			clicker: {
				onClick: function(){
              Entity.addEffect(Player.get(), 11, 1, 200, true, false);
         Entity.addEffect(Player.get(), 2, 2, 200, true, false);
            Entity.addEffect(Player.get(), 10, 1, 50, true, false);
				}
			}
		},

    button_speed_lv_untimed: {
			y: 2250,
			type: "button",
			bitmap: "skill_speed_off",
			bitmap2: "skill_speed_on",
			scale: 20,
      clicker: {
       onClick: function(){
          Entity.addEffect(Player.get(), Native.PotionEffect.movementSpeed, 20, 25);
          Entity.addEffect(Player.get(), Native.PotionEffect.jump, 20, 25);
          
        }
		}
	}, 

button_skill_sword: {
			y: 2450,
			type: "button",
			bitmap: "skill_sword_off",
			bitmap2: "skill_sword_on",
			scale: 20,
      clicker: {
       onClick: function(){
       
          Entity.addEffect(Player.get(), Native.PotionEffect.movementSpeed, 3, 25);
        }
		}
	}, 
//button armor 

button_sagearmor: {
			y: 1500,
			type: "button",
			bitmap: "skill_water_off",
			bitmap2: "skill_water_on",
			scale: 20,
			clicker: {
				onClick: function(){
              Entity.addEffect(Player.get(), Native.PotionEffect.waterBreathing, 0, 20*15);
			Entity.addEffect(Player.get(), Native.PotionEffect.absorption, 2, 20*15);
			Entity.addEffect(Player.get(), Native.PotionEffect.fireResistance, 1, 20*15);
			Entity.addEffect(Player.get(), Native.PotionEffect.nightVision, 0, 20*15);
              
				}
			}
		},
      button_scalearmor: {
			y: 1500,
			type: "button",
			bitmap: "skill_sword_off",
			bitmap2: "skill_sword_on",
			scale: 20,
			clicker: {
				onClick: function(){
              
              Entity.addEffect(Player.get(), Native.PotionEffect.damageBoost, 0, 20*15);
			Entity.addEffect(Player.get(), Native.PotionEffect.damageResistance, 0, 20*15);
			Entity.addEffect(Player.get(), Native.PotionEffect.fireResistance, 1, 20*15);
              Entity.addEffect(Player.get(), Native.PotionEffect.movementSlowdown, 1, 20*15); 
              
				}
			}
		},
		
		
button_thiefarmor: {
			y: 1500,
			type: "button",
			bitmap: "skill_speed_off",
			bitmap2: "skill_speed_on",
			scale: 20,
			clicker: {
				onClick: function(){
              
              Entity.addEffect(Player.get(), Native.PotionEffect.nightVision, 0, 20*15);
			Entity.addEffect(Player.get(), Native.PotionEffect.movementSpeed, 2, 20*15);
			Entity.addEffect(Player.get(), Native.PotionEffect.damageBoost, 0, 20*15);
			Entity.addEffect(Player.get(), Native.PotionEffect.jump, 0, 20*15);
              
				}
			}
		},


button_tribalarmor: {
			y: 1500,
			type: "button",
			bitmap: "skill_speed_off",
			bitmap2: "skill_speed_on",
			scale: 20,
			clicker: {
				onClick: function(){
              
              Entity.addEffect(Player.get(), Native.PotionEffect.movementSpeed, 2, 20*15);
			Entity.addEffect(Player.get(), Native.PotionEffect.nightVision, 0, 20*15);
			Entity.addEffect(Player.get(), Native.PotionEffect.digSpeed, 1, 20*15);
			Entity.addEffect(Player.get(), Native.PotionEffect.jump, 2, 20*15);
              
				}
			}
		},




button_fly: {
		y: 1000,
		type: "button",
		bitmap: "button_fly_off",
		bitmap2: "button_fly_on",
		scale: 20
	}
}

UIbuttons.Window.setAsGameOverlay(true);

function updateUIbuttons(){
	var elements = UIbuttons.Window.content.elements;
	for(var name in buttonMap){
		if(buttonMap[name]){
			if(!elements[name]){
				elements[name] = buttonContent[name];
			}
			elements[name].x = 0;
			buttonMap[name] = false;
		}
		else{
			elements[name] = null;
		}
	}
}


Callback.addCallback("tick", function(){
	var armor = [Player.getArmorSlot(0), Player.getArmorSlot(1), Player.getArmorSlot(2), Player.getArmorSlot(3)];
	activeButtons = [];
	for(var i in armor){
		var button = armorData[armor[i].id];
		if(button){
			buttonMap[button] = true;
			UIbuttons.isEnabled = true;
		}
	}
	if(UIbuttons.isEnabled && (currentUIscreen == "hud_screen" || currentUIscreen == "in_game_play_screen")){
		updateUIbuttons();
		if(!UIbuttons.container){
			UIbuttons.container = new UI.Container();
			UIbuttons.container.openAs(UIbuttons.Window);
		}
		if(UIbuttons.container.isElementTouched("button_fly")){
			var armor = armor[1];
			var y = Player.getPosition().y
			var maxDmg = Item.getMaxDamage(armor.id)
			if(armor.data < maxDmg && y < 256){ 
				if(World.getThreadTime() % 10 == 0){
					Player.setArmorSlot(1, armor.id, 1, Math.min(armor.data+50, maxDmg));
				}
				var vel = Player.getVelocity();
				var vy = Math.min(32, 264-y) / 160;
				if(vel.y < 0.67){
					Player.addVelocity(0, Math.min(vy, 0.67-vel.y), 0);
				}
			}
		}
	}
	else{
		if(UIbuttons.container){
			UIbuttons.container.close();
			UIbuttons.container = null;
		}
	}
	UIbuttons.isEnabled = false;
});




// file: Hexxit Core/Skill Mode/Armor Button/Armor True.js

//{∆}
UIbuttons.setButton(ItemID.infinity_chestplate, "button_speed_lv_untimed");
UIbuttons.setButton(ItemID.fieryC, "button_skill_resistance");
UIbuttons.setButton(ItemID.cosmSword, "button_skill_sword");


//<\>


UIbuttons.setButton(ItemID.sageChestplate, "button_sagearmor");
UIbuttons.setButton(ItemID.scaleChestplate, "button_scalearmor");
UIbuttons.setButton(ItemID.thiefChestplate, "button_thiefarmor");
UIbuttons.setButton(ItemID.tribalChestplate, "button_tribalarmor");









// file: Hexxit Core/Skill Mode/Enchant Skill/Skill Legend.js

IDRegistry.genItemID("fire_skill_legend");
Item.createItem("fire_skill_legend", "§6Skill Fire \n Rarity: Bag \n Chance: 7/100 \n Skill: Fire \n Lv: Legend \n Attack: +3 \n Tools: Sword", {name: "skill_fire", meta: 0}, {stack: 1}, {inCreative: false})

IDRegistry.genItemID("ice_skill_legend");
Item.createItem("ice_skill_legend", "§6Skill Ice \n Rarity: Bag \n Chance: 7/100 \n Skill: Ice \n Lv: Legend \n Attack: +3 \n Tools: Sword", {name: "skill_ice", meta: 0}, {stack: 1}, {inCreative: false})


                                 //function
//fire
Callback.addCallback("PlayerAttack", function (player, victim) { 
var item = Entity.getCarriedItem(player);
if(item.id==ItemID.fire_skill_legend){
Entity.setFire(victim, 70, true);
} 
});

Item.registerUseFunction("fire_skill_legend", function(coords, item, block, player)
{
let b = BlockSource.getDefaultForActor(player);
if(b.getBlock(coords.x, coords.y + 1, coords.z).id==0){
b.setBlock(coords.x, coords.y + 1, coords.z, 51, 0);
}
}
);

//ice
Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.ice_skill_legend){ 
Entity.addEffect(victim, Native.PotionEffect.movementSlowdown, 20, 20, true, true); 
}
});

Item.registerUseFunction("ice_skill_legend", function(coords, item, block, player)
{
let c = BlockSource.getDefaultForActor(player);
if(c.getBlock(coords.x, coords.y + 1, coords.z).id==0){
c.setBlock(coords.x, coords.y + 1, coords.z, 78, 0);
}
}
);




// file: Hexxit Core/Skill Mode/Enchant Skill/Skill Untimed.js

IDRegistry.genItemID("fire_skill_untimed");
Item.createItem("fire_skill_untimed", "§dSkill Fire \n Rarity: Bag \n Chance: 5/100 \n Skill: Fire \n Lv: untimed \n Attack: +5 \n Tools: Sword", {name: "skill_fire", meta: 0}, {stack: 1}, {inCreative: false})

IDRegistry.genItemID("ice_skill_untimed");
Item.createItem("ice_skill_untimed", "§dSkill Ice \n Rarity: Bag \n Chance: 5/100 \n Skill: Ice \n Lv: untimed \n Attack: +5 \n Tools: Sword", {name: "skill_ice", meta: 0}, {stack: 1}, {inCreative: false})


                                 //function
//fire
Callback.addCallback("PlayerAttack", function (player, victim) { 
var item = Entity.getCarriedItem(player);
if(item.id==ItemID.fire_skill_untimed){
Entity.setFire(victim, 180, true);
} 
});

Item.registerUseFunction("fire_skill_untimed", function(coords, item, block, player)
{
let b = BlockSource.getDefaultForActor(player);
if(b.getBlock(coords.x, coords.y + 1, coords.z).id==0){
b.setBlock(coords.x, coords.y + 1, coords.z, 51, 0);
}
}
);

//ice
Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.ice_skill_untimed){ 
Entity.addEffect(victim, Native.PotionEffect.movementSlowdown, 30, 30, true, true); 
}
});

Item.registerUseFunction("ice_skill_untimed", function(coords, item, block, player)
{
let c = BlockSource.getDefaultForActor(player);
if(c.getBlock(coords.x, coords.y + 1, coords.z).id==0){
c.setBlock(coords.x, coords.y + 1, coords.z, 78, 0);
}
}
);

//lightning










                               //glint
Item.setGlint("ice_skill_untimed", true);
Item.setGlint("fire_skill_untimed", true);
                               
                               
                               
                               
                               
           
                  




// file: Hexxit Core/Skill Mode/Bag Skill.js

IDRegistry.genItemID("bag_skill");
Item.createItem("bag_skill", "§bSkill Bag \n Drop: Skill Item \n §6Legend: 7/100 \n §dUntimed: 5/100", {name: "bag"});

function dropBag(coords){
 if (!Math.floor(Math.random()*10)) World.drop(coords.x, coords.y, coords.z, ItemID.bag_skill, 1, 0);
}

var TREASURE = [
    {chance: 70, id: ItemID.bag_skill, data: 0},
    
    {chance: 1, id: ItemID.fire_skill_untimed, data: 0},
    {chance: 1, id: ItemID.ice_skill_untimed, data: 0},
    
    
    {chance: 2, id: ItemID.fire_skill_legend, data: 0},
    {chance: 2, id: ItemID.ice_skill_legend, data: 0},
    

    
    
];

function getTreasureDropItem(){
    var total = 0;
    for (var i in TREASURE){
        total += TREASURE[i].chance;
    }
    var random = Math.random() * total * 1.4;
    var current = 0;
    for (var i in TREASURE){
        var drop = TREASURE[i];
        if (current < random && current + drop.chance > random){
            return drop;
        }
        current += drop.chance;
    }

    return {id: 0, data: 0};
}

Item.registerUseFunction("bag_skill", function(coords, item, block){
    var drop = getTreasureDropItem();
    World.drop(coords.relative.x + 0.5, coords.relative.y + 0.1, coords.relative.z + 0.5, drop.id, 1, drop.data);
    item.count--;
    if(!item.count){item.id = 0;}
    Player.setCarriedItem(item.id, item.count, 0);
});
Callback.addCallback("EntityDeath", function(entity){
var E = Entity.getType(entity);
var coords = Entity.getPosition(entity);
var Q = Math.round(Math.random() * 9);
 if(E == 34 || E == 32 || E == 47 || E == 38 || E == 33 || E == 35 || E == 40 || E == 44 ){
   if(Q == 8){
      World.drop(coords.x, coords.y, coords.z, ItemID.bag_skill, 1, 0);
}
}
});





// file: Mode Mod/Fly.js



Callback.addCallback('tick', function () {
let item = Player.getCarriedItem();
if(item.id == ItemID.cosmSword){
Player.setFlyingEnabled(true);
  }
  if(Entity.getArmorSlot(Player.get(), 0).id == ItemID.infinity_helmet &&Entity.getArmorSlot(Player.get(), 1).id == ItemID.infinity_chestplate &&Entity.getArmorSlot(Player.get(), 2).id == ItemID.infinity_leggings &&Entity.getArmorSlot(Player.get(), 3).id == ItemID.infinity_boots){
  Player.setFlyingEnabled(true);
  }
});

//dame




// file: Mode Mod/Group.js

Item.addCreativeGroup("Skill Untimed", Translation.translate("Skill Untimed"), [
	ItemID.fire_skill_untimed,
	 ItemID.ice_skill_untimed,
	 ItemID.lightning_skill_untimed,
]);

Item.addCreativeGroup("Skill Legend", Translation.translate("Skill Legend"), [
	ItemID.fire_skill_legend,
	 ItemID.ice_skill_legend,
	 ItemID.lightning_skill_legend,
]);







Item.addCreativeGroup("Key Boss", Translation.translate("Key Boss"), [
	ItemID.keyNaga,
	 ItemID.keyHydra,
	 ItemID.keyLich,
	 ItemID.keyUghast,
	 ItemID.keyMinoshroom,
	ItemID.keySnowQueen,
	 
]);
//infinity 
Item.addCreativeGroup("singularity and ingot", Translation.translate("singularity"), [
	ItemID.infinityingot,
	ItemID.fieryblood,
	ItemID.livingmetal,
	ItemID.fint,
	ItemID.diamondHexical,
	ItemID.steeleaf,
	ItemID.ironwood,
	ItemID.bo1,
	ItemID.bo2,
	ItemID.bo3,
	ItemID.bo4,
	 ItemID.bo5,
	 ItemID.bo6,
	 ItemID.bo7,
	 ItemID.bo8,
	 ItemID.bo9,
	ItemID.essenceHexical,
	 
	 
	 ItemID.hexibiscusItem,
	 
	 
	 ItemID.page,
]);
//magic run

// sword
Item.addCreativeGroup("sword giant & magic", Translation.translate("sword giant & magic"), [
	 ItemID.wooden_giant_sword,
	 ItemID.stone_giant_sword,
	 ItemID.iron_giant_sword,
	 ItemID.gold_giant_sword,
	 ItemID.diamond_giant_sword,
	 ItemID.emerald_giant_sword,
	 ItemID.ender_giant_sword,
	 ItemID.livingmetal_giant_sword,
	ItemID.bone_giant_sword, 
ItemID.netherrack_giant_sword, 
ItemID.quartz_giant_sword,
 ItemID.obsidian_giant_sword,
 ItemID.netherite_giant_sword, 
	ItemID.wither_giant_sword, 
	ItemID.dragon_giant_sword, 
	 
]);



Item.addCreativeGroup("all twilight forest tools", Translation.translate("all twilight forest tools"), [
	ItemID.v1,
	ItemID.v2,
	ItemID.v3,
	ItemID.v4,
	ItemID.pick,
    ItemID.minotauraxe,
]);
Item.addCreativeGroup("infinity tools", Translation.translate("infinity tools"), [
	ItemID.cosmSword,
	ItemID.cosmPickaxe,
	ItemID.cosmAxe,
	ItemID.cosmShovel,
	ItemID.cosmdes,
    ItemID.cosmhammer,
]);



//magic stick




Item.addCreativeGroup("Trophy", Translation.translate("Trophy"), [
	ItemID.ughastTrophy,
	ItemID.lichTrophy,
	ItemID.nagaTrophy,
	ItemID.hydraTrophy,
	
]);

Item.addCreativeGroup("Helmet hexxit", Translation.translate("Helmet hexxit"), [
     ItemID.infinity_helmet,
	ItemID.sageHelmet,
	ItemID.scaleHelmet,
	ItemID.thiefHelmet,
	ItemID.tribalHelmet,
	ItemID.armor1,
	ItemID.lol,
	 ItemID.st1,
	ItemID.fieryH,
	ItemID.stoneHelmet,
	ItemID.snowHelmet,
	ItemID.slimeHelmet,
	ItemID.dirtHelmet,
	ItemID.netherHelmet,
	ItemID.cobblestoneHelmet,
	ItemID.caneHelmet,
	 ItemID.brickHelmet,
	 ItemID.quartzHelmet,
	 ItemID.redstoneHelmet,
	ItemID.logHelmet,
	 ItemID.planksHelmet,
	 ItemID.dioriteHelmet,
	 ItemID.graniteHelmet,
	 ItemID.emeraldHelmet,
	 ItemID.lapisHelmet,
	 ItemID.coalHelmet,
	
]);

Item.addCreativeGroup("Chestplate hexxit ", Translation.translate(" Chestplate hexxit "), [
	ItemID.infinity_chestplate,
ItemID.sageChestplate,
	ItemID.scaleChestplate,
	ItemID.thiefChestplate,
	ItemID.tribalChestplate,
	ItemID.armor2,
	ItemID.loz,
	ItemID.st2,
	ItemID.fieryC,
	ItemID.stoneChestplate,
	ItemID.snowChestplate,
	ItemID.slimeChestplate,
	ItemID.dirtChestplate,
	ItemID.netherChestplate,
	 ItemID.cobblestoneChestplate,
	 ItemID.caneChestplate,
	 ItemID.brickChestplate,
	ItemID.quartzChestplate,
	 ItemID.redstoneChestplate,
	 ItemID.logChestplate,
	 ItemID.planksChestplate,
	ItemID.dioriteChestplate,
	 ItemID.graniteChestplate,
	ItemID.emeraldChestplate,
	 ItemID.lapisChestplate,
	 ItemID.coalChestplate,
]);

Item.addCreativeGroup("Leggings hexxit", Translation.translate("leggings hexxit"), [
	ItemID.infinity_leggings,
    ItemID.sageLeggings,
	ItemID.scaleLeggings,
	ItemID.thiefLeggings,
	ItemID.tribalLeggings,
	ItemID.armor3,
	ItemID.st3,
	ItemID.fieryL,
	ItemID.stoneLeggings,
	ItemID.snowLeggings,
	ItemID.slimeLeggings,
	ItemID.dirtLeggings,
	ItemID.netherLeggings,
	ItemID.cobblestoneLeggings,
	ItemID.caneLeggings,
	ItemID.brickLeggings,
	ItemID.quartzLeggings,
	ItemID.redstoneLeggings,
	ItemID.logLeggings,
	ItemID.planksLeggings,
	ItemID.dioriteLeggings,
	ItemID.graniteLeggings,
	ItemID.emeraldLeggings,
	ItemID.lapisLeggings,
	ItemID.coalLeggings,
]);

Item.addCreativeGroup("Boots hexxit", Translation.translate("Boots hexxit"), [
	ItemID.infinity_boots,
ItemID. sageBoots,
	ItemID.scaleBoots,
	ItemID.thiefBoots,
	ItemID.tribalBoots,
	ItemID.armor4,
	ItemID.st4,
	ItemID.fieryB,
	ItemID.stoneBoots,
	ItemID.snowBoots,
	ItemID.slimeBoots,
	ItemID.dirtBoots,
	ItemID.netherBoots,
	ItemID.cobblestoneBoots,
	ItemID.caneBoots,
	ItemID.brickBoots,
	ItemID.quartzBoots,
	ItemID.redstoneBoots,
	ItemID.logBoots,
	ItemID.planksBoots,
	ItemID.dioriteBoots,
	ItemID.graniteBoots,
	ItemID.emeraldBoots,
	ItemID.lapisBoots,
	ItemID.coalBoots,
]);






Item.addCreativeGroup("Log", Translation.translate("Log"), [
	BlockID.twDarkLog,
	 BlockID.twMangroveLog,
	BlockID.twCanopyLog,
	 BlockID.twTwilightOakLog,
	BlockID.twMiningLog,
	 BlockID.twSortingLog,
	BlockID.twTimeLog,
	 BlockID.twTransformationLog,
]);
Item.addCreativeGroup("Plank", Translation.translate("Plank"), [
	BlockID.tw_planks_dark_wood,
	 BlockID.tw_planks_mangrove,
	BlockID.tw_planks_canopy,
	 BlockID.tw_planks_twilight_oak,
	BlockID.tw_planks_mine,
	 BlockID.tw_planks_sort,
	BlockID.tw_planks_time,
	 BlockID.tw_planks_trans,
]);







// file: Mode Mod/Destroy.js

Callback.addCallback("DestroyBlock", function(coords, block, player){
item=Player.getCarriedItem(true);
if(item.id==ItemID.cosmPickaxe&&block.id==7){
	World.destroyBlock(coords.x, coords.y, coords.z, true);
	}});
	
	Callback.addCallback("tick", function () { 
	item=Player.getCarriedItem(true);
	if(item.id==ItemID.cosmPickaxe){
		Block.setDestroyTime(7, 0.1); 
	}
	else
	if(item.id!==ItemID.cosmPickaxe){
		Block.setDestroyTime(7, 99999*99999);
	}});
	//




// file: Hexxit Core/Food/Apple Metal.js

IDRegistry.genItemID("blueapple");
Item.createFoodItem("blueapple","Blune apple",
{name: "blueapple", meta: 0}, 
{food: 10});


IDRegistry.genItemID("grayapple");
Item.createFoodItem("grayapple","Gray apple",
{name: "grayapple", meta: 0}, 
{food: 6});

IDRegistry.genItemID("redapple");
Item.createFoodItem("redapple","Red apple",
{name: "redapple", meta: 0}, 
{food: 4});

IDRegistry.genItemID("bblueapple");
Item.createFoodItem("bblueapple","Blune apple 2",
{name: "bblueapple", meta: 0}, 
{food: 4});

IDRegistry.genItemID("greenapple");
Item.createFoodItem("greenapple","Green apple",
{name: "greenapple", meta: 0}, 
{food: 8});

IDRegistry.genItemID("blackapple");
Item.createFoodItem("blackapple","Black apple",
{name: "blackapple", meta: 0}, 
{food: 3});

Recipes.addShaped({id: ItemID.redapple, count:1 , data: 0}, [
 "bbb",
 "bab",
 "bbb"
], ['a', 260, 0, 'b', 331, 0]);

Recipes.addShaped({id: ItemID.blueapple, count:1 , data: 0}, [
 "bbb",
 "bab",
 "bbb"
], ['a', 260, 0, 'b', 264, 0]);

Recipes.addShaped({id: ItemID.greenapple, count:1 , data: 0}, [
 "bbb",
 "bab",
 "bbb"
], ['a', 260, 0, 'b', 388, 0]);

Recipes.addShaped({id: ItemID.blackapple, count:1 , data: 0}, [
 "bbb",
 "bab",
 "bbb"
], ['a', 260, 0, 'b', 263, 0]);

Recipes.addShaped({id: ItemID.blackapple, count:1 , data: 0}, [
 "bbb",
 "bab",
 "bbb"
], ['a', 260, 0, 'b', 263, 1]);

Recipes.addShaped({id: ItemID.bblueapple, count:1 , data: 0}, [
 "bbb",
 "bab",
 "bbb"
], ['a', 260, 0, 'b', 351, 4]);

Recipes.addShaped({id: ItemID.grayapple, count:1 , data: 0}, [
 "bbb",
 "bab",
 "bbb"
], ['a', 260, 0, 'b', 265, 0]);



Item.addCreativeGroup("táo nguyên tố", Translation.translate("táo nguyên tố"), [
	ItemID.blueapple,
	ItemID.grayapple,
	ItemID.redapple,
	ItemID.bblueapple,
	ItemID.greenapple,
	ItemID.blackapple
]);

Callback.addCallback("FoodEaten",function(heal, satRatio)
{
    var helmet = Player.getArmorSlot(0);
    var chest = Player.getArmorSlot(1);
    var legs = Player.getArmorSlot(2);
    var boots = Player.getArmorSlot(3);
    var pos = Player.getPosition();
    
if(Player.getCarriedItem().id==ItemID.blueapple)
{
Entity.addEffect(Player.get(), 5, 3, 20*60)
Entity.addEffect(Player.get(), 3, 3, 20*60)
Entity.addEffect(Player.get(), 22, 3, 20*60)
Entity.addEffect(Player.get(), 11, 3, 20*60)
}



if(Player.getCarriedItem().id==ItemID.grayapple)
{
Entity.addEffect(Player.get(), 5, 1, 20*30)
Entity.addEffect(Player.get(), 3, 1, 20*30)
Entity.addEffect(Player.get(), 22, 1, 20*30)
}


if(Player.getCarriedItem().id==ItemID.redapple)
{
Entity.addEffect(Player.get(), 10, 1, 20*10)

}


if(Player.getCarriedItem().id==ItemID.bblueapple)
{
Entity.addEffect(Player.get(), 13, 3, 20*60)
Entity.addEffect(Player.get(), 16, 1,20*30)
}


if(Player.getCarriedItem().id==ItemID.greenapple)
{
Entity.addEffect(Player.get(), 14, 3, 20*60)
Entity.addEffect(Player.get(), 8, 1,20*30)
Entity.addEffect(Player.get(), 1, 1,20*30)
}


if(Player.getCarriedItem().id==ItemID.blackapple)
{
Entity.addEffect(Player.get(), 16, 2, 10*120)
}





}) ;
//enchan
Item.setGlint("blueapple", true);
Item.setGlint("greenapple", true);







// file: Hexxit Core/Item/Item Mod.js

IDRegistry.genItemID("essenceHexical");
Item.createItem("essenceHexical", "Hexical Essence", {name: "hexessence", meta: 0});

IDRegistry.genItemID("hexibiscusItem");
Item.createItem("hexibiscusItem", "Hexibiscus", {name: "hexibiscus", meta: 0});

IDRegistry.genItemID("diamondHexical");
Item.createItem("diamondHexical", "Hexical Diamond", {name: "hexdiamond", meta: 0});

IDRegistry.genBlockID("hexibiscus");
Block.createBlock("hexibiscus", [
	{name: "Hexibiscus", texture: [["ghostblock", 0], ["ghostblock", 0], ["hexibiscus", 0]], inCreative: false}
]);

Block.setBlockShape(BlockID.hexibiscus, {x: 0.1, y: 0, z: 0.1}, {x: 0.9, y: 0.05, z: 0.9});

Item.registerUseFunction("hexibiscusItem", function(coords, item, block){
	var place = coords.relative;
	if(GenerationUtils.isTransparentBlock(World.getBlockID(place.x, place.y, place.z))){
		World.setBlock(place.x, place.y, place.z, BlockID.hexibiscus);
		Player.setCarriedItem(item.id, item.count - 1, item.data);
		World.addTileEntity(place.x, place.y, place.z);
	}
});

Block.registerDropFunction("hexibiscus", function(){
return [[ItemID.essenceHexical, 1, 0]];});

BlockRenderer.addRenderCallback(BlockID.hexibiscus, function(api, coords, block) {

var box = BlockID.hexibiscus;

api.renderBoxId(coords.x, coords.y, coords.z, .499, 0, 0, .501, 0.90, 1, box, 0);
api.renderBoxId(coords.x, coords.y, coords.z, 0, 0, .499, 1, 0.90, .501, box, 0);

                 
});
BlockRenderer.enableCustomRender(BlockID.hexibiscus);


Callback.addCallback("GenerateChunk", function (chunkX, chunkZ) {

    let coords = GenerationUtils.randomCoords(chunkX, chunkZ, 1, 512);
    if(Math.random() < 0.1){
    coords = GenerationUtils.findSurface(coords.x, coords.y, coords.z);

    if (World.getBlock(coords.x, coords.y + 1, coords.z).id === 0 && GenerationUtils.canSeeSky(coords.x, coords.y + 1, coords.z)) {
        World.setBlock(coords.x,coords.y + 1,  coords.z, BlockID.hexibiscus, 0);
        }}
});
//0

//1
IDRegistry.genItemID("livingmetal");
Item.createItem("livingmetal", " living metal ingot", {name: "li", meta: 0}, {stack: 64})
//3
IDRegistry.genItemID("steeleaf");
Item.createItem("steeleaf", " steeleaf", {name: "stl", meta: 0}, {stack: 64})
//4
IDRegistry.genItemID("ironwood");
Item.createItem("ironwood", " iron wood ", {name: "tao", meta: 0}, {stack: 64})

IDRegistry.genItemID("fieryblood");
Item.createItem("fieryblood", " fiery blood", {name: "fb", meta: 0}, {stack: 64})

IDRegistry.genItemID("fint");
Item.createItem("fint", "fiery ingot ", {name: "fin", meta: 0}, {stack: 64})

//4.5
IDRegistry.genItemID("page");
Item.createItem("page", "paper giant sword", {name: "kiemtove", meta: 0}, {stack: 4})
Recipes.addShaped({id: ItemID.page, count: 2, data: 0}, [
		"poo",
		"ooo",
		"bop"
	], ['o', 339, 0,'b', 280, 0]);
	 IDRegistry.genItemID("twpo");
Item.createItem("twpo", "over world and twilight forest", {name: "over_world", meta: 0}, {stack: 1})
	Recipes.addShaped({id: ItemID.twpo, count: 2, data: 0}, [
		"ooo",
		"aaa",
		"aaa"
	], ['o', ItemID.steeleaf, 0,'a', 3, 0]);
	
Item.setGlint("livingmetal", true);
Recipes.addShaped({id: ItemID.livingmetal, count: 1, data: 0}, [
		"oxo",
		"xgx",
		"oxo"
	], ['x', ItemID.diamondHexical, 0,'g', 265, 0]);
	
	///
	 






// file: Hexxit Core/Item/Singularity Mod.js

IDRegistry.genItemID("infinityingot");
Item.createItem("infinityingot", "infinity ingot ", {name: "ifi", meta: 0}, {stack: 64})
IDRegistry.genItemID("bo1");
Item.createItem("bo1", " singularity gold ", {name: "sin1", meta: 0}, {stack: 64})
IDRegistry.genItemID("bo2");
Item.createItem("bo2", " singularity iron", {name: "sin2", meta: 0}, {stack: 64})
IDRegistry.genItemID("bo3");
Item.createItem("bo3", " singularity lapis ", {name: "sin3", meta: 0}, {stack: 64})
IDRegistry.genItemID("bo4");
Item.createItem("bo4", " singularity emerald ", {name: "sin4", meta: 0}, {stack: 64})
IDRegistry.genItemID("bo5");
Item.createItem("bo5", " singularity redstone ", {name: "sin5", meta: 0}, {stack: 64})
IDRegistry.genItemID("bo6");
Item.createItem("bo6", " singularity diamond Hexical  ", {name: "sin6", meta: 0}, {stack: 64})
IDRegistry.genItemID("bo7");
Item.createItem("bo7", " singularity diamond  ", {name: "sin7", meta: 0}, {stack: 64})
IDRegistry.genItemID("bo8");
Item.createItem("bo8", " singularity  ", {name: "sin8", meta: 0}, {stack: 64})
IDRegistry.genItemID("bo9");
Item.createItem("bo9", "  neutron ingot  ", {name: "sin9", meta: 0}, {stack: 64})
//craft

Recipes.addShaped({id: ItemID.infinityingot, count: 1, data: 0}, [
		"bbb",
		"ooo",
		"bbb"
	], ['b', ItemID.bo9, 0,'o', ItemID.bo8, 0]);

Recipes.addShaped({id: ItemID.bo9, count: 2, data: 0}, [
		"bbb",
		"ooo",
		"bbb"
	], ['b', 49, 0,'o', 265, 0]);


Recipes.addShaped({id: ItemID.bo1, count: 1, data: 0}, [
	"xxx",
	"xxx",
	"xxx"
], ['g', ItemID.bo7, 0, 'x', 41, 0]);

Recipes.addShaped({id: ItemID.bo2, count: 1, data: 0}, [
	"xxx",
	"xxx",
	"xxx"
], ['g', ItemID.bo3, 0, 'x', 42, 0]);

Recipes.addShaped({id: ItemID.bo3, count: 1, data: 0}, [
	"xxx",
	"xxx",
	"xxx"
], ['x', 22, 0]);

Recipes.addShaped({id: ItemID.bo4, count: 1, data: 0}, [
	"xxx",
	"xxx",
	"xxx"
], ['x', 133, 0]);

Recipes.addShaped({id: ItemID.bo5, count: 1, data: 0}, [
	"xxx",
	"xxx",
	"xxx"
], ['x', 152, 0]);

Recipes.addShaped({id: ItemID.bo8, count: 1, data: 0}, [
	"abc",
	"nhx",
	"kmm"
], ['a', ItemID.bo1, 0,'b', ItemID.bo2, 0,'c', ItemID.bo3, 0,'n', ItemID.bo4, 0,'h', ItemID.bo5, 0,'x', ItemID.bo6, 0,'k', ItemID.bo7, 0]);

Recipes.addShaped({id: ItemID.bo6, count: 1, data: 0}, [
	"xxx",
	"xxx",
	"xxx"
], ['x', ItemID.diamondHexical, 0]);

Recipes.addShaped({id: ItemID.bo7, count: 1, data: 0}, [
	"xxx",
	"xxx",
	"xxx"
], ['x', 57, 0]);






// file: Hexxit Core/Item/Key Boss.js

IDRegistry.genItemID("keyNaga");
Item.createItem("keyNaga", "Key Naga Boss", {name: "key_boss", meta: 0}, {stack: 1})

	 IDRegistry.genItemID("keyHydra");
Item.createItem("keyHydra", "Key Hydra Boss", {name: "key_boss", meta: 0}, {stack: 1})

	 IDRegistry.genItemID("keyLich");
Item.createItem("keyLich", "Key Lich Boss", {name: "key_boss", meta: 0}, {stack: 1})

	 IDRegistry.genItemID("keyMinoshroom");
Item.createItem("keyMinoshroom", "Key Minoshroom Boss", {name: "key_boss", meta: 0}, {stack: 1})

	 IDRegistry.genItemID("keyUghast");
Item.createItem("keyUghast", "Key Ughast Boss", {name: "key_boss", meta: 0}, {stack: 1})

IDRegistry.genItemID("keySnowQueen");
Item.createItem("keySnowQueen", "Key Snow Queen Boss", {name: "key_boss", meta: 0}, {stack: 1})



Item.setGlint("keyNaga", true);
Item.setGlint("keyHydra", true);
Item.setGlint("keyLich", true);
Item.setGlint("keyMinoshroom", true);
Item.setGlint("keyUghast", true);
Item.setGlint("keySnowQueen", true);

	




// file: Hexxit Core/Tools/Bow.js




ToolAPI.addToolMaterial("infinity_bow", {durability:99999,level:6,efficiency:32747,damage:2147483647,enchantability:999});
IDRegistry.genItemID ("infinity_bow");
Item.createItem("infinity_bow", "§cCosm Bow \n Rarity: Extrеme Crafting \n Mode: Fly \n Lv: the ultimate level \n Damage: 1000",{name:"infinity_bow",meta:0},{stack:1});
Item.setToolRender(ItemID.infinity_bow,true);

Callback.addCallback('ProjectileHitEntity', function (projectile, entity) {
//当抛出的实体击中生物时调用。
let item = Player.getCarriedItem();
if(item.id == ItemID.infinity_bow){
Entity.setHealth(entity, 99999999);
Game.prevent();
}});




Item.registerNoTargetUseFunction("infinity_bow", function(item){
if(item.id == ItemID.infinity_bow){
 let 子弹 = Player.getPosition();
let 力量 = Entity.getLookVector(Player.get());
//发射的实体
var 子弹1 = Entity.spawn(子弹.x,子弹.y,子弹.z,Native.EntityType.IRON_GOLEM);
Entity.setVelocity(子弹1,8*力量.x,8*力量.y,8*力量.z);
}});




// file: Hexxit Core/Tools/Giant Sword.js

IDRegistry.genItemID( "wooden_giant_sword" );
Item.createItem("wooden_giant_sword", "Wooden Sword \n Rarity: Craftable \n Lv: Basic Level \n Skill: No \n Damage: +5", {
         name: "wooden_sword_giant", meta: 0
}, {stack: 1});

ToolAPI.addToolMaterial("oak planks", {durability: 340, level: 1, efficiency: 4, damage: 5, enchantability: 30});
ToolAPI.setTool(ItemID.wooden_giant_sword, "oak planks", ToolType.sword);

Recipes.addShaped({id: ItemID.wooden_giant_sword, count: 1, data: 0}, [
		"oqq",
		"qqq",
		"mqa"
	], ['o', ItemID.page, 0,'m', 280, 0,'q', 5, 0]);





IDRegistry.genItemID("stone_giant_sword");
Item.createItem("stone_giant_sword", "Stone Sword \n Rarity: Craftable \n Lv: Basic Level \n Skill: No \n Damage: +6", {
    name: "stone_sword_giant", meta: 0
}, {stack: 1});

ToolAPI.addToolMaterial("stone", {durability: 700, level: 2, efficiency: 4, damage: 6, enchantability: 30});
ToolAPI.setTool(ItemID.stone_giant_sword, "stone", ToolType.sword);

Recipes.addShaped({id: ItemID.stone_giant_sword, count: 1, data: 0}, [
		"ohh",
		"hhh",
		"vhp"
	], ['v', 280, 0,'h', 4, 0,'o', ItemID.page, 0]);
	


IDRegistry.genItemID("iron_giant_sword");
Item.createItem("iron_giant_sword", "Iron Sword  \n Rarity: Craftable \n Lv: Basic Level \n Skill: No \n Damage: +7", {
name: "iron_sword_giant", meta: 0
}, {stack: 1});

ToolAPI.addToolMaterial("iron ingot", {durability: 970, level: 3, efficiency: 4, damage: 7, enchantability: 30});
ToolAPI.setTool(ItemID.iron_giant_sword, "iron ingot", ToolType.sword);

Recipes.addShaped({id: ItemID.iron_giant_sword, count: 1, data: 0}, [
		"oll",
		"lll",
		"klp"
	], ['k', 280, 0,'l', 265, 0,'o', ItemID.page, 0]);
	


IDRegistry.genItemID("gold_giant_sword");
Item.createItem("gold_giant_sword", "Gold Sword \n Rarity: Craftable \n Lv: Basic Level \n Skill: No \n Damage: +5", {
name: "gold_sword_giant", meta: 0
}, {stack: 1});

ToolAPI.addToolMaterial("gold ingot", {durability: 340, level: 3, efficiency: 4, damage: 5, enchantability: 30});
ToolAPI.setTool(ItemID.gold_giant_sword, "gold ingot", ToolType.sword);

Recipes.addShaped({id: ItemID.gold_giant_sword, count: 1, data: 0}, [
		"oee",
		"eee",
		"yep"
	], ['y', 280, 0,'e', 266, 0,'o', ItemID.page, 0]);
	


IDRegistry.genItemID("diamond_giant_sword");
Item.createItem("diamond_giant_sword", "Diamond Sword \n Rarity: Craftable \n Lv: Basic Level \n Skill: No \n Damage: +11", {
      name: "diamond_sword_giant", meta: 0
}, {stack: 1});

ToolAPI.addToolMaterial("diamond", {durability: 2500, level: 4, efficiency: 4, damage: 11, enchantability: 30});
ToolAPI.setTool(ItemID.diamond_giant_sword, "diamond", ToolType.sword);

Recipes.addShaped({id: ItemID.diamond_giant_sword, count: 1, data: 0}, [
		"opp",
		"ppp",
		"fpx"
	], ['f', 280, 0,'p',264,0,'o', ItemID.page, 0]);



IDRegistry.genItemID("emerald_giant_sword");
Item.createItem("emerald_giant_sword", "Emerald Sword \n Rarity: Craftable \n Lv: Basic Level \n Skill: No \n Damage: +14", {
    name: "emerald_sword_giant", meta: 0
}, {stack: 1});

ToolAPI.addToolMaterial("emerald", {durability: 2600, level: 4, efficiency: 4, damage: 14, enchantability: 30});
ToolAPI.setTool(ItemID.emerald_giant_sword, "emerald", ToolType.sword);

Recipes.addShaped({id: ItemID.emerald_giant_sword, count: 1, data: 0}, [
		"onn",
		"nnn",
		"lnp"
	], ['l', 280, 0,'n',388,0,'o', ItemID.page, 0]);
	


IDRegistry.genItemID("ender_giant_sword");
Item.createItem("ender_giant_sword", "Ender Sword \n Rarity: Craftable \n Lv: Basic Level \n Skill: No \n Damage: +17", {
    name: "ender_sword_giant", meta: 0
}, {stack: 1});

ToolAPI.addToolMaterial("diamond", {durability: 2800, level: 4, efficiency: 4, damage: 17, enchantability: 30});
ToolAPI.setTool(ItemID.ender_giant_sword, "diamond", ToolType.sword);

Recipes.addShaped({id: ItemID.ender_giant_sword, count: 1, data: 0}, [
		"okk",
		"kek",
		"nkp"
	], ['e', 381, 0,'n', 369, 0,'k', 49, 0,'o', ItemID.page, 0]);





IDRegistry.genItemID("livingmetal_giant_sword");
Item.createItem("livingmetal_giant_sword", " Living Metal Sword \n Rarity: Craftable \n Lv: Basic Level \n Skill: No \n Damage: +20", {
     name: "livingmetal_sword_giant", meta: 0
}, {stack: 1});

ToolAPI.addToolMaterial("livingmetal", {durability: 3200, level: 4, efficiency: 4, damage: 20, enchantability: 30});
ToolAPI.setTool(ItemID.livingmetal_giant_sword, "livingmetal", ToolType.sword);

Recipes.addShaped({id: ItemID.livingmetal_giant_sword, count: 1, data: 0}, [
		"oxx",
		"xxx",
		"zxp"
	], ['x', ItemID.livingmetal, 0,'z', 280, 0,'o', ItemID.page, 0]);



	
	
	
	
	IDRegistry.genItemID("quartz_giant_sword");
Item.createItem("quartz_giant_sword", "Quartz Giant Sword \n Rarity: Craftable \n Lv: Basic Level \nSkill: No \n Damage: +6", {
     name: "quartz_giant_sword", meta: 0
}, {stack: 1});

ToolAPI.addToolMaterial("bone", {durability: 500, level: 4, efficiency: 4, damage: 6, enchantability: 30});
ToolAPI.setTool(ItemID.quartz_giant_sword, "bone", ToolType.sword);
	
	Recipes.addShaped({id: ItemID.quartz_giant_sword, count: 1, data: 0}, [
		"ohh",
		"hhh",
		"vhp"
	], ['v', 280, 0,'h', 406, 0,'o', ItemID.page, 0]);
	
	
	
	
	
	IDRegistry.genItemID("netherrack_giant_sword");
Item.createItem("netherrack_giant_sword", "Netherrack Giant Sword \n Rarity: Craftable \n Lv: Basic Level \n Skill: No \n Damage: +6", {
     name: "netherrack_giant_sword", meta: 0
}, {stack: 1});

ToolAPI.addToolMaterial("bone", {durability: 700, level: 4, efficiency: 4, damage: 6, enchantability: 30});
ToolAPI.setTool(ItemID.netherrack_giant_sword, "bone", ToolType.sword);
	
	Recipes.addShaped({id: ItemID.netherrack_giant_sword, count: 1, data: 0}, [
		"ohh",
		"hhh",
		"vhp"
	], ['v', 280, 0,'h', 87, 0,'o', ItemID.page, 0]);
	
	
	
	
	
	IDRegistry.genItemID("bone_giant_sword");
Item.createItem("bone_giant_sword", "Bone Giant Sword \n Rarity: Craftable \n Lv: Basic Level \n Skill: No \n Damage: +13", {
    name: "bone_giant_sword", meta: 0
}, {stack: 1});

ToolAPI.addToolMaterial("bone", {durability: 790, level: 4, efficiency: 4, damage: 13, enchantability: 30});
ToolAPI.setTool(ItemID.bone_giant_sword, "bone", ToolType.sword);
	
	Recipes.addShaped({id: ItemID.bone_giant_sword, count: 1, data: 0}, [
		"ohh",
		"hkh",
		"vhp"
	], ['v', 280, 0,'h', 352, 0,'o', ItemID.page, 0,'k', 397, 0]);
	
	
	
	

	IDRegistry.genItemID("obsidian_giant_sword");
Item.createItem("obsidian_giant_sword", "Obsidian Giant Sword \n Rarity: Craftable \n Lv: Basic Level \n Skill: No \n Damage: +15", {
     name: "obsidian_giant_sword", meta: 0
}, {stack: 1});

ToolAPI.addToolMaterial("bone", {durability: 2000, level: 4, efficiency: 4, damage: 15, enchantability: 30});
ToolAPI.setTool(ItemID.obsidian_giant_sword, "bone", ToolType.sword);

Recipes.addShaped({id: ItemID.obsidian_giant_sword, count: 1, data: 0}, [
		"ohh",
		"hhh",
		"vhp"
	], ['v', 280, 0,'h', 49, 0,'o', ItemID.page, 0]);
	
	
IDRegistry.genItemID("netherite_giant_sword");
Item.createItem("netherite_giant_sword", "Netherite Giant Sword \n Rarity: Craftable \n Lv: Basic Level \n Skill: No \n Damage: +18", {
     name: "netherite_giant_sword", meta: 0
}, {stack: 1});

ToolAPI.addToolMaterial("bone", {durability: 2000, level: 4, efficiency: 4, damage: 18, enchantability: 30});
ToolAPI.setTool(ItemID.netherite_giant_sword, "bone", ToolType.sword);

IDRegistry.genItemID("wither_giant_sword");
Item.createItem("wither_giant_sword", "Wither Giant Sword \n Rarity: Craftable \n Lv: Basic Level \n Skill: No \n Damage: +43", {
     name: "wither_giant_sword", meta: 0
}, {stack: 1});

ToolAPI.addToolMaterial("bone", {durability: 790, level: 4, efficiency: 4, damage: 43, enchantability: 30});
ToolAPI.setTool(ItemID.wither_giant_sword, "bone", ToolType.sword);
	
	
	Recipes.addShaped({id: ItemID.wither_giant_sword, count: 1, data: 0}, [
		"ohh",
		"hkh",
		"vhp"
	], ['h', 49, 0,'v', 280, 0,'o', ItemID.page, 0,'k', 397, 1]);
	
	
	
	
	
	
	
	
	IDRegistry.genItemID("dragon_giant_sword");
Item.createItem("dragon_giant_sword", "Dragon Giant Sword \n Rarity: Craftable \n Lv: Untimed \n Skill: No \n Damage: +70", {
    name: "dragon_giant_sword", meta: 0
}, {stack: 1});

ToolAPI.addToolMaterial("bone", {durability: 3000, level: 4, efficiency: 4, damage: 70, enchantability: 30});
ToolAPI.setTool(ItemID.dragon_giant_sword, "bone", ToolType.sword);
	
	 Recipes.addShaped({id: ItemID.dragon_giant_sword, count: 1, data: 0}, [
		"ohh",
		"akh",
		"vap"
	], ['v', 280, 0,'a', ItemID.livingmetal, 0,'o', ItemID.page, 0,'k', 122, 0,'h', 49, 0]);




// file: Hexxit Core/Tools/Infinity Tools.js

function addUsageChangeCallback(id, replacement) {
	makeSimplifiedCallback(function(name, item) {
		if (name == "ItemUse" && !Entity.getSneaking(Player.get())) return;
		makeReplaceable(item, id, replacement);
	}, "ItemUse", "ItemUseNoTarget");
}

IDRegistry.genItemID("cosmSword");
Item.createItem("cosmSword", "§cSword of the Infinity \n Rarity: Extrеme Crafting \n Mode: Fly \n Lv: Creativity Level \n Damage: §bI§cN§aF§6I§dN§fI§9T§8Y", {
	name: "cosm_sword", meta: 0
}, { stack: 1 });
Item.setEnchantType("cosmSword", 16, 999999999);

ToolAPI.addToolMaterial("cosmsw", {
	durability: 999999999,
	level: 7, efficiency: 6,
	damage: 999999,
	enchantability: 14
});
ToolAPI.setTool(ItemID.cosmSword, "cosmsw", ToolType.sword);
Item.setToolRender(ItemID.cosmSword, true);


//
IDRegistry.genItemID("cosmPickaxe");
Item.createItem("cosmPickaxe", "§cWorld Braker \n Rarity: Extrеme Crafting \n Mode: Destroy \n Lv: Creativity Level \n Damage: 1000", {
	name: "infinity_pickaxe", meta: 0
}, { stack: 1 });
Item.setEnchantType("cosmPickaxe", 18, 10);

ToolAPI.addToolMaterial("cosmpi", {
	durability: 999999999,
	level: 10, efficiency: 10000,
	damage: 1000, enchantability: 14
});
ToolAPI.setTool(ItemID.cosmPickaxe, "cosmpi", ToolType.pickaxe);
Item.setToolRender(ItemID.cosmPickaxe, true);
//


IDRegistry.genItemID("cosmhammer");
Item.createItem("cosmhammer", "§cinfinity hammer \n Rarity: Extrеme Crafting \n Mode: Destroy&9×9 \n Lv: Creativity Level \n Damage: 1000", {
	name: "infinity_hammer", meta: 0
}, { stack: 1 });
ToolAPI.setTool(ItemID.cosmhammer, "cosmpi", ToolType.pickaxe);
Item.setToolRender(ItemID.cosmhammer, true);



Callback.addCallback("DestroyBlock", function(coords, block, player) {
	if (Player.getCarriedItem().id == ItemID.cosmhammer) {
		var side = coords.side, x = 8, y = 9, z = 7;
		if (side == 4 || side == 5) x = 0;
		if (side == 1 || side == 6) y = 0;
		if (side == 2 || side == 3) z = 0;
		for (var xx = coords.x - x; xx <= coords.x + x; xx++) {
			for (var yy = coords.y - y; yy <= coords.y + y; yy++) {
				for (var zz = coords.z - z; zz <= coords.z + z; zz++) {
					if (World.getBlockID(xx, yy, zz) !== 7) {
						World.setBlock(xx, yy, zz, 0);
					}
				}
			}
		}
	}
});

IDRegistry.genItemID("cosmShovel");
Item.createItem("cosmShovel", "§cPlanet Eater \n Rarity: Extrеme Crafting \n Lv: Creativity Level \n Damage: 1000", {
	name: "infinity_shovel", meta: 0
}, { stack: 1 });

ToolAPI.addToolMaterial("cosmsh", {
	durability: 999999999,
	level: 8, efficiency: 1000,
	damage: 1000,
	enchantability: 14
});
ToolAPI.setTool(ItemID.cosmShovel, "cosmsh", ToolType.shovel);
Item.setToolRender(ItemID.cosmShovel, true);

IDRegistry.genItemID("cosmdes");
Item.createItem("cosmdes", "§cdestroyer \n Rarity: Extrеme Crafting \n Mode: Destroy&9×9 \n Lv: Creativity Level \n Damage: 1000", {
	name: "infinity_destroyer", meta: 0
}, { stack: 1 });
ToolAPI.setTool(ItemID.cosmdes, "cosmsh", ToolType.pickaxe);
Item.setToolRender(ItemID.cosmdes, true);



var DESTROYER_BLOCKS = [14, 15, 16, 21, 56, 73, 129, 49, 7];
DESTROYER_BLOCKS.hasId = function(id) {
	return this.indexOf(id) != -1;
};

Callback.addCallback("DestroyBlock", function(coords, block, player) {
	if (Player.getCarriedItem().id == ItemID.cosmdes) {
		var side = coords.side, x = 8, y = 9, z = 7;
		if (side == 4 || side == 5) x = 0;
		if (side == 1 || side == 6) y = 0;
		if (side == 2 || side == 3) z = 0;
		for (var xx = coords.x - x; xx <= coords.x + x; xx++) {
			for (var yy = coords.y - y; yy <= coords.y + y; yy++) {
				for (var zz = coords.z - z; zz <= coords.z + z; zz++) {
					if (!DESTROYER_BLOCKS.hasId(World.getBlockID(xx, yy, zz))) {
						World.setBlock(xx, yy, zz, 0);
					}
				}
			}
		}
	}
});

IDRegistry.genItemID("cosmAxe");
Item.createItem("cosmAxe", "§cNature's Ruin \n Rarity: Extrеme Crafting \n Lv: Creativity Level \n Damage: 1000", {
	name: "infinity_axe", meta: 0
}, { stack: 1 });

ToolAPI.addToolMaterial("cosmaxe", {
	durability: 999999999,
	level: 9, efficiency: 1000,
	damage: 1000, enchantability: 14
});
ToolAPI.setTool(ItemID.cosmAxe, "cosmaxe", ToolType.axe);
Item.setToolRender(ItemID.cosmAxe, true);
//
Block.setDestroyTime(ItemID.cosmSword, 3);
//







// file: Hexxit Core/Tools/Hammer Tools.js


var hammers = {
	addItem: function(id, material, i1, i2){
IDRegistry.genItemID(id + "hammer");
Item.createItem(id + "hammer", id + " hammer", {name: id + "hammer", meta: 0}, {stack: 1});
Item.setToolRender(ItemID[id + "hammer"], true);
ToolAPI.registerTool(ItemID[id + "hammer"], material, ["stone"], {damage: 5});
Callback.addCallback("PostLoaded", function(){
Recipes.addShaped({id: ItemID[id + "hammer"], count: 1, data: 0}, [
	"aaa",
	"aba",
	" b "
], ['a', i1, 0, 'b', i2, -1]);});
	}
}

ToolAPI.addToolMaterial("gold", {
      durability: 1360, 
      level: 10, 
      efficiency: 20, 
      damage: 15, 
      enchantability: 15
});

/*ToolAPI.addToolMaterial("obsidian", {
      durability: 3600, 
      level: 20, 
      efficiency: 20, 
      damage: 0, 
      enchantability: 15
});
*/


hammers.addItem("wood", "wood", 17, 5);
hammers.addItem("stone", "stone", 1, 5);
hammers.addItem("gold", "gold", 41, 5);
hammers.addItem("iron", "iron", 42, 5);
hammers.addItem("diamond", "diamond", 57, 5);
//hammers.addItem("obsidian", "obsidian", 49, 5);


Item.addCreativeGroup("hammmer", Translation.translate("hammmer"), [
	ItemID.woodhammer,
	ItemID.stonehammer,
	ItemID.goldhammer,
	ItemID.ironhammer,
	ItemID.diamondhammer,
	ItemID.netherite_hammer,
]);





Item.setEnchantType(ItemID.woodhammer, Native.EnchantType.pickaxe, 14);
Item.setEnchantType(ItemID.stonehammer, Native.EnchantType.pickaxe, 14);
Item.setEnchantType(ItemID.goldhammer, Native.EnchantType.pickaxe, 50);
Item.setEnchantType(ItemID.ironhammer, Native.EnchantType.pickaxe, 14);
Item.setEnchantType(ItemID.diamondhammer, Native.EnchantType.pickaxe, 14);


Item.addRepairItemIds(ItemID.woodhammer, [17]);
Item.addRepairItemIds(ItemID.stonehammer, [4]);
Item.addRepairItemIds(ItemID.goldhammer, [266]);
Item.addRepairItemIds(ItemID.ironhammer, [265]);
Item.addRepairItemIds(ItemID.diamondhammer, [264]);

Callback.addCallback("DestroyBlock", function(coords, block, player){

var side = coords.side;

var X = 1;
var Y = 1;
var Z = 1;

if(side==4 || side==5){
            X = 0;}
            if(side==1 || side==6){
            Y = 0;}
            if(side==2 || side==3){
            Z = 0;}
for(var xx = coords.x - X; xx <= coords.x + X; xx++){
                for(var yy = coords.y - Y; yy <= coords.y + Y; yy++){
                    for(var zz = coords.z - Z; zz <= coords.z + Z; zz++){
item=Player.getCarriedItem(true);
if(World.getBlockID(xx, yy, zz) !== 7&&item.id==ItemID.woodhammer||World.getBlockID(xx, yy, zz) !== 7&&item.id==ItemID.stonehammer||World.getBlockID(xx, yy, zz) !== 7&&item.id==ItemID.goldhammer||World.getBlockID(xx, yy, zz) !== 7&&item.id==ItemID.ironhammer||World.getBlockID(xx, yy, zz) !== 7&&item.id==ItemID.diamondhammer||World.getBlockID(xx, yy, zz) !== 7&&item.id==ItemID.netherite_hammer){
World.destroyBlock(xx, yy, zz, true);}}}};});


IDRegistry.genItemID("netherite_hammer");
Item.createItem("netherite_hammer", "netherite hammer", {
	name: "netherite_hammer", meta: 0
}, { stack: 1 });
ToolAPI.addToolMaterial("netherite", {
	durability: 2300,
	level: 5, efficiency: 20,
	damage: 29, enchantability: 15
});
ToolAPI.setTool(ItemID.netherite_hammer, "netherite", ToolType.pickaxe);














// file: Hexxit Core/Armor/Hexxit Armor.js

IDRegistry.genItemID("sageHelmet");
Item.createArmorItem("sageHelmet", "Sage Helmet \n Skill:§aTrue", {name: "sagehelmet"}, {type: "helmet", armor: 3, durability: 1500, texture: "armor/sagelayer_1.png"});

IDRegistry.genItemID("sageChestplate");
Item.createArmorItem("sageChestplate", "Sage Chestplate \n Skill:§aTrue", {name: "sagechest"}, {type: "chestplate", armor: 8, durability: 1500, texture: "armor/sagelayer_1.png"});

IDRegistry.genItemID("sageLeggings");
Item.createArmorItem("sageLeggings", "Sage Leggings \n Skill:§aTrue", {name: "sagelegs"}, {type: "leggings", armor: 6, durability: 1500, texture: "armor/sagelayer_2.png"});

IDRegistry.genItemID("sageBoots");
Item.createArmorItem("sageBoots", "Sage Boots \n Skill:§aTrue", {name: "sageboots"}, {type: "boots", armor: 3, durability: 176, texture: "armor/sagelayer_1.png"});


//2
IDRegistry.genItemID("scaleHelmet");
Item.createArmorItem("scaleHelmet", "Scale Helmet \n Skill:§aTrue", {name: "scalehelmet"}, {type: "helmet", armor: 3, durability: 1500, texture: "armor/scalelayer_1.png"});

IDRegistry.genItemID("scaleChestplate");
Item.createArmorItem("scaleChestplate", "Scale Chestplate \n Skill:§aTrue", {name: "scalechest"}, {type: "chestplate", armor: 8, durability: 1500, texture: "armor/scalelayer_1.png"});

IDRegistry.genItemID("scaleLeggings");
Item.createArmorItem("scaleLeggings", "Scale Leggings \n Skill:§aTrue", {name: "scalelegs"}, {type: "leggings", armor: 6, durability: 1500, texture: "armor/scalelayer_2.png"});

IDRegistry.genItemID("scaleBoots");
Item.createArmorItem("scaleBoots", "Scale Boots \n Skill:§aTrue", {name: "scaleboots"}, {type: "boots", armor: 3, durability: 176, texture: "armor/scalelayer_1.png"});

//3
IDRegistry.genItemID("thiefHelmet");
Item.createArmorItem("thiefHelmet", "Thief Helmet \n Skill:§aTrue", {name: "thiefhelmet"}, {type: "helmet", armor: 3, durability: 1500, texture: "armor/thieflayer_1.png"});

IDRegistry.genItemID("thiefChestplate");
Item.createArmorItem("thiefChestplate", "Thief Chestplate \n Skill:§aTrue", {name: "thiefchest"}, {type: "chestplate", armor: 8, durability: 1500, texture: "armor/thieflayer_1.png"});

IDRegistry.genItemID("thiefLeggings");
Item.createArmorItem("thiefLeggings", "Thief Leggings \n Skill:§aTrue", {name: "thieflegs"}, {type: "leggings", armor: 6, durability: 1500, texture: "armor/thieflayer_2.png"});

IDRegistry.genItemID("thiefBoots");
Item.createArmorItem("thiefBoots", "Thief Boots \n Skill:§aTrue", {name: "thiefboots"}, {type: "boots", armor: 3, durability: 1500, texture: "armor/thieflayer_1.png"});

//4
IDRegistry.genItemID("tribalHelmet");
Item.createArmorItem("tribalHelmet", "Tribal Helmet \n Skill:§aTrue", {name: "tribalhelmet"}, {type: "helmet", armor: 3, durability: 1500, texture: "armor/tribalhelm.png"});

IDRegistry.genItemID("tribalChestplate");
Item.createArmorItem("tribalChestplate", "Tribal Chestplate \n Skill:§aTrue", {name: "tribalchest"}, {type: "chestplate", armor: 8, durability: 1500, texture: "armor/triballayer_1.png"});

IDRegistry.genItemID("tribalLeggings");
Item.createArmorItem("tribalLeggings", "Tribal Leggings \n Skill:§aTrue", {name: "triballegs"}, {type: "leggings", armor: 6, durability: 1500, texture: "armor/triballayer_2.png"});

IDRegistry.genItemID("tribalBoots");
Item.createArmorItem("tribalBoots", "Tribal Boots \n Skill:§aTrue", {name: "tribalboots"}, {type: "boots", armor: 3, durability: 1500, texture: "armor/triballayer_1.png"});


Callback.addCallback("GenerateChunk", function(chunkX, chunkZ){
	var coords = GenerationUtils.randomCoords(chunkX, chunkZ, 64, 128);
	coords = GenerationUtils.findSurface(coords.x, coords.y, coords.z);
	if(Math.random()< __config__.access("HexGenNumber") ){
		if((World.getBiome((chunkX + 0.5) * 16, (chunkZ + 0.5) * 16)==id)){
			World.setBlock(coords.x, coords.y + 1, coords.z, BlockID.hexibiscus, 0);
		}
	}
});

Recipes.addShaped({id: ItemID.diamondHexical, count: 1, data: 0}, [
	" b ",
	"bab",
	" b "
], ['a', 264, 0, 'b', ItemID.essenceHexical, 0]);
Recipes.addShaped({id: ItemID.sageHelmet, count: 1, data: 0}, [
	" b ",
	"cac",
	"d d"
], ['a', ItemID.diamondHexical, 0,'b', 340, 0,'c', 49, 0, 'd',35,0]);

Recipes.addShaped({id: ItemID.sageChestplate, count: 1, data: 0}, [
	"c c",
	"dad",
	"cbc"
], ['a', ItemID.diamondHexical, 0, 'b', 35, 0,'c', 266, 0, 'd',340,0]);

Recipes.addShaped({id: ItemID.sageLeggings, count: 1, data: 0}, [
	"bcb",
	"dad",
	"b b"
], ['a', ItemID.diamondHexical, 0,'b', 266, 0,'c', 35, 0, 'd',340,0]);

Recipes.addShaped({id: ItemID.sageBoots, count: 1, data: 0}, [
	"bab",
	"c c",
	"   "
], ['a', ItemID.diamondHexical, 0,'b', 340, 0, 'c',35,0]);

Recipes.addShaped({id: ItemID.scaleHelmet, count: 1, data: 0}, [
	"bbb",
	"cac"
], ['a', ItemID.diamondHexical, 0,'b', 49, 0,'c', 266, 0]);

Recipes.addShaped({id: ItemID.scaleChestplate, count: 1, data: 0}, [
	"c c",
	"bab",
	"cbc"
], ['a', ItemID.diamondHexical, 0, 'b', 49, 0,'c', 266, 0]);

Recipes.addShaped({id: ItemID.scaleLeggings, count: 1, data: 0}, [
	"bbb",
	"cac",
	"b b"
], ['a', ItemID.diamondHexical, 0,'b', 49, 0,'c', 266, 0]);

Recipes.addShaped({id: ItemID.scaleBoots, count: 1, data: 0}, [
	"bab",
	"b b"
], ['a', ItemID.diamondHexical, 0,'b', 49, 0]);


Recipes.addShaped({id: ItemID.thiefHelmet, count: 1, data: 0}, [
	"bbb",
	"bab"
], ['a', ItemID.diamondHexical, 0,'b', 35, 14]);

Recipes.addShaped({id: ItemID.thiefChestplate, count: 1, data: 0}, [
	"b b",
	"cac",
	"ccc"
], ['a', ItemID.diamondHexical, 0, 'b', 35, 14,'c', 334, 0]);

Recipes.addShaped({id: ItemID.thiefLeggings, count: 1, data: 0}, [
	"bab",
	"bcb",
	"b b"
], ['a', ItemID.diamondHexical, 0,'b', 334, 0,'c', 287, 0]);

Recipes.addShaped({id: ItemID.thiefBoots, count: 1, data: 0}, [
	"cac",
	"b b"
], ['a', ItemID.diamondHexical, 0, 'b', 35, 7,'c', 334, 0]);


Recipes.addShaped({id: ItemID.tribalHelmet, count: 1, data: 0}, [
	"bbb",
	"bab"
], ['a', ItemID.diamondHexical, 0,'b', 352, 0]);

Recipes.addShaped({id: ItemID.tribalChestplate, count: 1, data: 0}, [
	"c c",
	"bab",
	"cbc"
], ['a', ItemID.diamondHexical, 0, 'b', 334, 0,'c', 265, 0]);

Recipes.addShaped({id: ItemID.tribalLeggings, count: 1, data: 0}, [
	"bbb",
	"cac",
	"b b"
], ['a', ItemID.diamondHexical, 0,'b', 334, 0,'c', 265, 0]);

Recipes.addShaped({id: ItemID.tribalBoots, count: 1, data: 0}, [
	"cac",
	"b b"
], ['a', ItemID.diamondHexical, 0,'b', 334, 0,'c', 287, 0]);



/*

var sageArmor = false;
var scaleArmor = false;
var thiefArmor = false;
var tribalArmor = false;
Callback.addCallback("tick", function(){
	if(World.getThreadTime()%120 == 0){
		if(World.getBlock(Player.getPosition().x-0.5, Player.getPosition ().y-0.8, Player.getPosition ().z-0.6).id == BlockID.hexibiscus){
			Entity.addEffect(Player.get(), Native.PotionEffect.absorption, 0, 20*5);
			Entity.addEffect(Player.get(), Native.PotionEffect.regeneration, 0, 20*5);
		}
	}
	var armor = [Player.getArmorSlot(0), Player.getArmorSlot(1), Player.getArmorSlot(2), Player.getArmorSlot(3)];
	if(World.getThreadTime()%50 == 0){
		if(armor[0].id == ItemID.sageHelmet&&armor[1].id == ItemID.sageChestplate&&armor[2].id == ItemID.sageLeggings&&armor[3].id == ItemID.sageBoots){
			sageArmor = true;
			Entity.addEffect(Player.get(), Native.PotionEffect.waterBreathing, 0, 20*15);
			Entity.addEffect(Player.get(), Native.PotionEffect.absorption, 2, 20*15);
			Entity.addEffect(Player.get(), Native.PotionEffect.fireResistance, 1, 20*15);
			Entity.addEffect(Player.get(), Native.PotionEffect.nightVision, 0, 20*15);
		}else if(sageArmor) Entity.clearEffects (Player.get()), sageArmor = false;
		
		if(armor[0].id == ItemID.scaleHelmet&&armor[1].id == ItemID.scaleChestplate&&armor[2].id == ItemID.scaleLeggings&&armor[3].id == ItemID.scaleBoots){
			scaleArmor = true;
			Entity.addEffect(Player.get(), Native.PotionEffect.damageBoost, 0, 20*15);
			Entity.addEffect(Player.get(), Native.PotionEffect.damageResistance, 0, 20*15);
			Entity.addEffect(Player.get(), Native.PotionEffect.fireResistance, 1, 20*15);
		}else if(scaleArmor) Entity.clearEffects (Player.get()), scaleArmor = false;

		if(armor[0].id == ItemID.thiefHelmet&&armor[1].id == ItemID.thiefChestplate&&armor[2].id == ItemID.thiefLeggings&&armor[3].id == ItemID.thiefBoots){
			thiefArmor = true;
			Entity.addEffect(Player.get(), Native.PotionEffect.nightVision, 0, 20*15);
			Entity.addEffect(Player.get(), Native.PotionEffect.movementSpeed, 2, 20*15);
			Entity.addEffect(Player.get(), Native.PotionEffect.damageBoost, 0, 20*15);
			Entity.addEffect(Player.get(), Native.PotionEffect.jump, 0, 20*15);
		}else if(thiefArmor) Entity.clearEffects (Player.get()), thiefArmor = false;

		if(armor[0].id == ItemID.tribalHelmet&&armor[1].id == ItemID.tribalChestplate&&armor[2].id == ItemID.tribalLeggings&&armor[3].id == ItemID.tribalBoots){
			tribalArmor = true;
			Entity.addEffect(Player.get(), Native.PotionEffect.nightVision, 0, 20*15);
			Entity.addEffect(Player.get(), Native.PotionEffect.digSpeed, 1, 20*15);
			Entity.addEffect(Player.get(), Native.PotionEffect.jump, 2, 20*15);
		}else if(tribalArmor) Entity.clearEffects (Player.get()), tribalArmor = false;
	}


});
*/
//1
IDRegistry.genItemID("st1");
IDRegistry.genItemID("st2");
IDRegistry.genItemID("st3");
IDRegistry.genItemID("st4");

Item.createArmorItem("st1", " steeleaf Helmet", {name: "sh1"}, {type: "helmet", armor: 3, durability: 1100, texture: "armor/sk1_1.png"});
Item.createArmorItem("st2", " steeleaf Chestplate", {name: "sh2"}, {type: "chestplate", armor: 4, durability: 1100, texture: "armor/sk1_1.png"});
Item.createArmorItem("st3", " steeleaf Leggings", {name: "sh3"}, {type: "leggings", armor: 4, durability: 1100, texture: "armor/sk2_2.png"});
Item.createArmorItem("st4", " steeleaf Boots", {name: "sh4"}, {type: "boots", armor: 3, durability: 1100, texture: "armor/sk1_1.png"});



Recipes.addShaped({id: ItemID.st1, count: 1, data: 0}, [
	"xxx",
	"xox",
	"ooo"
], ['x', ItemID.steeleaf, 0]);

Recipes.addShaped({id: ItemID.st2, count: 1, data: 0}, [
	"xox",
	"xxx",
	"xxx"
], ['x', ItemID.steeleaf, 0]);

Recipes.addShaped({id: ItemID.st3, count: 1, data: 0}, [
	"xxx",
	"xox",
	"xox"
], ['x', ItemID.steeleaf, 0]);

Recipes.addShaped({id: ItemID.st4, count: 1, data: 0}, [
	"ooo",
	"xox",
	"xox"
], ['x', ItemID.steeleaf, 0]);



IDRegistry.genItemID("lol");
IDRegistry.genItemID("loz");

Item.createArmorItem("lol", " fantom Helmet", {name: "fantom1"}, {type: "helmet", armor: 6, durability: 1100, texture: "armor/fan1_1.png"});
Item.createArmorItem("loz", " fantom Chestplate", {name: "fantom2"}, {type: "chestplate", armor: 9, durability: 1100, texture: "armor/fan1_1.png"});

IDRegistry.genItemID("armor1");
IDRegistry.genItemID("armor2");
IDRegistry.genItemID("armor3");
IDRegistry.genItemID("armor4");

Item.createArmorItem("armor1", " ironwood Helmet", {name: "cr1"}, {type: "helmet", armor: 3, durability: 1100, texture: "armor/cr1_1.png"});
Item.createArmorItem("armor2", " ironwood Chestplate", {name: "cr2"}, {type: "chestplate", armor: 4, durability: 1100, texture: "armor/cr1_1.png"});
Item.createArmorItem("armor3", " ironwood Leggings", {name: "cr3"}, {type: "leggings", armor: 4, durability: 1100, texture: "armor/cr2_2.png"});
Item.createArmorItem("armor4", " ironwood Boots", {name: "cr4"}, {type: "boots", armor: 3, durability: 1100, texture: "armor/cr1_1.png"});



Recipes.addShaped({id: ItemID.armor1, count: 1, data: 0}, [
	"xxx",
	"xox",
	"ooo"
], ['x', ItemID.ironwood, 0]);

Recipes.addShaped({id: ItemID.armor2, count: 1, data: 0}, [
	"xox",
	"xxx",
	"xxx"
], ['x', ItemID.ironwood, 0]);

Recipes.addShaped({id: ItemID.armor3, count: 1, data: 0}, [
	"xxx",
	"xox",
	"xox"
], ['x', ItemID.ironwood, 0]);

Recipes.addShaped({id: ItemID.armor4, count: 1, data: 0}, [
	"ooo",
	"xox",
	"xox"
], ['x', ItemID.ironwood, 0]);
//fiery
IDRegistry.genItemID("fieryH");
IDRegistry.genItemID("fieryC");
IDRegistry.genItemID("fieryL");
IDRegistry.genItemID("fieryB");

Item.createArmorItem("fieryH", "Fiery Helmet \n Skill:§aTrue", {name: "FH1"}, {type: "helmet", armor: 6, durability: 1100, texture: "armor/FA1_1.png"});
Item.createArmorItem("fieryC", "Fiery Chestplate \n Skill:§aTrue", {name: "FC2"}, {type: "chestplate", armor: 7, durability: 1100, texture: "armor/FA1_1.png"});
Item.createArmorItem("fieryL", "Fiery Leggings \n Skill:§aTrue", {name: "FL3"}, {type: "leggings", armor: 7, durability: 1100, texture: "armor/FA2_2.png"});
Item.createArmorItem("fieryB", "Fiery Boots \n Skill:§aTrue", {name: "FB4"}, {type: "boots", armor: 6, durability: 1100, texture: "armor/FA1_1.png"});

Item.setGlint("fieryH", true);
Item.setGlint("fieryC", true);
Item.setGlint("fieryL", true);
Item.setGlint("fieryB", true);

Recipes.addShaped({id: ItemID.fieryH, count: 1, data: 0}, [
	"xxx",
	"xox",
	"ooo"
], ['x', ItemID.fint, 0]);

Recipes.addShaped({id: ItemID.fieryC, count: 1, data: 0}, [
	"xox",
	"xxx",
	"xxx"
], ['x', ItemID.fint, 0]);

Recipes.addShaped({id: ItemID.fieryL, count: 1, data: 0}, [
	"xxx",
	"xox",
	"xox"
], ['x', ItemID.fint, 0]);

Recipes.addShaped({id: ItemID.fieryB, count: 1, data: 0}, [
	"ooo",
	"xox",
	"xox"
], ['x', ItemID.fint, 0]);
//var armor all




// file: Hexxit Core/Armor/Infinity Armor.js



IDRegistry.genItemID("infinity_helmet");
IDRegistry.genItemID("infinity_chestplate");
IDRegistry.genItemID("infinity_leggings");
IDRegistry.genItemID("infinity_boots");
//IDRegistry.genItemID("fff");

Item.createArmorItem("infinity_helmet",
"infinity_helmet \n Armor:§cNull \n §aSkill:§aTrue",{name:"infinity_helmet"},{type: "helmet",armor:null,durability:1111110,texture: "armor/infinity1_1.png"});
Item.createArmorItem("infinity_chestplate",
"infinity_chestplate \n Armor:§cNull \n §aSkill:§aTrue",{name:"infinity_chestplate"},{type: "chestplate",armor:null,durability:1111110,texture: "armor/infinity1_1.png"});
Item.createArmorItem("infinity_leggings",
"infinity_leggings \n Armor:§cNull \n §aSkill:§aTrue",{name:"infinity_leggings"},{type: "leggings",armor:null,durability:11111100,texture: "armor/infinity2_2.png"});
Item.createArmorItem("infinity_boots",
"infinity_boots \n Armor:§cNull \n §aSkill:§aTrue",{name:"infinity_boots"},{type: "boots",armor:null,durability:11111100,texture: "armor/infinity2_2.png"});

Callback.addCallback('EntityHurt', function (attacker, victim, damageValue, damageType, someBool1, someBool2) {
let item = Player.getCarriedItem();
if(victim== Player.get()){
if(item.id==ItemID.cosmSword){
Game.prevent();
  }
 }
 if(victim== Player.get()){
   if(Entity.getArmorSlot(Player.get(), 0).id == ItemID.infinity_helmet &&Entity.getArmorSlot(Player.get(), 1).id == ItemID.infinity_chestplate &&Entity.getArmorSlot(Player.get(), 2).id == ItemID.infinity_leggings &&Entity.getArmorSlot(Player.get(), 3).id == ItemID.infinity_boots){
  Game.prevent();
  }
}});


Callback.addCallback("tick", function(){
    var helmet = Player.getArmorSlot(0);
    var chest = Player.getArmorSlot(1);
    var legs = Player.getArmorSlot(2);
    var boots = Player.getArmorSlot(3);
    var pos = Player.getPosition();
if (helmet.id == ItemID.infinity_helmet && chest.id == ItemID.infinity_chestplate && legs.id == ItemID.infinity_leggings && boots.id == ItemID.infinity_boots) {
    
    Entity.addEffect(Player.get(), Native.PotionEffect.regeneration, 25, 20);
    
   }
});







// file: Hexxit Core/Work Bech/Ex Crafting.js





IDRegistry.genBlockID("extCraft");
Block.createBlockWithRotation("extCraft", [{
	name: "Extrеme Crafting \n Update: Infinity",
	texture: [["crafting", 2],
 ["craftingtop", 0],
 ["craftingside", 0],
  ["craftingside", 0],
   ["craftingside", 0],
    ["craftingside", 0]],
	inCreative: true
}], "opaque");
Block.setDestroyTime(BlockID.extCraft, 4);
ToolAPI.registerBlockMaterial(BlockID.extCraft, "stone", 3, true);


var ext_crafting = new UI.StandartWindow({
    standart: {
        header: {text: {text: Translation.translate("Extrеme Table")}},
        inventory: {standart:true},
        background: {standart: true},
    },
    drawing: [{
        type: "bitmap",
        bitmap: "plus",
        x: 450,
        y: 170,
        scale: 4
    },{
    	type: "bitmap",
        bitmap: "arrow",
        x: 640,
        y: 170,
        scale: 4
   },{
   	type: "bitmap",
       bitmap: "infinity",
       x: 350,
       y: 90,
       scale: 5
    },{
       type: "text",
       text: Translation.translate("Upgrade  Infinity Armor and tools..."),
       x: 435,
       y: 130,
       font: {color: Color.BLACK},
       scale: 1
    }],
    elements:{
        "inputSlot0":{x:350, y:170, type:"slot"},
        "inputSlot1":{x:550, y:170, type:"slot"/*, bitmap: "ingotplace"*/},

        "outputSlot":{x:750, y:170, type:"slot"}
    }
});

TileEntity.registerPrototype(BlockID.extCraft, {
	useNetworkItemContainer: true,
	
	getScreenName: function(player, coords) {
        return "main";
    },
    getScreenByName: function(screenName) {
        return ext_crafting;
    },
    
    init: function () {
    	this.container.setSlotAddTransferPolicy("outputSlot", function(container, name, id, amount, data, extra, playerUid){return 0;})//result slot
    
        this.container.setSlotAddTransferPolicy("inputSlot0", function(container, name, id, amount, data, extra, playerUid)
		{
			if (container.getSlot("inputSlot0").count == 1) {
				return 0;
			}else{
				return 1;
			}
		}) //base slot
		
		this.container.setSlotAddTransferPolicy("inputSlot1", function(container, name, id, amount, data, extra, playerUid)
		{
			if (container.getSlot("inputSlot1").count == 1) {
				return 0;
			}else{
				return 1;
			}
		}) //netherite slot
		
		this.container.setSlotGetTransferPolicy("outputSlot", function(container, name, id, amount, data, extra, playerUid)
		{
			container.getSlot("inputSlot1").id = 0
			container.getSlot("inputSlot1").count = 0
			container.getSlot("inputSlot0").id = 0
			container.getSlot("inputSlot0").count = 0
			return 1;
		})
    },
    
    destroy: function(){
    	this.container.getSlot("outputSlot").id = 0
		this.container.getSlot("outputSlot").count = 0
    },
	
	tick: function(){
		var baseSlot = this.container.getSlot("inputSlot0");
		var netheriteSlot = this.container.getSlot("inputSlot1");
		var resultSlot = this.container.getSlot("outputSlot");
		var extraTemp;
		var extraData;
		
		
		if(baseSlot.id == 310 && IDRegistry.getNameByID(netheriteSlot.id) == "infinityingot") {
			extraTemp = baseSlot.extra
			extraData = baseSlot.data
			resultSlot.id = ItemID.infinity_helmet
			resultSlot.count = 1;
			this.container.setSlot("outputSlot", this.container.getSlot("outputSlot").id, 1, extraData, extraTemp);
			//fiery  chestplate
		} else if(baseSlot.id == 311 && IDRegistry.getNameByID(netheriteSlot.id) == "infinityingot") {
			extraTemp = baseSlot.extra
			extraData = baseSlot.data
			resultSlot.id = ItemID.infinity_chestplate
			resultSlot.count = 1;
			this.container.setSlot("outputSlot", this.container.getSlot("outputSlot").id, 1, extraData, extraTemp);
			//fiery  leggings
		} else if(baseSlot.id == 312 && IDRegistry.getNameByID(netheriteSlot.id) == "infinityingot") {
			extraTemp = baseSlot.extra
			extraData = baseSlot.data
			resultSlot.id = ItemID.infinity_leggings
			resultSlot.count = 1;
			this.container.setSlot("outputSlot", this.container.getSlot("outputSlot").id, 1, extraData, extraTemp);
			//fiery  boots
		} else if(baseSlot.id == 313 && IDRegistry.getNameByID(netheriteSlot.id) == "infinityingot") {
			extraTemp = baseSlot.extra
			extraData = baseSlot.data
			resultSlot.id = ItemID.infinity_boots
			resultSlot.count = 1;
			this.container.setSlot("outputSlot", this.container.getSlot("outputSlot").id, 1, extraData, extraTemp);
			//magic1 sword
		
		
			//
			 } else if(baseSlot.id == 277 && IDRegistry.getNameByID(netheriteSlot.id) == "infinityingot") {
			extraTemp = baseSlot.extra
			extraData = baseSlot.data
			resultSlot.id = ItemID.cosmShovel
			resultSlot.count = 1;
			this.container.setSlot("outputSlot", this.container.getSlot("outputSlot").id, 1, extraData, extraTemp);
			//
			 } else if(baseSlot.id == 279 && IDRegistry.getNameByID(netheriteSlot.id) == "infinityingot") {
			extraTemp = baseSlot.extra
			extraData = baseSlot.data
			resultSlot.id = ItemID.cosmAxe
			resultSlot.count = 1;
			this.container.setSlot("outputSlot", this.container.getSlot("outputSlot").id, 1, extraData, extraTemp);
			//
		 } else if(baseSlot.id == 276 && IDRegistry.getNameByID(netheriteSlot.id) == "infinityingot") {
			extraTemp = baseSlot.extra
			extraData = baseSlot.data
			resultSlot.id = ItemID.cosmSword
			resultSlot.count = 1;
			this.container.setSlot("outputSlot", this.container.getSlot("outputSlot").id, 1, extraData, extraTemp);
			} else if(baseSlot.id == 278 && IDRegistry.getNameByID(netheriteSlot.id) == "infinityingot") {
			extraTemp = baseSlot.extra
			extraData = baseSlot.data
			resultSlot.id = ItemID.cosmPickaxe
			resultSlot.count = 1;
			this.container.setSlot("outputSlot", this.container.getSlot("outputSlot").id, 1, extraData, extraTemp);
		}else{
			resultSlot.id = 0
			resultSlot.count = 0;
			this.container.setSlot("outputSlot", this.container.getSlot("outputSlot").id, 0, 0);
		}
        
		//visual final
		if (baseSlot.count == 0) {
			this.container.setSlot("inputSlot0", 0, 0, 0);
		}
		if (netheriteSlot.count == 0) {
			this.container.setSlot("inputSlot1", 0, 0, 0);
		}
		this.container.validateAll()
	}
});
//recipe 
Recipes.addShaped({id: BlockID.extCraft, count: 1, data: 0}, [
		"ooo",
		"ana",
		"aaa"
	], ['n', ItemID.infinityingot, 0,'a', 42, 0,'o', 57, 0]);






// file: Hexxit Core/Work Bech/Mini Update Skill.js

var SBInventory = {
    isEnabled: false,
    container: new UI.Container(),
    windowContainer: new UI.Container(),
    buttonWindow: new UI.Window({
        location: {
            x: -170,
            y: -180,
            width: 50,
            height: 50
        },
        drawing:[
            {type: "background", color: 0}
        ],
        elements:{
            "fuckButton":{type: "button", x: 0, y: 0, scale: 31, bitmap: "icon", clicker:{onClick:function(){
                SBInventory.windowContainer.openAs(SBInventory.Window);
            }}}
        }
    }), 
    Window: new UI.StandartWindow({
        standart:{
			header: {text: {text: "Skill Tools Update"}},
            backgroud:{
                standart: true
            },
            inventory:{
                standart: true
            }
        },
        elements:{
		"inputSlot0": {type: "slot", x: 430, y: 180, size: 71}, 
		"inputSlot1": {type: "slot", x: 520, y: 180, size: 71},
		"image_0": {type: "image", x: 611, y: 180, bitmap: "arrow", scale: 4.5},
		"outputSlot": {type: "slot", x: 720, y: 180, size: 71, isValid:RecipeTE.outputSlotValid}
        } 
    }),
    open:function(){
        if(!this.isEnabled){
            this.container.openAs(this.buttonWindow);
            this.isEnabled = true;
        }
    },
    close:function(){
        if(this.isEnabled){
            this.container.close();
            this.isEnabled = false;
        }
    }
};

SBInventory.buttonWindow.setAsGameOverlay(true);

Callback.addCallback("NativeGuiChanged", function (screenName) {
	//alert(screenName);
    if(screenName == "inventory_screen"){
        SBInventory.open();
    }else if(SBInventory.isEnabled){
        SBInventory.close();
    }
});


var getSlot = SBInventory.windowContainer.getSlot;
var clearSlot = SBInventory.windowContainer.clearSlot;
Callback.addCallback("tick", function (){
if(SBInventory.isEnabled&&SBInventory.windowContainer.isOpened()){
 
   if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.dragon_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.fire_skill_untimed
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.dragon_giant_sword_fire_untimed, 1, 0);
}
 if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.dragon_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.ice_skill_untimed
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.dragon_giant_sword_ice_untimed, 1, 0);
}
//Legend Recipe
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.wooden_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.ice_skill_legend
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.wooden_giant_sword_ice_legend, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.stone_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.ice_skill_legend
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.stone_giant_sword_ice_legend, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.iron_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.ice_skill_legend
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.iron_giant_sword_ice_legend, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.gold_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.ice_skill_legend
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.gold_giant_sword_ice_legend, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.diamond_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.ice_skill_legend
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.diamond_giant_sword_ice_legend, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.emerald_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.ice_skill_legend
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.emerald_giant_sword_ice_legend, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.ender_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.ice_skill_legend
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.ender_giant_sword_ice_legend, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.livingmetal_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.ice_skill_legend
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.livingmetal_giant_sword_ice_legend, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.quartz_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.ice_skill_legend
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.quartz_giant_sword_ice_legend, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.netherrack_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.ice_skill_legend
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.netherrack_giant_sword_ice_legend, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.bone_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.ice_skill_legend
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.bone_giant_sword_ice_legend, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.obsidian_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.ice_skill_legend
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.obsidian_giant_sword_ice_legend, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.netherite_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.ice_skill_legend
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.netherite_giant_sword_ice_legend, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.wither_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.ice_skill_legend
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.wither_giant_sword_ice_legend, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.dragon_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.ice_skill_legend
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.dragon_giant_sword_ice_legend, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.wooden_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.fire_skill_legend
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.wooden_giant_sword_fire_legend, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.stone_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.fire_skill_legend
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.stone_giant_sword_fire_legend, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.iron_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.fire_skill_legend
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.iron_giant_sword_fire_legend, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.gold_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.fire_skill_legend
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.gold_giant_sword_fire_legend, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.diamond_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.fire_skill_legend
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.diamond_giant_sword_fire_legend, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.emerald_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.fire_skill_legend
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.emerald_giant_sword_fire_legend, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.ender_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.fire_skill_legend
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.ender_giant_sword_fire_legend, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.livingmetal_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.fire_skill_legend
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.livingmetal_giant_sword_fire_legend, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.quartz_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.fire_skill_legend
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.quartz_giant_sword_fire_legend, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.netherrack_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.fire_skill_legend
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.netherrack_giant_sword_fire_legend, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.bone_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.fire_skill_legend
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.bone_giant_sword_fire_legend, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.obsidian_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.fire_skill_legend
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.obsidian_giant_sword_fire_legend, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.netherite_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.fire_skill_legend
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.netherite_giant_sword_fire_legend, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.wither_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.fire_skill_legend
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.wither_giant_sword_fire_legend, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.dragon_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.fire_skill_legend
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.dragon_giant_sword_fire_legend, 1, 0);
}//untimed
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.wooden_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.ice_skill_untimed
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.wooden_giant_sword_ice_untimed, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.stone_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.ice_skill_untimed
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.stone_giant_sword_ice_untimed, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.iron_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.ice_skill_untimed
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.iron_giant_sword_ice_untimed, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.gold_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.ice_skill_untimed
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.gold_giant_sword_ice_untimed, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.diamond_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.ice_skill_untimed
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.diamond_giant_sword_ice_untimed, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.emerald_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.ice_skill_untimed
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.emerald_giant_sword_ice_untimed, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.ender_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.ice_skill_untimed
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.ender_giant_sword_ice_untimed, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.livingmetal_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.ice_skill_untimed
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.livingmetal_giant_sword_ice_untimed, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.quartz_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.ice_skill_untimed
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.quartz_giant_sword_ice_untimed, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.netherrack_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.ice_skill_untimed
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.netherrack_giant_sword_ice_untimed, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.bone_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.ice_skill_untimed
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.bone_giant_sword_ice_untimed, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.obsidian_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.ice_skill_untimed
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.obsidian_giant_sword_ice_untimed, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.netherite_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.ice_skill_untimed
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.netherite_giant_sword_ice_untimed, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.wither_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.ice_skill_untimed
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.wither_giant_sword_ice_untimed, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.dragon_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.ice_skill_untimed
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.dragon_giant_sword_ice_untimed, 1, 0);
}
//fire
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.wooden_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.fire_skill_untimed
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.wooden_giant_sword_fire_untimed, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.stone_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.fire_skill_untimed
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.stone_giant_sword_fire_untimed, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.iron_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.fire_skill_untimed
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.iron_giant_sword_fire_untimed, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.gold_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.fire_skill_untimed
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.gold_giant_sword_fire_untimed, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.diamond_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.fire_skill_untimed
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.diamond_giant_sword_fire_untimed, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.emerald_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.fire_skill_untimed
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.emerald_giant_sword_fire_untimed, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.ender_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.fire_skill_untimed
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.ender_giant_sword_fire_untimed, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.livingmetal_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.fire_skill_untimed
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.livingmetal_giant_sword_fire_untimed, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.quartz_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.fire_skill_untimed
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.quartz_giant_sword_fire_untimed, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.netherrack_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.fire_skill_untimed
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.netherrack_giant_sword_fire_untimed, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.bone_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.fire_skill_untimed
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.bone_giant_sword_fire_untimed, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.obsidian_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.fire_skill_untimed
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.obsidian_giant_sword_fire_untimed, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.netherite_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.fire_skill_untimed
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.netherite_giant_sword_fire_untimed, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.wither_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.fire_skill_untimed
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.wither_giant_sword_fire_untimed, 1, 0);
}
if(SBInventory.windowContainer.getSlot("inputSlot0").id == ItemID.dragon_giant_sword &&
      SBInventory.windowContainer.getSlot("inputSlot1").id == ItemID.fire_skill_untimed
      
){
      SBInventory.windowContainer.clearSlot("inputSlot0");
      SBInventory.windowContainer.clearSlot("inputSlot1");
      SBInventory.windowContainer.setSlot("outputSlot", ItemID.dragon_giant_sword_fire_untimed, 1, 0);
}



}
});





// file: Hexxit Core/Block/Tree Block/Log.js

IDRegistry.genBlockID("twDarkLog");
IDRegistry.genBlockID("twMangroveLog");
IDRegistry.genBlockID("twCanopyLog");
IDRegistry.genBlockID("twTwilightOakLog");
IDRegistry.genBlockID("twMiningLog");
IDRegistry.genBlockID("twSortingLog");
IDRegistry.genBlockID("twTimeLog");
IDRegistry.genBlockID("twTransformationLog");

Block.createBlock("twDarkLog", [{
    name: "Dark Log",
    texture: [
        ["twDarkLog_top", 0],
        ["twDarkLog_top", 0],
        ["twDarkLog", 0],
        ["twDarkLog", 0],
        ["twDarkLog", 0],
        ["twDarkLog", 0],], inCreative: true, }
], {destroytime: 2.25, sound: "wood"});
ToolAPI.registerBlockMaterial(BlockID.twDarkLog, "wood", 1, true);
Block.setDestroyLevel("twDarkLog", 0);
        
        
Block.createBlock("twCanopyLog", [{
    name: "Canopy Log",
    texture: [
        ["twCanopyLog_top", 0],
        ["twCanopyLog_top", 0],
        ["twCanopyLog", 0],
        ["twCanopyLog", 0],
        ["twCanopyLog", 0],
        ["twCanopyLog", 0],], inCreative: true, }
], {destroytime: 2.25, sound: "wood"});
ToolAPI.registerBlockMaterial(BlockID.twCanopyLog, "wood", 1, true);
Block.setDestroyLevel("twCanopyLog", 0);
        
        
        
        
Block.createBlock("twMangroveLog", [{
    name: "Mangrove Log",
    texture: [
        ["twMangroveLog_top", 0],
        ["twMangroveLog_top", 0],
        ["twMangroveLog", 0],
        ["twMangroveLog", 0],
        ["twMangroveLog", 0],
        ["twMangroveLog", 0],], inCreative: true, }
], {destroytime: 2.25, sound: "wood"});
ToolAPI.registerBlockMaterial(BlockID.twMangroveLog, "wood", 1, true);
Block.setDestroyLevel("twMangroveLog", 0);
        
        
        
        
Block.createBlock("twTwilightOakLog", [{
    name: "Twilight Oak Log",
    texture: [
        ["twTwilightOakLog_top", 0],
        ["twTwilightOakLog_top", 0],
        ["twTwilightOakLog", 0],
        ["twTwilightOakLog", 0],
        ["twTwilightOakLog", 0],
        ["twTwilightOakLog", 0],], inCreative: true, }
], {destroytime: 2.25, sound: "wood"});
ToolAPI.registerBlockMaterial(BlockID.twTwilightOakLog, "wood", 1, true);
Block.setDestroyLevel("twTwilightOakLog", 0);
        
        
        
        
        
Block.createBlock("twMiningLog", [{
    name: "Mining Log",
    texture: [
        ["twMiningLog_top", 0],
        ["twMiningLog_top", 0],
        ["twMiningLog", 0],
        ["twMiningLog", 0],
        ["twMiningLog", 0],
        ["twMiningLog", 0],], inCreative: true, }
], {destroytime: 2.25, sound: "wood"});
ToolAPI.registerBlockMaterial(BlockID.twMiningLog, "wood", 1, true);
Block.setDestroyLevel("twMiningLog", 0);
        
        
        
Block.createBlock("twSortingLog", [{
    name: "Sorting Log",
    texture: [
        ["twSortingLog_top", 0],
        ["twSortingLog_top", 0],
        ["twSortingLog", 0],
        ["twSortingLog", 0],
        ["twSortingLog", 0],
        ["twSortingLog", 0],], inCreative: true, }
], {destroytime: 2.25, sound: "wood"});
ToolAPI.registerBlockMaterial(BlockID.twSortingLog, "wood", 1, true);
Block.setDestroyLevel("twSortingLog", 0);
        
        
        
        
Block.createBlock("twTimeLog", [{
    name: "Time Log",
    texture: [
        ["twTimeLog_top", 0],
        ["twTimeLog_top", 0],
        ["twTimeLog", 0],
        ["twTimeLog", 0],
        ["twTimeLog", 0],
        ["twTimeLog", 0],], inCreative: true, }
], {destroytime: 2.25, sound: "wood"});
ToolAPI.registerBlockMaterial(BlockID.twTimeLog, "wood", 1, true);
Block.setDestroyLevel("twTimeLog", 0);
 

        
        
        
        
        
        
Block.createBlock("twTransformationLog", [{
    name: "Transformation Log",
    texture: [
        ["twTransformationLog_top", 0],
        ["twTransformationLog_top", 0],
        ["twTransformationLog", 0],
        ["twTransformationLog", 0],
        ["twTransformationLog", 0],
        ["twTransformationLog", 0],], inCreative: true, }
], {destroytime: 2.25, sound: "wood"});
ToolAPI.registerBlockMaterial(BlockID.twTransformationLog, "wood", 1, true);
Block.setDestroyLevel("twTransformationLog", 0);
        
        
        
        
        
        
        
        




// file: Hexxit Core/Block/Tree Block/Wood.js

//Register ID
IDRegistry.genBlockID("tw_planks_dark_wood");
IDRegistry.genBlockID("tw_planks_mangrove");
IDRegistry.genBlockID("tw_planks_canopy");
IDRegistry.genBlockID("tw_planks_twilight_oak");
IDRegistry.genBlockID("tw_planks_mine");
IDRegistry.genBlockID("tw_planks_sort");
IDRegistry.genBlockID("tw_planks_time");
IDRegistry.genBlockID("tw_planks_trans");

//Create Blocks
Block.createBlock("tw_planks_dark_wood", [{
    name: "Dark Wood Planks",
    texture: [
        ["tw_planks_darkwood", 0],
        ["tw_planks_darkwood", 0],
        ["tw_planks_darkwood", 0],
        ["tw_planks_darkwood", 0],
        ["tw_planks_darkwood", 0],
        ["tw_planks_darkwood", 0],], inCreative: true, }
], {destroytime: 2.25, sound: "wood"});
ToolAPI.registerBlockMaterial(BlockID.tw_planks_dark_wood, "wood", 0, true);
Block.setDestroyLevel("tw_planks_dark_wood", 0);
    

    
    
    
    
Block.createBlock("tw_planks_mangrove", [{
    name: "Mangrove Planks",
    texture: [
        ["tw_planks_mangrove", 0],
        ["tw_planks_mangrove", 0],
        ["tw_planks_mangrove", 0],
        ["tw_planks_mangrove", 0],
        ["tw_planks_mangrove", 0],
        ["tw_planks_mangrove", 0],], inCreative: true, }
], {destroytime: 2.25, sound: "wood"});
ToolAPI.registerBlockMaterial(BlockID.tw_planks_mangrove, "wood", 1, true);
Block.setDestroyLevel("tw_planks_mangrove", 0);
    


    
    
    
    
Block.createBlock("tw_planks_canopy", [{
    name: "Canopy Planks",
    texture: [
        ["tw_planks_canopy", 0],
        ["tw_planks_canopy", 0],
        ["tw_planks_canopy", 0],
        ["tw_planks_canopy", 0],
        ["tw_planks_canopy", 0],
        ["tw_planks_canopy", 0],], inCreative: true, }
], {destroytime: 2.25, sound: "wood"});
ToolAPI.registerBlockMaterial(BlockID.tw_planks_canopy, "wood", 1, true);
Block.setDestroyLevel("tw_planks_canopy", 0);
    

    
    
    
    
    
Block.createBlock("tw_planks_mine", [{
    name: "Mine Planks",
    texture: [
        ["tw_planks_mine", 0],
        ["tw_planks_mine", 0],
        ["tw_planks_mine", 0],
        ["tw_planks_mine", 0],
        ["tw_planks_mine", 0],
        ["tw_planks_mine", 0],], inCreative: true, }
], {destroytime: 2.25, sound: "wood"});
ToolAPI.registerBlockMaterial(BlockID.tw_planks_mine, "wood", 1, true);
Block.setDestroyLevel("tw_planks_mine", 0);
    

    
    
    
    
    
Block.createBlock("tw_planks_twilight_oak", [{
    name: "Twilight Oak Planks",
    texture: [
        ["tw_planks_twilight_oak", 0],
        ["tw_planks_twilight_oak", 0],
        ["tw_planks_twilight_oak", 0],
        ["tw_planks_twilight_oak", 0],
        ["tw_planks_twilight_oak", 0],
        ["tw_planks_twilight_oak", 0],], inCreative: true, }
], {destroytime: 2.25, sound: "wood"});
ToolAPI.registerBlockMaterial(BlockID.tw_planks_twilight_oak, "wood", 1, true);
Block.setDestroyLevel("tw_planks_twilight_oak", 0);
    

    
    
    
    
    
Block.createBlock("tw_planks_time", [{
    name: "Time Planks",
    texture: [
        ["tw_planks_time", 0],
        ["tw_planks_time", 0],
        ["tw_planks_time", 0],
        ["tw_planks_time", 0],
        ["tw_planks_time", 0],
        ["tw_planks_time", 0],], inCreative: true, }
], {destroytime: 2.25, sound: "wood"});
ToolAPI.registerBlockMaterial(BlockID.tw_planks_time, "wood", 1, true);
Block.setDestroyLevel("tw_planks_time", 0);
    

    
    
    
    
    
    
Block.createBlock("tw_planks_sort", [{
    name: "Sort Planks",
    texture: [
        ["tw_planks_sort", 0],
        ["tw_planks_sort", 0],
        ["tw_planks_sort", 0],
        ["tw_planks_sort", 0],
        ["tw_planks_sort", 0],
        ["tw_planks_sort", 0],],inCreative: true, }
], {destroytime: 2.25, sound: "wood"});
ToolAPI.registerBlockMaterial(BlockID.tw_planks_sort, "wood", 1, true);
Block.setDestroyLevel("tw_planks_sort", 0);
    

    
    
    
    
Block.createBlock("tw_planks_trans", [{
    name: "Transformation Planks",
    texture: [
        ["tw_planks_trans", 0],
        ["tw_planks_trans", 0],
        ["tw_planks_trans", 0],
        ["tw_planks_trans", 0],
        ["tw_planks_trans", 0],
        ["tw_planks_trans", 0],], inCreative: true, }
], {destroytime: 2.25, sound: "wood"});
ToolAPI.registerBlockMaterial(BlockID.tw_planks_trans, "wood", 1, true);
Block.setDestroyLevel("tw_planks_trans", 0);
    




// file: Hexxit Core/Block/Block.js

IDRegistry.genBlockID("infBlock");
Block.createBlock("infBlock", [{
	name: "Infinity block",
	texture: [["infinity", 0]],
	inCreative: true
}], "opaque");
Block.setDestroyTime(BlockID.infBlock, 3);
ToolAPI.registerBlockMaterial(BlockID.infBlock, "stone", 4, true);

Recipes.addShaped({id: BlockID.infBlock, count: 1, data: 0}, [
		"aaa",
		"aaa",
		"aaa"
	], ['a', ItemID.infinityingot, 0]);






IDRegistry.genBlockID("g1")
Block.createBlock("g1", [
    {name: " Sunset tiles", texture: [["g", 0], ["g", 0], ["g", 0], ["g", 0], ["g", 0], ["g", 0]], inCreative: false}
]);




IDRegistry.genBlockID("k1")
Block.createBlock("k1", [
    {name: " Sunset tiles1", texture: [["k", 0], ["k", 0], ["k", 0], ["k", 0], ["k", 0], ["k", 0]], inCreative: false}
]);

IDRegistry.genBlockID("may2")
Block.createBlock("may2", [
    {name: "maz stone", texture: [["may", 0], ["may", 0], ["may", 0], ["may", 0], ["may", 0], ["may", 0]], inCreative: false}
]);

IDRegistry.genBlockID("may1"); 
Block.createBlock("may1", [
    {name: "may stone", texture: 
[["may3", 0], ["may3",0], 
["may3", 0], ["may3", 0], 
["may3", 0], ["may3", 0]], inCreative: false}
]) ;












IDRegistry.genBlockID("lo")
Block.createBlock("lo", [
    {name: "maze", texture: [["may5", 1], ["may5", 1], ["may4", 1], ["may4", 1], ["may4", 1], ["may4", 1]], inCreative: false}
]);

IDRegistry.genBlockID("lo1")
Block.createBlock("lo1", [
    {name: "maze forever", texture: [["may5", 1], ["may5", 1], ["may6", 1], ["may6", 1], ["may6", 1], ["may6", 1]], inCreative: false}
]);

IDRegistry.genBlockID("toto1")
Block.createBlock("toto1", [
    {name: "stone TW", texture: [["toto1", 0], ["toto1", 0], ["toto1", 0], ["toto1", 0], ["toto1", 0], ["toto1", 0]], inCreative: false}
]);






IDRegistry.genBlockID("goden")
Block.createBlock("goden", [
    {name: " towerwood alt", texture: [["go", 0], ["go", 0], ["go", 0], ["go", 0], ["go", 0], ["go", 0]], inCreative: false}
]);

IDRegistry.genBlockID("oh")
Block.createBlock("oh", [
    {name: " towerwood encased", texture: [["go1", 0], ["go1", 0], ["go1", 0], ["go1", 0], ["go1", 0], ["go1", 0]], inCreative: false}
]);

IDRegistry.genBlockID("uk1")
Block.createBlock("uk1", [
    {name: " towerwood mossy", texture: [["go2", 0], ["go2", 0], ["go2", 0], ["go2", 0], ["go2", 0], ["go2", 0]], inCreative: false}
]);

IDRegistry.genBlockID("uk2")
Block.createBlock("uk2", [
    {name: " towerwood infested", texture: [["go3", 0], ["go3", 0], ["go3", 0], ["go3", 0], ["go3", 0], ["go3", 0]], inCreative: false}
]);

IDRegistry.genBlockID("uk3")
Block.createBlock("uk3", [
    {name: " towerdev reappearing off", texture: [["go4", 0], ["go4", 0], ["go4", 0], ["go4", 0], ["go4", 0], ["go4", 0]], inCreative: false}
]);

IDRegistry.genBlockID("uk4")
Block.createBlock("uk4", [
    {name: " towerdev reappearing on", texture: [["go5", 0], ["go5", 0], ["go5", 0], ["go5", 0], ["go5", 0], ["go5", 0]], inCreative: false}
]);








IDRegistry.genBlockID("twBlockPortal")
Block.createBlock("twBlockPortal", [
    {name: "twilight forest block portal", texture: [["dirt_day", 1], ["tw_top", 1], ["tw", 0], ["tw", 0], ["tw", 0], ["tw", 0]], inCreative: true}
]);
Recipes.addShaped({id: BlockID.twBlockPortal, count: 1, data: 0}, [
		"ooo",
		"oxo",
		"ooo"
	], ['o', 3, 0, 'h', 326, 0]);




// file: Hexxit Core/Block/Block Trophy/Trophy Heart.js

IDRegistry.genBlockID("uk5")
Block.createBlock("uk5", [
    {name: "ghast health", texture: [["p11", 1], ["p11", 1], ["go6", 0], ["go6", 0], ["go6", 0], ["go6", 0]], inCreative: false }
]);

//

IDRegistry.genBlockID("he")
Block.createBlock("he", [
    {name: "naga health", texture: [["p11", 1], ["p11", 1], ["uk", 0], ["uk", 0], ["uk", 0], ["uk", 0]], inCreative: false }
]);

IDRegistry.genBlockID("boss")
Block.createBlock("boss", [ {name: "lich health", texture: [["p11", 1], ["p11", 1], ["boss12", 1], ["boss12", 1], ["boss22", 1], ["boss12", 1]], inCreative: false }]);

IDRegistry.genBlockID("hydraboss")
Block.createBlock("hydraboss", [
    {name: "hydra health", texture: [["p11", 1], ["p11", 1], ["hydra", 0], ["hydra", 0], ["hydra", 0], ["hydra", 0]], inCreative: false }
]);

IDRegistry.genBlockID("snowqueenboss")
Block.createBlock("snowqueenboss", [
    {name: "snow queen health", texture: [["p11", 1], ["p11", 1], ["snq", 0], ["snq", 0], ["snq", 0], ["snq", 0]], inCreative: false }
]);

//item spawn ugha
IDRegistry.genItemID("ughastTrophy");
Item.createItem("ughastTrophy", "Ur Ghast Trophy", {name: "UrGhastTrophy", meta: 0}, {stack: 1})

Callback.addCallback("ItemUse", function (coords, item, block) {
var hp = Entity.getMaxHealth(Player.get());
if(item.id == ItemID.ughastTrophy&&block.id !==0){
Player.setCarriedItem(item.id, item.count - 1, 0);
World.setBlock(coords.x, coords.y+1, coords.z, BlockID.uk5, 0);
}}); 
//naga


IDRegistry.genItemID("nagaTrophy");
Item.createItem("nagaTrophy", "Naga Trophy", {name: "nagaTrophy", meta: 0}, {stack: 1})
Callback.addCallback("ItemUse", function (coords, item, block) {
var hp = Entity.getMaxHealth(Player.get());
if(item.id == ItemID.nagaTrophy&&block.id !==0){
Player.setCarriedItem(item.id, item.count - 1, 0);
World.setBlock(coords.x, coords.y+1, coords.z, BlockID.he, 0);
}}); 
//lich


IDRegistry.genItemID("lichTrophy");
Item.createItem("lichTrophy", "Lich Trophy", {name: "lichTrophy", meta: 0}, {stack: 1})
Callback.addCallback("ItemUse", function (coords, item, block) {
var hp = Entity.getMaxHealth(Player.get());
if(item.id == ItemID.lichTrophy&&block.id !==0){
Player.setCarriedItem(item.id, item.count - 1, 0);
World.setBlock(coords.x, coords.y+1, coords.z, BlockID.boss, 0);
}}); 
//hydra

IDRegistry.genItemID("hydraTrophy");
Item.createItem("hydraTrophy", "Hydra Trophy", {name: "hydraTrophy", meta: 0}, {stack: 1})

Callback.addCallback("ItemUse", function (coords, item, block) {
var hp = Entity.getMaxHealth(Player.get());
if(item.id == ItemID.hydraTrophy&&block.id !==0){
Player.setCarriedItem(item.id, item.count - 1, 0);
World.setBlock(coords.x, coords.y+1, coords.z, BlockID.hydraboss, 0);

}});

IDRegistry.genItemID("snowQueenTrophy");
Item.createItem("snowQueenTrophy", "snow queen Trophy", {name: "snowQueenTrophy", meta: 0}, {stack: 1})

Callback.addCallback("ItemUse", function (coords, item, block) {
var hp = Entity.getMaxHealth(Player.get());
if(item.id == ItemID.snowQueenTrophy&&block.id !==0){
Player.setCarriedItem(item.id, item.count - 1, 0);
World.setBlock(coords.x, coords.y+1, coords.z, BlockID.snowqueenboss, 0);
}});



//drop
Item.addCreativeGroup("Trophy", Translation.translate("Trophy"), [
	ItemID.ughastTrophy,
	ItemID.lichTrophy,
	ItemID.nagaTrophy,
	ItemID.snowQueenTrophy,
	ItemID.hydraTrophy,
	
]);




// file: Hexxit Core/Block/Block Trophy/Trophy Table.js

//naga

IDRegistry.genBlockID("na1")
Block.createBlock("na1", [{name: "§a  NAGA ON", texture: [["p1", 1], ["p1", 1], ["na1", 0], ["na1", 0], ["na1", 0], ["na1", 0]], inCreative: true}]);


//lich

IDRegistry.genBlockID("o")
Block.createBlock("o", [{name: "§a LICH ON", texture: [["p1", 1], ["p1", 1], ["o1", 0], ["o1", 0], ["o1", 0], ["o1", 0]], inCreative: true}]);

//hydra 



IDRegistry.genBlockID("hydraOn")
Block.createBlock("hydraOn", [{name: "§a HYDRA ON", texture: [["p1", 1], ["p1", 1], ["hydra", 1], ["hydra", 1], ["hydra", 1], ["hydra", 1]], inCreative: true}]);

//snow queen



IDRegistry.genBlockID("snowQueenOn")
Block.createBlock("snowQueenOn", [{name: "§a SNOW QUEEN ON", texture: [["p1", 1], ["p1", 1], ["snowqueen", 1], ["snowqueen", 1], ["snowqueen", 1], ["snowqueen", 1]], inCreative: true}]);

//ughast
IDRegistry.genBlockID("ughastOn")
Block.createBlock("ughastOn", [
    {name: "§a UGHAST ON", texture: [["p1", 1], ["p1", 1], ["ugh", 2], ["ugh", 2], ["ugh", 2], ["ugh", 2]], inCreative: true}]);





//group 
Item.addCreativeGroup("temple summoning", Translation.translate("temple summoning"), [
	 BlockID.na1,
	 BlockID.o,
	 BlockID.ughastOn,
	 
	 BlockID.snowQueenOn,
	 
	 BlockID.hydraOn,
	 
]);





// file: Hexxit Core/Dimensions/THE TWILIGHT FOREST/Portal.js







//
Callback.addCallback("ItemUse", function(coords, item, block) {
  if (item.id==264 && block.id== BlockID.twBlockPortal) {
  World.setBlock(coords.x, coords.y, coords.z, 0, 0) 
  World.setBlock(coords.x+2, coords.y+1, coords.z, 2, 0);
World.setBlock(coords.x+2, coords.y+2, coords.z, 2, 0);
World.setBlock(coords.x+2, coords.y+3, coords.z, 2, 0);
World.setBlock(coords.x+2, coords.y+4, coords.z, 2, 0);
World.setBlock(coords.x+1, coords.y+4, coords.z, 2, 0);
World.setBlock(coords.x+1, coords.y+1, coords.z, 2, 0);
World.setBlock(coords.x, coords.y+4, coords.z, 2, 0);
World.setBlock(coords.x, coords.y+1, coords.z, 2, 0);

World.setBlock(coords.x-1, coords.y+1, coords.z, 2, 0);
World.setBlock(coords.x-1, coords.y+2, coords.z, 2, 0);
World.setBlock(coords.x-1, coords.y+3, coords.z, 2, 0);
World.setBlock(coords.x-1, coords.y+4, coords.z, 2, 0);
//
World.setBlock(coords.x+1, coords.y+2, coords.z, BlockID.twPortal, 0); 
World.setBlock(coords.x+1, coords.y+3, coords.z, BlockID.twPortal, 0); 
World.setBlock(coords.x, coords.y+2, coords.z, BlockID.twPortal, 0); 
World.setBlock(coords.x, coords.y+3, coords.z, BlockID.twPortal, 0); 
Entity.spawn(coords.x, coords.y+1, coords.z, 93); 
  Player.decreaseCarriedItem(1)
  Particles.addParticle(Native.ParticleType.hugeexplosion, coords.x + 0.5, coords.y + 0.5, coords.z + 0.5, 0, 0.1, 0, 0);
  World.playSound(coords.x, coords.y, coords.z, "random.explode", 3)
  World.destroyBlock(coords.x, coords.y, coords.z, 1)
}
});













// file: Hexxit Core/Dimensions/THE TWILIGHT FOREST/Twilight Forest.js

var twilightforest1 = new Dimensions.CustomDimension("twilightforest1", 1345); 

 
 Callback.addCallback("ItemUse", function(coords, item) {
    
    if (item.id == ItemID.twpo) {
        Dimensions.transfer(Player.get(), Player.getDimension() == 0 ? twilightforest1.id : 0);
    }
})
twilightforest1.setGenerator(Dimensions.newGenerator({
    layers: [
        {
            minY: 0, maxY: 70, 
            yConversion: [[.0, 0], [0, 0]],
            material: {base: 1, surface: {id: 3, data: 0, width:4}, cover: 2}, 
            noise: {
                octaves: {count: 4, scale: 20}
            }
        }
    ]
}));

PortalUtils.newPortalBlock("twPortal", ["twilightforest1_portal", 0], {type: "v-plane", frameId: 2}, true);

var shapeTw = new PortalShape();
shapeTw.setPortalId(BlockID.twPortal);
shapeTw.setFrameIds(BlockID.twPortal);
shapeTw.setMinSize(2, 3);

Callback.addCallback("ItemUse", function(coords, item, block){ 
if (Player.getCarriedItem().id == ItemID.congtw) 
var rect = shapeTw.findPortal(coords.relative.x, coords.relative.y, coords.relative.z);
  if (rect) {
            shapeTw.buildPortal(rect, false);      
   }
}); 
    
Callback.addCallback("DestroyBlock", function(pos, block) { 
    if (block.id == 2 || block.id == BlockID.twPortal) {
        DimensionHelper.eliminateIncorrectPlacedPortals(pos, BlockID.twPortal, [2]);
    }
}); 

Callback.addCallback("tick", function() {
var crdsP = Player.getPosition();
if (World.getBlock(crdsP.x, crdsP.y, crdsP.z).id == BlockID.twPortal && Player.getDimension().id != twilightforest1.id) {
    Dimensions.transfer(Player.get(), twilightforest1.id);
   shapeTw.buildPortal(crdsP.x, crdsP.y, crdsP.z, true); 
    } else {
      if (World.getBlock(crdsP.x, crdsP.y, crdsP.z).id == BlockID.twPortal && Player.getDimension().id != twilightforest1.id)
       Dimensions.transfer(Player.get(), twilightforest1.id);   
      shapeTw.buildPortal(crdsP.x, crdsP.y, crdsP.z, true); 
    }
});





// file: Hexxit Core/Dimensions/THE TWILIGHT FOREST/Mob Spawn Dimensions.js

//spawn firefly 

Callback.addCallback("GenerateCustomDimensionChunk", function(chunkX, chunkZ, random, dimensionId){
    if(dimensionId <= twilightforest1.id){
        if(Math.random()<=0.3){
            var coords = GenerationUtils.randomCoords(chunkX, chunkZ, 5, 10);
            coords = GenerationUtils.findSurface(coords.x, coords.y, coords.z);
           let bs = BlockSource.getDefaultForDimension(dimensionId);
bs = BlockSource.getCurrentWorldGenRegion();
bs.spawnEntity(coords.x, coords.y+3, coords.z, "hexxit:firefly");
} 
} 
});
//bò
Callback.addCallback("GenerateCustomDimensionChunk", function(chunkX, chunkZ, random, dimensionId){
    if(dimensionId <= twilightforest1.id){
        if(Math.random()<=0.06){
            var coords = GenerationUtils.randomCoords(chunkX, chunkZ, 5, 10);
            coords = GenerationUtils.findSurface(coords.x, coords.y, coords.z);
           let bs = BlockSource.getDefaultForDimension(dimensionId);
bs = BlockSource.getCurrentWorldGenRegion();
bs.spawnEntity(coords.x, coords.y+1, coords.z, "hexxit:minotaur");
} 
} 
});
//golem
Callback.addCallback("GenerateCustomDimensionChunk", function(chunkX, chunkZ, random, dimensionId){
    if(dimensionId <= twilightforest1.id){
        if(Math.random()<=0.06){
            var coords = GenerationUtils.randomCoords(chunkX, chunkZ, 5, 10);
            coords = GenerationUtils.findSurface(coords.x, coords.y, coords.z);
           let bs = BlockSource.getDefaultForDimension(dimensionId);
bs = BlockSource.getCurrentWorldGenRegion();
bs.spawnEntity(coords.x, coords.y+1, coords.z, "hexxit:tower_golem");
} 
} 
});




// file: Hexxit Core/Dimensions/THE TWILIGHT FOREST/Tree/trans tree.js

Callback.addCallback("GenerateCustomDimensionChunk", function(chunkX, chunkZ, random, dimensionId){
    if(dimensionId==twilightforest1.id){
let coords = GenerationUtils.randomCoords(chunkX, chunkZ, 64, 128);
    if(Math.random() < 0.6){
    coords = GenerationUtils.findSurface(coords.x, coords.y, coords.z);

if(World.getBlock(coords.x,coords.y+1,coords.z).id === 0 && GenerationUtils.canSeeSky(coords.x, coords.y + 1, coords.z)) { 
       World.setBlock(coords.x+6, coords.y+1, coords.z+11, BlockID.twTransformationLog, 0); 
World.setBlock(coords.x+6, coords.y+2, coords.z+11, BlockID.twTransformationLog, 0); 
World.setBlock(coords.x+6, coords.y+3, coords.z+11, BlockID.twTransformationLog, 0); 
World.setBlock(coords.x+6, coords.y+4, coords.z+11, BlockID.twTransformationLog, 0); 
World.setBlock(coords.x+6, coords.y+5, coords.z+11, BlockID.twTransformationLog, 0); 
//
World.setBlock(coords.x+7, coords.y+1, coords.z+11, BlockID.twTransformationLog, 0); 
World.setBlock(coords.x+7, coords.y+2, coords.z+11, BlockID.twTransformationLog, 0); 
//
World.setBlock(coords.x+8, coords.y+1, coords.z+11, BlockID.twTransformationLog, 0); 
World.setBlock(coords.x+8, coords.y+1, coords.z+10, BlockID.twTransformationLog, 0); 
//
World.setBlock(coords.x+9, coords.y+1, coords.z+10, BlockID.twTransformationLog, 0); 
World.setBlock(coords.x+9, coords.y+2, coords.z+10, BlockID.twTransformationLog, 0); 
//
World.setBlock(coords.x+8, coords.y, coords.z+12, BlockID.twTransformationLog, 0); 
World.setBlock(coords.x+8, coords.y+1, coords.z+12, BlockID.twTransformationLog, 0); 
//
//
World.setBlock(coords.x+5, coords.y+8, coords.z+12, BlockID.twTransformationLog, 0); 
World.setBlock(coords.x+5, coords.y+7, coords.z+12, BlockID.twTransformationLog, 0); 
//
World.setBlock(coords.x+6, coords.y+8, coords.z+11, BlockID.twTransformationLog, 0); 
World.setBlock(coords.x+6, coords.y+7, coords.z+11, BlockID.twTransformationLog, 0); 
//
World.setBlock(coords.x+5, coords.y+7, coords.z+11, BlockID.twTransformationLog, 0); 
World.setBlock(coords.x+5, coords.y+6, coords.z+11, BlockID.twTransformationLog, 0); 
World.setBlock(coords.x+5, coords.y+5, coords.z+11, BlockID.twTransformationLog, 0); 
World.setBlock(coords.x+5, coords.y+4, coords.z+11, BlockID.twTransformationLog, 0); 
World.setBlock(coords.x+5, coords.y+6, coords.z+10, BlockID.twTransformationLog, 0);
//
//
World.setBlock(coords.x+9, coords.y, coords.z+12, BlockID.twTransformationLog, 0); 
World.setBlock(coords.x+9, coords.y, coords.z+13, BlockID.twTransformationLog, 0); 
World.setBlock(coords.x+9, coords.y, coords.z+14, BlockID.twTransformationLog, 0); 
//
World.setBlock(coords.x+6, coords.y+1, coords.z+12, BlockID.twTransformationLog, 0); 
World.setBlock(coords.x+6, coords.y, coords.z+12, BlockID.twTransformationLog, 0); 
//
World.setBlock(coords.x+5, coords.y+1, coords.z+11, BlockID.twTransformationLog, 0); 
World.setBlock(coords.x+5, coords.y, coords.z+11, BlockID.twTransformationLog, 0);
//
World.setBlock(coords.x+6, coords.y+1, coords.z+10, BlockID.twTransformationLog, 0); 
World.setBlock(coords.x+6, coords.y, coords.z+10, BlockID.twTransformationLog, 0); 
 World.setBlock(coords.x+6, coords.y, coords.z+9, BlockID.twTransformationLog, 0); 
World.setBlock(coords.x+4, coords.y, coords.z+12, BlockID.twTransformationLog, 0); 

//lá
World.setBlock(coords.x+5, coords.y+9, coords.z+15, 18, 0); 
World.setBlock(coords.x+5, coords.y+9, coords.z+14, 18, 0); 
//
World.setBlock(coords.x+6, coords.y+9, coords.z+14, 18, 0); 
World.setBlock(coords.x+6, coords.y+9, coords.z+13, 18, 0); 
//
World.setBlock(coords.x+7, coords.y+9, coords.z+14, 18, 0); 
World.setBlock(coords.x+7, coords.y+9, coords.z+13, 18, 0); 
World.setBlock(coords.x+7, coords.y+9, coords.z+12, 18, 0); 
World.setBlock(coords.x+7, coords.y+9, coords.z+11, 18, 0); 
World.setBlock(coords.x+7, coords.y+9, coords.z+10, 18, 0); 
//
World.setBlock(coords.x+4, coords.y+9, coords.z+9, 18, 0); 
//
World.setBlock(coords.x+8, coords.y+9, coords.z+11, 18, 0); 
World.setBlock(coords.x+8, coords.y+9, coords.z+10, 18, 0); 
//
World.setBlock(coords.x+6, coords.y+9, coords.z+12, 18, 0); 
World.setBlock(coords.x+6, coords.y+9, coords.z+11, 18, 0); 
World.setBlock(coords.x+6, coords.y+9, coords.z+10, 18, 0); 
World.setBlock(coords.x+6, coords.y+9, coords.z+9, 18, 0); 
//
World.setBlock(coords.x+5, coords.y+9, coords.z+13, 18, 0); 
World.setBlock(coords.x+5, coords.y+9, coords.z+12, 18, 0); 
World.setBlock(coords.x+5, coords.y+9, coords.z+11, 18, 0); 
World.setBlock(coords.x+5, coords.y+9, coords.z+10, 18, 0); 
World.setBlock(coords.x+5, coords.y+9, coords.z+9, 18, 0); 
World.setBlock(coords.x+5, coords.y+9, coords.z+8, 18, 0); 
//
World.setBlock(coords.x+4, coords.y+9, coords.z+13, 18, 0); 
World.setBlock(coords.x+4, coords.y+9, coords.z+12, 18, 0); 
World.setBlock(coords.x+4, coords.y+9, coords.z+11, 18, 0); 
World.setBlock(coords.x+4, coords.y+9, coords.z+10, 18, 0); 
World.setBlock(coords.x+4, coords.y+9, coords.z+9, 18, 0); 
//
World.setBlock(coords.x+3, coords.y+9, coords.z+12, 18, 0); 
World.setBlock(coords.x+3, coords.y+9, coords.z+11, 18, 0); 
World.setBlock(coords.x+3, coords.y+9, coords.z+10, 18, 0); 
World.setBlock(coords.x+3, coords.y+9, coords.z+9, 18, 0); 
//
World.setBlock(coords.x+2, coords.y+9, coords.z+11, 18, 0); 
//
//
World.setBlock(coords.x+4, coords.y+10, coords.z+9, 18, 0); 
World.setBlock(coords.x+4, coords.y+10, coords.z+10, 18, 0); 
World.setBlock(coords.x+4, coords.y+10, coords.z+11, 18, 0); 
//
World.setBlock(coords.x+5, coords.y+10, coords.z+12, 18, 0); 
World.setBlock(coords.x+5, coords.y+10, coords.z+11, 18, 0); 
World.setBlock(coords.x+5, coords.y+10, coords.z+10, 18, 0); 
//
World.setBlock(coords.x+6, coords.y+10, coords.z+13, 18, 0); 
World.setBlock(coords.x+6, coords.y+10, coords.z+12, 18, 0); 
World.setBlock(coords.x+6, coords.y+10, coords.z+11, 18, 0); 
World.setBlock(coords.x+6, coords.y+10, coords.z+10, 18, 0); 
//
World.setBlock(coords.x+7, coords.y+10, coords.z+11, 18, 0); 
//
//
World.setBlock(coords.x+4, coords.y+8, coords.z+11, 18, 0); 
World.setBlock(coords.x+6, coords.y+8, coords.z+10, 18, 0); 
World.setBlock(coords.x+5, coords.y+8, coords.z+10, 18, 0); 
//
World.setBlock(coords.x+7, coords.y+10, coords.z+11, 18, 0); 
World.setBlock(coords.x+6, coords.y+10, coords.z+12, 18, 0); 
World.setBlock(coords.x+5, coords.y+10, coords.z+13, 18, 0); 
World.setBlock(coords.x+4, coords.y+10, coords.z+12, 18, 0); 


} 
} 
}
});




// file: Hexxit Core/Dimensions/THE TWILIGHT FOREST/Tree/tree canopy.js


Callback.addCallback("GenerateCustomDimensionChunk", function(chunkX, chunkZ, random, dimensionId){
    if(dimensionId==twilightforest1.id){
let coords = GenerationUtils.randomCoords(chunkX, chunkZ, 64, 128);
    if(Math.random() < 0.6){
    coords = GenerationUtils.findSurface(coords.x, coords.y, coords.z);

if(World.getBlock(coords.x,coords.y+1,coords.z).id === 0 && GenerationUtils.canSeeSky(coords.x, coords.y + 1, coords.z)) { 



World.setBlock(coords.x+6, coords.y+1, coords.z+11, BlockID.twCanopyLog, 0); 
World.setBlock(coords.x+6, coords.y+2, coords.z+11, BlockID.twCanopyLog, 0); 
World.setBlock(coords.x+6, coords.y+3, coords.z+11, BlockID.twCanopyLog, 0); 
World.setBlock(coords.x+6, coords.y+4, coords.z+11, BlockID.twCanopyLog, 0); 
World.setBlock(coords.x+6, coords.y+5, coords.z+11, BlockID.twCanopyLog, 0); 
//
World.setBlock(coords.x+7, coords.y+1, coords.z+11, BlockID.twCanopyLog, 0); 
World.setBlock(coords.x+7, coords.y+2, coords.z+11, BlockID.twCanopyLog, 0); 
//
World.setBlock(coords.x+8, coords.y+1, coords.z+11, BlockID.twCanopyLog, 0); 
World.setBlock(coords.x+8, coords.y+1, coords.z+10, BlockID.twCanopyLog, 0); 
//
World.setBlock(coords.x+9, coords.y+1, coords.z+10, BlockID.twCanopyLog, 0); 
World.setBlock(coords.x+9, coords.y+2, coords.z+10, BlockID.twCanopyLog, 0); 
//
World.setBlock(coords.x+8, coords.y, coords.z+12, BlockID.twCanopyLog, 0); 
World.setBlock(coords.x+8, coords.y+1, coords.z+12, BlockID.twCanopyLog, 0); 
//
//
World.setBlock(coords.x+5, coords.y+8, coords.z+12, BlockID.twCanopyLog, 0); 
World.setBlock(coords.x+5, coords.y+7, coords.z+12, BlockID.twCanopyLog, 0); 
//
World.setBlock(coords.x+6, coords.y+8, coords.z+11, BlockID.twCanopyLog, 0); 
World.setBlock(coords.x+6, coords.y+7, coords.z+11, BlockID.twCanopyLog, 0); 
//
World.setBlock(coords.x+5, coords.y+7, coords.z+11, BlockID.twCanopyLog, 0); 
World.setBlock(coords.x+5, coords.y+6, coords.z+11, BlockID.twCanopyLog, 0); 
World.setBlock(coords.x+5, coords.y+5, coords.z+11, BlockID.twCanopyLog, 0); 
World.setBlock(coords.x+5, coords.y+4, coords.z+11, BlockID.twCanopyLog, 0); 
World.setBlock(coords.x+5, coords.y+6, coords.z+10, BlockID.twCanopyLog, 0);
//
//
World.setBlock(coords.x+9, coords.y, coords.z+12, BlockID.twCanopyLog, 0); 
World.setBlock(coords.x+9, coords.y, coords.z+13, BlockID.twCanopyLog, 0); 
World.setBlock(coords.x+9, coords.y, coords.z+14, BlockID.twCanopyLog, 0); 
//
World.setBlock(coords.x+6, coords.y+1, coords.z+12, BlockID.twCanopyLog, 0); 
World.setBlock(coords.x+6, coords.y, coords.z+12, BlockID.twCanopyLog, 0); 
//
World.setBlock(coords.x+5, coords.y+1, coords.z+11, BlockID.twCanopyLog, 0); 
World.setBlock(coords.x+5, coords.y, coords.z+11, BlockID.twCanopyLog, 0);
//
World.setBlock(coords.x+6, coords.y+1, coords.z+10, BlockID.twCanopyLog, 0); 
World.setBlock(coords.x+6, coords.y, coords.z+10, BlockID.twCanopyLog, 0); 
 World.setBlock(coords.x+6, coords.y, coords.z+9, BlockID.twCanopyLog, 0); 
World.setBlock(coords.x+4, coords.y, coords.z+12, BlockID.twCanopyLog, 0); 

//lá
World.setBlock(coords.x+5, coords.y+9, coords.z+15, 18, 0); 
World.setBlock(coords.x+5, coords.y+9, coords.z+14, 18, 0); 
//
World.setBlock(coords.x+6, coords.y+9, coords.z+14, 18, 0); 
World.setBlock(coords.x+6, coords.y+9, coords.z+13, 18, 0); 
//
World.setBlock(coords.x+7, coords.y+9, coords.z+14, 18, 0); 
World.setBlock(coords.x+7, coords.y+9, coords.z+13, 18, 0); 
World.setBlock(coords.x+7, coords.y+9, coords.z+12, 18, 0); 
World.setBlock(coords.x+7, coords.y+9, coords.z+11, 18, 0); 
World.setBlock(coords.x+7, coords.y+9, coords.z+10, 18, 0); 
//
World.setBlock(coords.x+4, coords.y+9, coords.z+9, 18, 0); 
//
World.setBlock(coords.x+8, coords.y+9, coords.z+11, 18, 0); 
World.setBlock(coords.x+8, coords.y+9, coords.z+10, 18, 0); 
//
World.setBlock(coords.x+6, coords.y+9, coords.z+12, 18, 0); 
World.setBlock(coords.x+6, coords.y+9, coords.z+11, 18, 0); 
World.setBlock(coords.x+6, coords.y+9, coords.z+10, 18, 0); 
World.setBlock(coords.x+6, coords.y+9, coords.z+9, 18, 0); 
//
World.setBlock(coords.x+5, coords.y+9, coords.z+13, 18, 0); 
World.setBlock(coords.x+5, coords.y+9, coords.z+12, 18, 0); 
World.setBlock(coords.x+5, coords.y+9, coords.z+11, 18, 0); 
World.setBlock(coords.x+5, coords.y+9, coords.z+10, 18, 0); 
World.setBlock(coords.x+5, coords.y+9, coords.z+9, 18, 0); 
World.setBlock(coords.x+5, coords.y+9, coords.z+8, 18, 0); 
//
World.setBlock(coords.x+4, coords.y+9, coords.z+13, 18, 0); 
World.setBlock(coords.x+4, coords.y+9, coords.z+12, 18, 0); 
World.setBlock(coords.x+4, coords.y+9, coords.z+11, 18, 0); 
World.setBlock(coords.x+4, coords.y+9, coords.z+10, 18, 0); 
World.setBlock(coords.x+4, coords.y+9, coords.z+9, 18, 0); 
//
World.setBlock(coords.x+3, coords.y+9, coords.z+12, 18, 0); 
World.setBlock(coords.x+3, coords.y+9, coords.z+11, 18, 0); 
World.setBlock(coords.x+3, coords.y+9, coords.z+10, 18, 0); 
World.setBlock(coords.x+3, coords.y+9, coords.z+9, 18, 0); 
//
World.setBlock(coords.x+2, coords.y+9, coords.z+11, 18, 0); 
//
//
World.setBlock(coords.x+4, coords.y+10, coords.z+9, 18, 0); 
World.setBlock(coords.x+4, coords.y+10, coords.z+10, 18, 0); 
World.setBlock(coords.x+4, coords.y+10, coords.z+11, 18, 0); 
//
World.setBlock(coords.x+5, coords.y+10, coords.z+12, 18, 0); 
World.setBlock(coords.x+5, coords.y+10, coords.z+11, 18, 0); 
World.setBlock(coords.x+5, coords.y+10, coords.z+10, 18, 0); 
//
World.setBlock(coords.x+6, coords.y+10, coords.z+13, 18, 0); 
World.setBlock(coords.x+6, coords.y+10, coords.z+12, 18, 0); 
World.setBlock(coords.x+6, coords.y+10, coords.z+11, 18, 0); 
World.setBlock(coords.x+6, coords.y+10, coords.z+10, 18, 0); 
//
World.setBlock(coords.x+7, coords.y+10, coords.z+11, 18, 0); 
//
//
World.setBlock(coords.x+4, coords.y+8, coords.z+11, 18, 0); 
World.setBlock(coords.x+6, coords.y+8, coords.z+10, 18, 0); 
World.setBlock(coords.x+5, coords.y+8, coords.z+10, 18, 0); 
//
World.setBlock(coords.x+7, coords.y+10, coords.z+11, 18, 0); 
World.setBlock(coords.x+6, coords.y+10, coords.z+12, 18, 0); 
World.setBlock(coords.x+5, coords.y+10, coords.z+13, 18, 0); 
World.setBlock(coords.x+4, coords.y+10, coords.z+12, 18, 0); 



 









} 
} 
}
});




// file: Hexxit Core/Dimensions/THE TWILIGHT FOREST/Dimensions Structure/Ore.js





Callback.addCallback("GenerateCustomDimensionChunk", function(chunkX, chunkZ, random, dimensionId){
    if(dimensionId==twilightforest1.id){
if (Math.random()*5 <= 3){
    for(var i = 0; i < 2; i++){
        
        var coords = GenerationUtils.randomCoords(chunkX, chunkZ, 0, 20);
        GenerationUtils.generateOre(coords.x, coords.y+25, coords.z, 16, 0, 10, true);

} 
} 
}
});



Callback.addCallback("GenerateCustomDimensionChunk", function(chunkX, chunkZ, random, dimensionId){
    if(dimensionId==twilightforest1.id){
if (Math.random()*5 <= 2){
    for(var i = 0; i < 2; i++){
        
        var coords = GenerationUtils.randomCoords(chunkX, chunkZ, 0, 20);
        GenerationUtils.generateOre(coords.x, coords.y+21, coords.z, 15, 0, 10, true);

} 
} 
}
});



Callback.addCallback("GenerateCustomDimensionChunk", function(chunkX, chunkZ, random, dimensionId){
    if(dimensionId==twilightforest1.id){
if (Math.random()*5 <= 2){
    for(var i = 0; i < 2; i++){
        
        var coords = GenerationUtils.randomCoords(chunkX, chunkZ, 0, 20);
        GenerationUtils.generateOre(coords.x, coords.y+23, coords.z, 14, 0, 10, true);

} 
} 
}
});


Callback.addCallback("GenerateCustomDimensionChunk", function(chunkX, chunkZ, random, dimensionId){
    if(dimensionId==twilightforest1.id){
if (Math.random()*5 <= 1){
    for(var i = 0; i < 2; i++){
        
        var coords = GenerationUtils.randomCoords(chunkX, chunkZ, 0, 20);
        GenerationUtils.generateOre(coords.x, coords.y+11, coords.z, 56, 0, 10, true);

} 
} 
}
});




// file: Hexxit Core/Dimensions/THE TWILIGHT FOREST/Dimensions Structure/Structure Boss/Lich Structure.js

Callback.addCallback("GenerateCustomDimensionChunk", function(chunkX, chunkZ, random, dimensionId){
    if(dimensionId==twilightforest1.id){
let coords = GenerationUtils.randomCoords(chunkX, chunkZ, 64, 128);
    if(Math.random() < 0.005){
    coords = GenerationUtils.findSurface(coords.x, coords.y, coords.z);

if(World.getBlock(coords.x,coords.y+1,coords.z).id === 0 && GenerationUtils.canSeeSky(coords.x, coords.y + 1, coords.z)) { 
 World.setBlock(coords.x-1,coords.y+1,  coords.z+2, 98, 1);
       World.setBlock(coords.x,coords.y+1,  coords.z+2, 98, 1);
       World.setBlock(coords.x+1,coords.y+1,  coords.z+2, 98, 1);
       World.setBlock(coords.x+2,coords.y+1,  coords.z+1, 98, 1);
       World.setBlock(coords.x+1,coords.y+1,  coords.z+1, 98, 1);
       World.setBlock(coords.x,coords.y+1,  coords.z+1, 98, 1);
       World.setBlock(coords.x-1,coords.y+1,  coords.z+1, 98, 1);
       World.setBlock(coords.x-2,coords.y+1,  coords.z+1, 98, 1);
       //
       //
       World.setBlock(coords.x+2,coords.y+1,  coords.z, 98, 1);
       World.setBlock(coords.x+1,coords.y+1,  coords.z, 98, 1);
       World.setBlock(coords.x,coords.y+1,  coords.z, 98, 1); 
       World.setBlock(coords.x,coords.y+2,  coords.z, BlockID.o, 0);// boss
       
       World.setBlock(coords.x-1,coords.y+1,  coords.z, 98, 1);
       World.setBlock(coords.x-2,coords.y+1,  coords.z, 98, 1);
       //
       World.setBlock(coords.x+2,coords.y+1,  coords.z-1, 98, 1);
       World.setBlock(coords.x+1,coords.y+1,  coords.z-1, 98, 1);
       World.setBlock(coords.x,coords.y+1,  coords.z-1, 98, 1);
       World.setBlock(coords.x-1,coords.y+1,  coords.z-1, 98, 1);
       World.setBlock(coords.x-2,coords.y+1,  coords.z-1, 98, 1);
       //
       World.setBlock(coords.x-1,coords.y+1,  coords.z-2, 98, 1);
       World.setBlock(coords.x,coords.y+1,  coords.z-2, 98, 1);
       World.setBlock(coords.x+1,coords.y+1,  coords.z-2, 98, 1);
       //
       //cột
       World.setBlock(coords.x+2,coords.y+1,  coords.z-2, 98, 1);
       World.setBlock(coords.x+2,coords.y+2,  coords.z-2, 98, 1);
       World.setBlock(coords.x+2,coords.y+3,  coords.z-2, 98, 1);
       World.setBlock(coords.x+2,coords.y+4,  coords.z-2, 98, 1);
       //
       World.setBlock(coords.x-2,coords.y+1,  coords.z-2, 98, 1);
       World.setBlock(coords.x-2,coords.y+2,  coords.z-2, 98, 1);
       World.setBlock(coords.x-2,coords.y+3,  coords.z-2, 98, 1);
       World.setBlock(coords.x-2,coords.y+4,  coords.z-2, 98, 1);
       //
       World.setBlock(coords.x-2,coords.y+1,  coords.z+2, 98, 1);
       World.setBlock(coords.x-2,coords.y+2,  coords.z+2, 98, 1);
       World.setBlock(coords.x-2,coords.y+3,  coords.z+2, 98, 1);
       World.setBlock(coords.x-2,coords.y+4,  coords.z+2, 98, 1);
       //
       World.setBlock(coords.x+2,coords.y+1,  coords.z+2, 98, 1);
       World.setBlock(coords.x+2,coords.y+2,  coords.z+2, 98, 1);
       World.setBlock(coords.x+2,coords.y+3,  coords.z+2, 98, 1);
       World.setBlock(coords.x+2,coords.y+4,  coords.z+2, 98, 1);
       //
       //
       World.setBlock(coords.x+4,coords.y+2,  coords.z+2, 98, 1);
       World.setBlock(coords.x+4,coords.y+1,  coords.z+2, 98, 1);
       World.setBlock(coords.x+4,coords.y-1,  coords.z+2, 98, 1);
       World.setBlock(coords.x+4,coords.y-2,  coords.z+2, 98, 1);
       //
       World.setBlock(coords.x-1,coords.y+4,  coords.z-2, 98, 1);
       World.setBlock(coords.x-2,coords.y+4,  coords.z-1, 98, 1);
       World.setBlock(coords.x-2,coords.y+4,  coords.z+1, 98, 1);
       World.setBlock(coords.x-1,coords.y+4,  coords.z+2, 98, 1);
       //
       World.setBlock(coords.x-1,coords.y+5,  coords.z, 98, 1);
       World.setBlock(coords.x,coords.y+5,  coords.z-1, 98, 1);
       World.setBlock(coords.x+1,coords.y+5,  coords.z, 98, 1);
       World.setBlock(coords.x,coords.y+5,  coords.z+1, 98, 1);
       

} 
} 
}
});




// file: Hexxit Core/Dimensions/THE TWILIGHT FOREST/Dimensions Structure/Structure Boss/Naga Structure.js

Callback.addCallback("GenerateCustomDimensionChunk", function(chunkX, chunkZ, random, dimensionId){
    if(dimensionId==twilightforest1.id){
let coords = GenerationUtils.randomCoords(chunkX, chunkZ, 64, 128);
    if(Math.random() < 0.005){
    coords = GenerationUtils.findSurface(coords.x, coords.y, coords.z);

if(World.getBlock(coords.x,coords.y+1,coords.z).id === 0 && GenerationUtils.canSeeSky(coords.x, coords.y + 1, coords.z)) { 
 World.setBlock(coords.x-1,coords.y+1,  coords.z+2, 98, 1);
       World.setBlock(coords.x,coords.y+1,  coords.z+2, 98, 1);
       World.setBlock(coords.x+1,coords.y+1,  coords.z+2, 98, 1);
       World.setBlock(coords.x+2,coords.y+1,  coords.z+1, 98, 1);
       World.setBlock(coords.x+1,coords.y+1,  coords.z+1, 98, 1);
       World.setBlock(coords.x,coords.y+1,  coords.z+1, 98, 1);
       World.setBlock(coords.x-1,coords.y+1,  coords.z+1, 98, 1);
       World.setBlock(coords.x-2,coords.y+1,  coords.z+1, 98, 1);
       //
       //
       World.setBlock(coords.x+2,coords.y+1,  coords.z, 98, 1);
       World.setBlock(coords.x+1,coords.y+1,  coords.z, 98, 1);
       World.setBlock(coords.x,coords.y+1,  coords.z, 98, 1); 
       World.setBlock(coords.x,coords.y+2,  coords.z, BlockID.na1, 0);// boss
       
       World.setBlock(coords.x-1,coords.y+1,  coords.z, 98, 1);
       World.setBlock(coords.x-2,coords.y+1,  coords.z, 98, 1);
       //
       World.setBlock(coords.x+2,coords.y+1,  coords.z-1, 98, 1);
       World.setBlock(coords.x+1,coords.y+1,  coords.z-1, 98, 1);
       World.setBlock(coords.x,coords.y+1,  coords.z-1, 98, 1);
       World.setBlock(coords.x-1,coords.y+1,  coords.z-1, 98, 1);
       World.setBlock(coords.x-2,coords.y+1,  coords.z-1, 98, 1);
       //
       World.setBlock(coords.x-1,coords.y+1,  coords.z-2, 98, 1);
       World.setBlock(coords.x,coords.y+1,  coords.z-2, 98, 1);
       World.setBlock(coords.x+1,coords.y+1,  coords.z-2, 98, 1);
       //
       //cột
       World.setBlock(coords.x+2,coords.y+1,  coords.z-2, 98, 1);
       World.setBlock(coords.x+2,coords.y+2,  coords.z-2, 98, 1);
       World.setBlock(coords.x+2,coords.y+3,  coords.z-2, 98, 1);
       World.setBlock(coords.x+2,coords.y+4,  coords.z-2, 98, 1);
       //
       World.setBlock(coords.x-2,coords.y+1,  coords.z-2, 98, 1);
       World.setBlock(coords.x-2,coords.y+2,  coords.z-2, 98, 1);
       World.setBlock(coords.x-2,coords.y+3,  coords.z-2, 98, 1);
       World.setBlock(coords.x-2,coords.y+4,  coords.z-2, 98, 1);
       //
       World.setBlock(coords.x-2,coords.y+1,  coords.z+2, 98, 1);
       World.setBlock(coords.x-2,coords.y+2,  coords.z+2, 98, 1);
       World.setBlock(coords.x-2,coords.y+3,  coords.z+2, 98, 1);
       World.setBlock(coords.x-2,coords.y+4,  coords.z+2, 98, 1);
       //
       World.setBlock(coords.x+2,coords.y+1,  coords.z+2, 98, 1);
       World.setBlock(coords.x+2,coords.y+2,  coords.z+2, 98, 1);
       World.setBlock(coords.x+2,coords.y+3,  coords.z+2, 98, 1);
       World.setBlock(coords.x+2,coords.y+4,  coords.z+2, 98, 1);
       //
       //
       World.setBlock(coords.x+4,coords.y+2,  coords.z+2, 98, 1);
       World.setBlock(coords.x+4,coords.y+1,  coords.z+2, 98, 1);
       World.setBlock(coords.x+4,coords.y-1,  coords.z+2, 98, 1);
       World.setBlock(coords.x+4,coords.y-2,  coords.z+2, 98, 1);
       //
       World.setBlock(coords.x-1,coords.y+4,  coords.z-2, 98, 1);
       World.setBlock(coords.x-2,coords.y+4,  coords.z-1, 98, 1);
       World.setBlock(coords.x-2,coords.y+4,  coords.z+1, 98, 1);
       World.setBlock(coords.x-1,coords.y+4,  coords.z+2, 98, 1);
       //
       World.setBlock(coords.x-1,coords.y+5,  coords.z, 98, 1);
       World.setBlock(coords.x,coords.y+5,  coords.z-1, 98, 1);
       World.setBlock(coords.x+1,coords.y+5,  coords.z, 98, 1);
       World.setBlock(coords.x,coords.y+5,  coords.z+1, 98, 1);
       

} 
} 
}
});




// file: Hexxit Core/Dimensions/THE TWILIGHT FOREST/Dimensions Structure/Structure Boss/Hydra Structure.js

Callback.addCallback("GenerateCustomDimensionChunk", function(chunkX, chunkZ, random, dimensionId){
    if(dimensionId==twilightforest1.id){
let coords = GenerationUtils.randomCoords(chunkX, chunkZ, 64, 128);
    if(Math.random() < 0.005){
    coords = GenerationUtils.findSurface(coords.x, coords.y, coords.z);

if(World.getBlock(coords.x,coords.y+1,coords.z).id === 0 && GenerationUtils.canSeeSky(coords.x, coords.y + 1, coords.z)) { 
 World.setBlock(coords.x-1,coords.y+1,  coords.z+2, 98, 1);
       World.setBlock(coords.x,coords.y+1,  coords.z+2, 98, 1);
       World.setBlock(coords.x+1,coords.y+1,  coords.z+2, 98, 1);
       World.setBlock(coords.x+2,coords.y+1,  coords.z+1, 98, 1);
       World.setBlock(coords.x+1,coords.y+1,  coords.z+1, 98, 1);
       World.setBlock(coords.x,coords.y+1,  coords.z+1, 98, 1);
       World.setBlock(coords.x-1,coords.y+1,  coords.z+1, 98, 1);
       World.setBlock(coords.x-2,coords.y+1,  coords.z+1, 98, 1);
       //
       //
       World.setBlock(coords.x+2,coords.y+1,  coords.z, 98, 1);
       World.setBlock(coords.x+1,coords.y+1,  coords.z, 98, 1);
       World.setBlock(coords.x,coords.y+1,  coords.z, 98, 1); 
       World.setBlock(coords.x,coords.y+2,  coords.z, BlockID.hydraOn, 0);// boss
       
       World.setBlock(coords.x-1,coords.y+1,  coords.z, 98, 1);
       World.setBlock(coords.x-2,coords.y+1,  coords.z, 98, 1);
       //
       World.setBlock(coords.x+2,coords.y+1,  coords.z-1, 98, 1);
       World.setBlock(coords.x+1,coords.y+1,  coords.z-1, 98, 1);
       World.setBlock(coords.x,coords.y+1,  coords.z-1, 98, 1);
       World.setBlock(coords.x-1,coords.y+1,  coords.z-1, 98, 1);
       World.setBlock(coords.x-2,coords.y+1,  coords.z-1, 98, 1);
       //
       World.setBlock(coords.x-1,coords.y+1,  coords.z-2, 98, 1);
       World.setBlock(coords.x,coords.y+1,  coords.z-2, 98, 1);
       World.setBlock(coords.x+1,coords.y+1,  coords.z-2, 98, 1);
       //
       //cột
       World.setBlock(coords.x+2,coords.y+1,  coords.z-2, 98, 1);
       World.setBlock(coords.x+2,coords.y+2,  coords.z-2, 98, 1);
       World.setBlock(coords.x+2,coords.y+3,  coords.z-2, 98, 1);
       World.setBlock(coords.x+2,coords.y+4,  coords.z-2, 98, 1);
       //
       World.setBlock(coords.x-2,coords.y+1,  coords.z-2, 98, 1);
       World.setBlock(coords.x-2,coords.y+2,  coords.z-2, 98, 1);
       World.setBlock(coords.x-2,coords.y+3,  coords.z-2, 98, 1);
       World.setBlock(coords.x-2,coords.y+4,  coords.z-2, 98, 1);
       //
       World.setBlock(coords.x-2,coords.y+1,  coords.z+2, 98, 1);
       World.setBlock(coords.x-2,coords.y+2,  coords.z+2, 98, 1);
       World.setBlock(coords.x-2,coords.y+3,  coords.z+2, 98, 1);
       World.setBlock(coords.x-2,coords.y+4,  coords.z+2, 98, 1);
       //
       World.setBlock(coords.x+2,coords.y+1,  coords.z+2, 98, 1);
       World.setBlock(coords.x+2,coords.y+2,  coords.z+2, 98, 1);
       World.setBlock(coords.x+2,coords.y+3,  coords.z+2, 98, 1);
       World.setBlock(coords.x+2,coords.y+4,  coords.z+2, 98, 1);
       //
       //
       World.setBlock(coords.x+4,coords.y+2,  coords.z+2, 98, 1);
       World.setBlock(coords.x+4,coords.y+1,  coords.z+2, 98, 1);
       World.setBlock(coords.x+4,coords.y-1,  coords.z+2, 98, 1);
       World.setBlock(coords.x+4,coords.y-2,  coords.z+2, 98, 1);
       //
       World.setBlock(coords.x-1,coords.y+4,  coords.z-2, 98, 1);
       World.setBlock(coords.x-2,coords.y+4,  coords.z-1, 98, 1);
       World.setBlock(coords.x-2,coords.y+4,  coords.z+1, 98, 1);
       World.setBlock(coords.x-1,coords.y+4,  coords.z+2, 98, 1);
       //
       World.setBlock(coords.x-1,coords.y+5,  coords.z, 98, 1);
       World.setBlock(coords.x,coords.y+5,  coords.z-1, 98, 1);
       World.setBlock(coords.x+1,coords.y+5,  coords.z, 98, 1);
       World.setBlock(coords.x,coords.y+5,  coords.z+1, 98, 1);
       

} 
} 
}
});




// file: Hexxit Core/Dimensions/THE TWILIGHT FOREST/Dimensions Structure/Structure Boss/Snow Queen Structure.js

Callback.addCallback("GenerateCustomDimensionChunk", function(chunkX, chunkZ, random, dimensionId){
    if(dimensionId==twilightforest1.id){
let coords = GenerationUtils.randomCoords(chunkX, chunkZ, 64, 128);
    if(Math.random() < 0.005){
    coords = GenerationUtils.findSurface(coords.x, coords.y, coords.z);

if(World.getBlock(coords.x,coords.y+1,coords.z).id === 0 && GenerationUtils.canSeeSky(coords.x, coords.y + 1, coords.z)) { 
 World.setBlock(coords.x-1,coords.y+1,  coords.z+2, 98, 1);
       World.setBlock(coords.x,coords.y+1,  coords.z+2, 98, 1);
       World.setBlock(coords.x+1,coords.y+1,  coords.z+2, 98, 1);
       World.setBlock(coords.x+2,coords.y+1,  coords.z+1, 98, 1);
       World.setBlock(coords.x+1,coords.y+1,  coords.z+1, 98, 1);
       World.setBlock(coords.x,coords.y+1,  coords.z+1, 98, 1);
       World.setBlock(coords.x-1,coords.y+1,  coords.z+1, 98, 1);
       World.setBlock(coords.x-2,coords.y+1,  coords.z+1, 98, 1);
       //
       //
       World.setBlock(coords.x+2,coords.y+1,  coords.z, 98, 1);
       World.setBlock(coords.x+1,coords.y+1,  coords.z, 98, 1);
       World.setBlock(coords.x,coords.y+1,  coords.z, 98, 1); 
       World.setBlock(coords.x,coords.y+2,  coords.z, BlockID.snowQueenOn, 0);// boss
       
       World.setBlock(coords.x-1,coords.y+1,  coords.z, 98, 1);
       World.setBlock(coords.x-2,coords.y+1,  coords.z, 98, 1);
       //
       World.setBlock(coords.x+2,coords.y+1,  coords.z-1, 98, 1);
       World.setBlock(coords.x+1,coords.y+1,  coords.z-1, 98, 1);
       World.setBlock(coords.x,coords.y+1,  coords.z-1, 98, 1);
       World.setBlock(coords.x-1,coords.y+1,  coords.z-1, 98, 1);
       World.setBlock(coords.x-2,coords.y+1,  coords.z-1, 98, 1);
       //
       World.setBlock(coords.x-1,coords.y+1,  coords.z-2, 98, 1);
       World.setBlock(coords.x,coords.y+1,  coords.z-2, 98, 1);
       World.setBlock(coords.x+1,coords.y+1,  coords.z-2, 98, 1);
       //
       //cột
       World.setBlock(coords.x+2,coords.y+1,  coords.z-2, 98, 1);
       World.setBlock(coords.x+2,coords.y+2,  coords.z-2, 98, 1);
       World.setBlock(coords.x+2,coords.y+3,  coords.z-2, 98, 1);
       World.setBlock(coords.x+2,coords.y+4,  coords.z-2, 98, 1);
       //
       World.setBlock(coords.x-2,coords.y+1,  coords.z-2, 98, 1);
       World.setBlock(coords.x-2,coords.y+2,  coords.z-2, 98, 1);
       World.setBlock(coords.x-2,coords.y+3,  coords.z-2, 98, 1);
       World.setBlock(coords.x-2,coords.y+4,  coords.z-2, 98, 1);
       //
       World.setBlock(coords.x-2,coords.y+1,  coords.z+2, 98, 1);
       World.setBlock(coords.x-2,coords.y+2,  coords.z+2, 98, 1);
       World.setBlock(coords.x-2,coords.y+3,  coords.z+2, 98, 1);
       World.setBlock(coords.x-2,coords.y+4,  coords.z+2, 98, 1);
       //
       World.setBlock(coords.x+2,coords.y+1,  coords.z+2, 98, 1);
       World.setBlock(coords.x+2,coords.y+2,  coords.z+2, 98, 1);
       World.setBlock(coords.x+2,coords.y+3,  coords.z+2, 98, 1);
       World.setBlock(coords.x+2,coords.y+4,  coords.z+2, 98, 1);
       //
       //
       World.setBlock(coords.x+4,coords.y+2,  coords.z+2, 98, 1);
       World.setBlock(coords.x+4,coords.y+1,  coords.z+2, 98, 1);
       World.setBlock(coords.x+4,coords.y-1,  coords.z+2, 98, 1);
       World.setBlock(coords.x+4,coords.y-2,  coords.z+2, 98, 1);
       //
       World.setBlock(coords.x-1,coords.y+4,  coords.z-2, 98, 1);
       World.setBlock(coords.x-2,coords.y+4,  coords.z-1, 98, 1);
       World.setBlock(coords.x-2,coords.y+4,  coords.z+1, 98, 1);
       World.setBlock(coords.x-1,coords.y+4,  coords.z+2, 98, 1);
       //
       World.setBlock(coords.x-1,coords.y+5,  coords.z, 98, 1);
       World.setBlock(coords.x,coords.y+5,  coords.z-1, 98, 1);
       World.setBlock(coords.x+1,coords.y+5,  coords.z, 98, 1);
       World.setBlock(coords.x,coords.y+5,  coords.z+1, 98, 1);
       

} 
} 
}
});




// file: Hexxit Core/Dimensions/THE TWILIGHT FOREST/Mob/hydra.js

Callback.addCallback("ItemUse", function(coords, item, block) {
  if (item.id==ItemID.keyHydra && block.id== BlockID.hydraOn) {
  World.setBlock(coords.x, coords.y, coords.z, 0, 0) 
Entity.spawnAddon (coords.x, coords.y+1, coords.z+5, "ms:jts");
Entity.spawn(coords.x, coords.y+9, coords.z+5, 34); 
Entity.spawn(coords.x, coords.y+9, coords.z+5, 34); 
Entity.spawn(coords.x, coords.y+9, coords.z+4, 34); 
Entity.spawn(coords.x, coords.y+9, coords.z+5, 34); 



World.setBlock(coords.x-13,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x-13,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x-13,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x-13,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x-13,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x-13,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x-13,coords.y-3,  coords.z-13, 98, 1);
       //
       World.setBlock(coords.x-13,coords.y+3,  coords.z-12, 98, 1);
       World.setBlock(coords.x-13,coords.y+2,  coords.z-12, 98, 1);
       World.setBlock(coords.x-13,coords.y+1,  coords.z-12, 98, 1);
       World.setBlock(coords.x-13,coords.y,  coords.z-12, 98, 1);
       World.setBlock(coords.x-13,coords.y-1,  coords.z-12, 98, 1);
       World.setBlock(coords.x-13,coords.y-2,  coords.z-12, 98, 1);
       World.setBlock(coords.x-13,coords.y-3,  coords.z-12, 98, 1);
       //
       World.setBlock(coords.x-13,coords.y+3,  coords.z-11, 98, 1);
       World.setBlock(coords.x-13,coords.y+2,  coords.z-11, 98, 1);
       World.setBlock(coords.x-13,coords.y+1,  coords.z-11, 98, 1);
       World.setBlock(coords.x-13,coords.y,  coords.z-11, 98, 1);
       World.setBlock(coords.x-13,coords.y-1,  coords.z-11, 98, 1);
       World.setBlock(coords.x-13,coords.y-2,  coords.z-11, 98, 1);
       World.setBlock(coords.x-13,coords.y-3,  coords.z-11, 98, 1);
//
World.setBlock(coords.x-13,coords.y+3,  coords.z-10, 98, 1);
       World.setBlock(coords.x-13,coords.y+2,  coords.z-10, 98, 1);
       World.setBlock(coords.x-13,coords.y+1,  coords.z-10, 98, 1);
       World.setBlock(coords.x-13,coords.y,  coords.z-10, 98, 1);
       World.setBlock(coords.x-13,coords.y-1,  coords.z-10, 98, 1);
       World.setBlock(coords.x-13,coords.y-2,  coords.z-10, 98, 1);
       World.setBlock(coords.x-13,coords.y-3,  coords.z-10, 98, 1);
//
World.setBlock(coords.x-13,coords.y+3,  coords.z-9, 98, 1);
       World.setBlock(coords.x-13,coords.y+2,  coords.z-9, 98, 1);
       World.setBlock(coords.x-13,coords.y+1,  coords.z-9, 98, 1);
       World.setBlock(coords.x-13,coords.y,  coords.z-9, 98, 1);
       World.setBlock(coords.x-13,coords.y-1,  coords.z-9, 98, 1);
       World.setBlock(coords.x-13,coords.y-2,  coords.z-9, 98, 1);
       World.setBlock(coords.x-13,coords.y-3,  coords.z-9, 98, 1);
//
World.setBlock(coords.x-13,coords.y+3,  coords.z-8, 98, 1);
       World.setBlock(coords.x-13,coords.y+2,  coords.z-8, 98, 1);
       World.setBlock(coords.x-13,coords.y+1,  coords.z-8, 98, 1);
       World.setBlock(coords.x-13,coords.y,  coords.z-8, 98, 1);
       World.setBlock(coords.x-13,coords.y-1,  coords.z-8, 98, 1);
       World.setBlock(coords.x-13,coords.y-2,  coords.z-8, 98, 1);
       World.setBlock(coords.x-13,coords.y-3,  coords.z-8, 98, 1);
       //
       World.setBlock(coords.x-13,coords.y+3,  coords.z-7, 98, 1);
       World.setBlock(coords.x-13,coords.y+2,  coords.z-7, 98, 1);
       World.setBlock(coords.x-13,coords.y+1,  coords.z-7, 98, 1);
       World.setBlock(coords.x-13,coords.y,  coords.z-7, 98, 1);
       World.setBlock(coords.x-13,coords.y-1,  coords.z-7, 98, 1);
       World.setBlock(coords.x-13,coords.y-2,  coords.z-7, 98, 1);
       World.setBlock(coords.x-13,coords.y-3,  coords.z-7, 98, 1);
       //
       World.setBlock(coords.x-13,coords.y+3,  coords.z-6, 98, 1);
       World.setBlock(coords.x-13,coords.y+2,  coords.z-6, 98, 1);
       World.setBlock(coords.x-13,coords.y+1,  coords.z-6, 98, 1);
       World.setBlock(coords.x-13,coords.y,  coords.z-6, 98, 1);
       World.setBlock(coords.x-13,coords.y-1,  coords.z-6, 98, 1);
       World.setBlock(coords.x-13,coords.y-2,  coords.z-6, 98, 1);
       World.setBlock(coords.x-13,coords.y-3,  coords.z-6, 98, 1);
       //
       World.setBlock(coords.x-13,coords.y+3,  coords.z-5, 98, 1);
       World.setBlock(coords.x-13,coords.y+2,  coords.z-5, 98, 1);
       World.setBlock(coords.x-13,coords.y+1,  coords.z-5, 98, 1);
       World.setBlock(coords.x-13,coords.y,  coords.z-5, 98, 1);
       World.setBlock(coords.x-13,coords.y-1,  coords.z-5, 98, 1);
       World.setBlock(coords.x-13,coords.y-2,  coords.z-5, 98, 1);
       World.setBlock(coords.x-13,coords.y-3,  coords.z-5, 98, 1);
       //
       World.setBlock(coords.x-13,coords.y+3,  coords.z-4, 98, 1);
       World.setBlock(coords.x-13,coords.y+2,  coords.z-4, 98, 1);
       World.setBlock(coords.x-13,coords.y+1,  coords.z-4, 98, 1);
       World.setBlock(coords.x-13,coords.y,  coords.z-4, 98, 1);
       World.setBlock(coords.x-13,coords.y-1,  coords.z-4, 98, 1);
       World.setBlock(coords.x-13,coords.y-2,  coords.z-4, 98, 1);
       World.setBlock(coords.x-13,coords.y-3,  coords.z-4, 98, 1);
       //
       World.setBlock(coords.x-13,coords.y+3,  coords.z-3, 98, 1);
       World.setBlock(coords.x-13,coords.y+2,  coords.z-3, 98, 1);
       World.setBlock(coords.x-13,coords.y+1,  coords.z-3, 98, 1);
       World.setBlock(coords.x-13,coords.y,  coords.z-3, 98, 1);
       World.setBlock(coords.x-13,coords.y-1,  coords.z-3, 98, 1);
       World.setBlock(coords.x-13,coords.y-2,  coords.z-3, 98, 1);
       World.setBlock(coords.x-13,coords.y-3,  coords.z-3, 98, 1);
       //
       World.setBlock(coords.x-13,coords.y+3,  coords.z-2, 98, 1);
       World.setBlock(coords.x-13,coords.y+2,  coords.z-2, 98, 1);
       World.setBlock(coords.x-13,coords.y+1,  coords.z-2, 98, 1);
       World.setBlock(coords.x-13,coords.y,  coords.z-2, 98, 1);
       World.setBlock(coords.x-13,coords.y-1,  coords.z-2, 98, 1);
       World.setBlock(coords.x-13,coords.y-2,  coords.z-2, 98, 1);
       World.setBlock(coords.x-13,coords.y-3,  coords.z-2, 98, 1);
       //
       World.setBlock(coords.x-13,coords.y+3,  coords.z-1, 98, 1);
       World.setBlock(coords.x-13,coords.y+2,  coords.z-1, 98, 1);
       World.setBlock(coords.x-13,coords.y+1,  coords.z-1, 98, 1);
       World.setBlock(coords.x-13,coords.y,  coords.z-1, 98, 1);
       World.setBlock(coords.x-13,coords.y-1,  coords.z-1, 98, 1);
       World.setBlock(coords.x-13,coords.y-2,  coords.z-1, 98, 1);
       World.setBlock(coords.x-13,coords.y-3,  coords.z-1, 98, 1);
       
       World.setBlock(coords.x-13,coords.y+3,  coords.z, 98, 1);
       World.setBlock(coords.x-13,coords.y+2,  coords.z, 98, 1);
       World.setBlock(coords.x-13,coords.y+1,  coords.z, 98, 1);
       World.setBlock(coords.x-13,coords.y,  coords.z, 98, 1);
       World.setBlock(coords.x-13,coords.y-1,  coords.z, 98, 1);
       World.setBlock(coords.x-13,coords.y-2,  coords.z, 98, 1);
       World.setBlock(coords.x-13,coords.y-3,  coords.z, 98, 1);
       //
       World.setBlock(coords.x-13,coords.y+3,  coords.z+1, 98, 1);
       World.setBlock(coords.x-13,coords.y+2,  coords.z+1, 98, 1);
       World.setBlock(coords.x-13,coords.y+1,  coords.z+1, 98, 1);
       World.setBlock(coords.x-13,coords.y,  coords.z+1, 98, 1);
       World.setBlock(coords.x-13,coords.y-1,  coords.z+1, 98, 1);
       World.setBlock(coords.x-13,coords.y-2,  coords.z+1, 98, 1);
       World.setBlock(coords.x-13,coords.y-3,  coords.z+1, 98, 1);
       World.setBlock(coords.x-13,coords.y+3,  coords.z+2, 98, 1);
       World.setBlock(coords.x-13,coords.y+2,  coords.z+2, 98, 1);
       World.setBlock(coords.x-13,coords.y+1,  coords.z+2, 98, 1);
       World.setBlock(coords.x-13,coords.y,  coords.z+2, 98, 1);
       World.setBlock(coords.x-13,coords.y-1,  coords.z+2, 98, 1);
       World.setBlock(coords.x-13,coords.y-2,  coords.z+2, 98, 1);
       World.setBlock(coords.x-13,coords.y-3,  coords.z+2, 98, 1);
       World.setBlock(coords.x-13,coords.y+3,  coords.z+3, 98, 1);
       World.setBlock(coords.x-13,coords.y+2,  coords.z+3, 98, 1);
       World.setBlock(coords.x-13,coords.y+1,  coords.z+3, 98, 1);
       World.setBlock(coords.x-13,coords.y,  coords.z+3, 98, 1);
       World.setBlock(coords.x-13,coords.y-1,  coords.z+3, 98, 1);
       World.setBlock(coords.x-13,coords.y-2,  coords.z+3, 98, 1);
       World.setBlock(coords.x-13,coords.y-3,  coords.z+3, 98, 1);
       World.setBlock(coords.x-13,coords.y+3,  coords.z+4, 98, 1);
       World.setBlock(coords.x-13,coords.y+2,  coords.z+4, 98, 1);
       World.setBlock(coords.x-13,coords.y+1,  coords.z+4, 98, 1);
       World.setBlock(coords.x-13,coords.y,  coords.z+4, 98, 1);
       World.setBlock(coords.x-13,coords.y-1,  coords.z+4, 98, 1);
       World.setBlock(coords.x-13,coords.y-2,  coords.z+4, 98, 1);
       World.setBlock(coords.x-13,coords.y-3,  coords.z+4, 98, 1);
       World.setBlock(coords.x-13,coords.y+3,  coords.z+5, 98, 1);
       World.setBlock(coords.x-13,coords.y+2,  coords.z+5, 98, 1);
       World.setBlock(coords.x-13,coords.y+1,  coords.z+5, 98, 1);
       World.setBlock(coords.x-13,coords.y,  coords.z+5, 98, 1);
       World.setBlock(coords.x-13,coords.y-1,  coords.z+5, 98, 1);
       World.setBlock(coords.x-13,coords.y-2,  coords.z+5, 98, 1);
       World.setBlock(coords.x-13,coords.y-3,  coords.z+5, 98, 1);
       World.setBlock(coords.x-13,coords.y+3,  coords.z+6, 98, 1);
       World.setBlock(coords.x-13,coords.y+2,  coords.z+6, 98, 1);
       World.setBlock(coords.x-13,coords.y+1,  coords.z+6, 98, 1);
       World.setBlock(coords.x-13,coords.y,  coords.z+6, 98, 1);
       World.setBlock(coords.x-13,coords.y-1,  coords.z+6, 98, 1);
       World.setBlock(coords.x-13,coords.y-2,  coords.z+6, 98, 1);
       World.setBlock(coords.x-13,coords.y-3,  coords.z+6, 98, 1);
       World.setBlock(coords.x-13,coords.y+3,  coords.z+7, 98, 1);
       World.setBlock(coords.x-13,coords.y+2,  coords.z+7, 98, 1);
       World.setBlock(coords.x-13,coords.y+1,  coords.z+7, 98, 1);
       World.setBlock(coords.x-13,coords.y,  coords.z+7, 98, 1);
       World.setBlock(coords.x-13,coords.y-1,  coords.z+7, 98, 1);
       World.setBlock(coords.x-13,coords.y-2,  coords.z+7, 98, 1);
       World.setBlock(coords.x-13,coords.y-3,  coords.z+7, 98, 1);
       World.setBlock(coords.x-13,coords.y+3,  coords.z+8, 98, 1);
       World.setBlock(coords.x-13,coords.y+2,  coords.z+8, 98, 1);
       World.setBlock(coords.x-13,coords.y+1,  coords.z+8, 98, 1);
       World.setBlock(coords.x-13,coords.y,  coords.z+8, 98, 1);
       World.setBlock(coords.x-13,coords.y-1,  coords.z+8, 98, 1);
       World.setBlock(coords.x-13,coords.y-2,  coords.z+8, 98, 1);
       World.setBlock(coords.x-13,coords.y-3,  coords.z+8, 98, 1);
       World.setBlock(coords.x-13,coords.y+3,  coords.z+9, 98, 1);
       World.setBlock(coords.x-13,coords.y+2,  coords.z+9, 98, 1);
       World.setBlock(coords.x-13,coords.y+1,  coords.z+9, 98, 1);
       World.setBlock(coords.x-13,coords.y,  coords.z+9, 98, 1);
       World.setBlock(coords.x-13,coords.y-1,  coords.z+9, 98, 1);
       World.setBlock(coords.x-13,coords.y-2,  coords.z+9, 98, 1);
       World.setBlock(coords.x-13,coords.y-3,  coords.z+9, 98, 1);
       World.setBlock(coords.x-13,coords.y+3,  coords.z+10, 98, 1);
       World.setBlock(coords.x-13,coords.y+2,  coords.z+10, 98, 1);
       World.setBlock(coords.x-13,coords.y+1,  coords.z+10, 98, 1);
       World.setBlock(coords.x-13,coords.y,  coords.z+10, 98, 1);
       World.setBlock(coords.x-13,coords.y-1,  coords.z+10, 98, 1);
       World.setBlock(coords.x-13,coords.y-2,  coords.z+10, 98, 1);
       World.setBlock(coords.x-13,coords.y-3,  coords.z+10, 98, 1);
       World.setBlock(coords.x-13,coords.y+3,  coords.z+11, 98, 1);
       World.setBlock(coords.x-13,coords.y+2,  coords.z+11, 98, 1);
       World.setBlock(coords.x-13,coords.y+1,  coords.z+11, 98, 1);
       World.setBlock(coords.x-13,coords.y,  coords.z+11, 98, 1);
       World.setBlock(coords.x-13,coords.y-1,  coords.z+11, 98, 1);
       World.setBlock(coords.x-13,coords.y-2,  coords.z+11, 98, 1);
       World.setBlock(coords.x-13,coords.y-3,  coords.z+11, 98, 1);
       World.setBlock(coords.x-13,coords.y+3,  coords.z+12, 98, 1);
       World.setBlock(coords.x-13,coords.y+2,  coords.z+12, 98, 1);
       World.setBlock(coords.x-13,coords.y+1,  coords.z+12, 98, 1);
       World.setBlock(coords.x-13,coords.y,  coords.z+12, 98, 1);
       World.setBlock(coords.x-13,coords.y-1,  coords.z+12, 98, 1);
       World.setBlock(coords.x-13,coords.y-2,  coords.z+12, 98, 1);
       World.setBlock(coords.x-13,coords.y-3,  coords.z+12, 98, 1);
       World.setBlock(coords.x-13,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x-13,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x-13,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x-13,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x-13,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x-13,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x-13,coords.y-3,  coords.z+13, 98, 1);
       
      //2
      World.setBlock(coords.x-12,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x-12,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x-12,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x-12,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x-12,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x-12,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x-12,coords.y-3,  coords.z+13, 98, 1);
      World.setBlock(coords.x-11,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x-11,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x-11,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x-11,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x-11,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x-11,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x-11,coords.y-3,  coords.z+13, 98, 1);
      World.setBlock(coords.x-10,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x-10,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x-10,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x-10,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x-10,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x-10,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x-10,coords.y-3,  coords.z+13, 98, 1);
      World.setBlock(coords.x-9,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x-9,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x-9,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x-9,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x-9,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x-9,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x-9,coords.y-3,  coords.z+13, 98, 1);
      World.setBlock(coords.x-8,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x-8,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x-8,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x-8,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x-8,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x-8,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x-8,coords.y-3,  coords.z+13, 98, 1);
      World.setBlock(coords.x-7,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x-7,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x-7,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x-7,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x-7,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x-7,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x-7,coords.y-3,  coords.z+13, 98, 1);
      World.setBlock(coords.x-6,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x-6,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x-6,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x-6,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x-6,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x-6,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x-6,coords.y-3,  coords.z+13, 98, 1);
      World.setBlock(coords.x-5,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x-5,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x-5,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x-5,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x-5,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x-5,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x-5,coords.y-3,  coords.z+13, 98, 1);
      World.setBlock(coords.x-4,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x-4,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x-4,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x-4,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x-4,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x-4,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x-4,coords.y-3,  coords.z+13, 98, 1);
      World.setBlock(coords.x-3,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x-3,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x-3,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x-3,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x-3,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x-3,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x-3,coords.y-3,  coords.z+13, 98, 1);
      World.setBlock(coords.x-2,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x-2,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x-2,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x-2,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x-2,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x-2,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x-2,coords.y-3,  coords.z+13, 98, 1);
      World.setBlock(coords.x-1,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x-1,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x-1,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x-1,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x-1,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x-1,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x-1,coords.y-3,  coords.z+13, 98, 1);
      World.setBlock(coords.x,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x,coords.y-3,  coords.z+13, 98, 1);
      World.setBlock(coords.x+1,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x+1,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+1,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+1,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x+1,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+1,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+1,coords.y-3,  coords.z+13, 98, 1);
      World.setBlock(coords.x+2,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x+2,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+2,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+2,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x+2,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+2,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+2,coords.y-3,  coords.z+13, 98, 1);
      World.setBlock(coords.x+3,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x+3,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+3,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+3,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x+3,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+3,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+3,coords.y-3,  coords.z+13, 98, 1);
      World.setBlock(coords.x+4,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x+4,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+4,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+4,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x+4,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+4,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+4,coords.y-3,  coords.z+13, 98, 1);
      World.setBlock(coords.x+5,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x+5,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+5,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+5,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x+5,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+5,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+5,coords.y-3,  coords.z+13, 98, 1);
      World.setBlock(coords.x+6,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x+6,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+6,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+6,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x+6,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+6,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+6,coords.y-3,  coords.z+13, 98, 1);
      World.setBlock(coords.x+7,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x+7,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+7,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+7,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x+7,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+7,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+7,coords.y-3,  coords.z+13, 98, 1);
      World.setBlock(coords.x+8,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x+8,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+8,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+8,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x+8,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+8,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+8,coords.y-3,  coords.z+13, 98, 1);
      World.setBlock(coords.x+9,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x+9,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+9,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+9,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x+9,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+9,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+9,coords.y-3,  coords.z+13, 98, 1);
       World.setBlock(coords.x+10,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x+10,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+10,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+10,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x+10,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+10,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+10,coords.y-3,  coords.z+13, 98, 1);
       World.setBlock(coords.x+11,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x+11,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+11,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+11,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x+11,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+11,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+11,coords.y-3,  coords.z+13, 98, 1);
       World.setBlock(coords.x+12,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x+12,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+12,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+12,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x+12,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+12,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+12,coords.y-3,  coords.z+13, 98, 1);
       World.setBlock(coords.x+13,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z+13, 98, 1);
       //3
       World.setBlock(coords.x+13,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z-13, 98, 1);
       //
       World.setBlock(coords.x+13,coords.y+3,  coords.z-12, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z-12, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z-12, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z-12, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z-12, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z-12, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z-12, 98, 1);
       //
       World.setBlock(coords.x+13,coords.y+3,  coords.z-11, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z-11, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z-11, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z-11, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z-11, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z-11, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z-11, 98, 1);
//
World.setBlock(coords.x+13,coords.y+3,  coords.z-10, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z-10, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z-10, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z-10, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z-10, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z-10, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z-10, 98, 1);
//
World.setBlock(coords.x+13,coords.y+3,  coords.z-9, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z-9, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z-9, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z-9, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z-9, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z-9, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z-9, 98, 1);
//
World.setBlock(coords.x+13,coords.y+3,  coords.z-8, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z-8, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z-8, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z-8, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z-8, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z-8, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z-8, 98, 1);
       //
       World.setBlock(coords.x+13,coords.y+3,  coords.z-7, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z-7, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z-7, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z-7, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z-7, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z-7, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z-7, 98, 1);
       //
       World.setBlock(coords.x+13,coords.y+3,  coords.z-6, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z-6, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z-6, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z-6, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z-6, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z-6, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z-6, 98, 1);
       //
       World.setBlock(coords.x+13,coords.y+3,  coords.z-5, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z-5, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z-5, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z-5, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z-5, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z-5, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z-5, 98, 1);
       //
       World.setBlock(coords.x+13,coords.y+3,  coords.z-4, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z-4, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z-4, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z-4, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z-4, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z-4, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z-4, 98, 1);
       //
       World.setBlock(coords.x+13,coords.y+3,  coords.z-3, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z-3, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z-3, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z-3, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z-3, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z-3, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z-3, 98, 1);
       //
       World.setBlock(coords.x+13,coords.y+3,  coords.z-2, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z-2, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z-2, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z-2, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z-2, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z-2, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z-2, 98, 1);
       //
       World.setBlock(coords.x+13,coords.y+3,  coords.z-1, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z-1, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z-1, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z-1, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z-1, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z-1, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z-1, 98, 1);
       
       World.setBlock(coords.x+13,coords.y+3,  coords.z, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z, 98, 1);
       //
       World.setBlock(coords.x+13,coords.y+3,  coords.z+1, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z+1, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z+1, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z+1, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z+1, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z+1, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z+1, 98, 1);
       World.setBlock(coords.x+13,coords.y+3,  coords.z+2, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z+2, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z+2, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z+2, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z+2, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z+2, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z+2, 98, 1);
       World.setBlock(coords.x+13,coords.y+3,  coords.z+3, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z+3, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z+3, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z+3, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z+3, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z+3, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z+3, 98, 1);
       World.setBlock(coords.x+13,coords.y+3,  coords.z+4, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z+4, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z+4, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z+4, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z+4, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z+4, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z+4, 98, 1);
       World.setBlock(coords.x+13,coords.y+3,  coords.z+5, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z+5, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z+5, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z+5, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z+5, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z+5, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z+5, 98, 1);
       World.setBlock(coords.x+13,coords.y+3,  coords.z+6, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z+6, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z+6, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z+6, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z+6, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z+6, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z+6, 98, 1);
       World.setBlock(coords.x+13,coords.y+3,  coords.z+7, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z+7, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z+7, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z+7, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z+7, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z+7, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z+7, 98, 1);
       World.setBlock(coords.x+13,coords.y+3,  coords.z+8, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z+8, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z+8, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z+8, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z+8, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z+8, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z+8, 98, 1);
       World.setBlock(coords.x+13,coords.y+3,  coords.z+9, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z+9, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z+9, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z+9, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z+9, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z+9, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z+9, 98, 1);
       World.setBlock(coords.x+13,coords.y+3,  coords.z+10, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z+10, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z+10, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z+10, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z+10, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z+10, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z+10, 98, 1);
       World.setBlock(coords.x+13,coords.y+3,  coords.z+11, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z+11, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z+11, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z+11, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z+11, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z+11, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z+11, 98, 1);
       World.setBlock(coords.x+13,coords.y+3,  coords.z+12, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z+12, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z+12, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z+12, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z+12, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z+12, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z+12, 98, 1);
       World.setBlock(coords.x+13,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z+13, 98, 1);
//
World.setBlock(coords.x-12,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x-12,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x-12,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x-12,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x-12,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x-12,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x-12,coords.y-3,  coords.z-13, 98, 1);
      World.setBlock(coords.x-11,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x-11,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x-11,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x-11,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x-11,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x-11,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x-11,coords.y-3,  coords.z-13, 98, 1);
      World.setBlock(coords.x-10,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x-10,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x-10,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x-10,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x-10,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x-10,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x-10,coords.y-3,  coords.z-13, 98, 1);
      World.setBlock(coords.x-9,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x-9,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x-9,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x-9,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x-9,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x-9,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x-9,coords.y-3,  coords.z-13, 98, 1);
      World.setBlock(coords.x-8,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x-8,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x-8,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x-8,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x-8,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x-8,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x-8,coords.y-3,  coords.z-13, 98, 1);
      World.setBlock(coords.x-7,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x-7,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x-7,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x-7,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x-7,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x-7,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x-7,coords.y-3,  coords.z-13, 98, 1);
      World.setBlock(coords.x-6,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x-6,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x-6,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x-6,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x-6,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x-6,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x-6,coords.y-3,  coords.z-13, 98, 1);
      World.setBlock(coords.x-5,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x-5,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x-5,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x-5,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x-5,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x-5,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x-5,coords.y-3,  coords.z-13, 98, 1);
      World.setBlock(coords.x-4,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x-4,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x-4,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x-4,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x-4,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x-4,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x-4,coords.y-3,  coords.z-13, 98, 1);
      World.setBlock(coords.x-3,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x-3,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x-3,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x-3,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x-3,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x-3,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x-3,coords.y-3,  coords.z-13, 98, 1);
      World.setBlock(coords.x-2,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x-2,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x-2,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x-2,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x-2,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x-2,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x-2,coords.y-3,  coords.z-13, 98, 1);
      World.setBlock(coords.x-1,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x-1,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x-1,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x-1,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x-1,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x-1,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x-1,coords.y-3,  coords.z-13, 98, 1);
      World.setBlock(coords.x,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x,coords.y-3,  coords.z-13, 98, 1);
      World.setBlock(coords.x+1,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x+1,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+1,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+1,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x+1,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+1,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+1,coords.y-3,  coords.z-13, 98, 1);
      World.setBlock(coords.x+2,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x+2,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+2,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+2,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x+2,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+2,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+2,coords.y-3,  coords.z-13, 98, 1);
      World.setBlock(coords.x+3,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x+3,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+3,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+3,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x+3,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+3,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+3,coords.y-3,  coords.z-13, 98, 1);
      World.setBlock(coords.x+4,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x+4,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+4,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+4,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x+4,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+4,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+4,coords.y-3,  coords.z-13, 98, 1);
      World.setBlock(coords.x+5,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x+5,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+5,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+5,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x+5,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+5,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+5,coords.y-3,  coords.z-13, 98, 1);
      World.setBlock(coords.x+6,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x+6,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+6,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+6,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x+6,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+6,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+6,coords.y-3,  coords.z-13, 98, 1);
      World.setBlock(coords.x+7,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x+7,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+7,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+7,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x+7,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+7,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+7,coords.y-3,  coords.z-13, 98, 1);
      World.setBlock(coords.x+8,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x+8,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+8,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+8,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x+8,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+8,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+8,coords.y-3,  coords.z-13, 98, 1);
      World.setBlock(coords.x+9,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x+9,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+9,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+9,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x+9,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+9,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+9,coords.y-3,  coords.z-13, 98, 1);
       World.setBlock(coords.x+10,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x+10,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+10,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+10,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x+10,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+10,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+10,coords.y-3,  coords.z-13, 98, 1);
       World.setBlock(coords.x+11,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x+11,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+11,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+11,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x+11,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+11,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+11,coords.y-3,  coords.z-13, 98, 1);
       World.setBlock(coords.x+12,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x+12,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+12,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+12,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x+12,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+12,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+12,coords.y-3,  coords.z-13, 98, 1);
       World.setBlock(coords.x+13,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z-13, 98, 1);
       
  Player.decreaseCarriedItem(1)
  Particles.addParticle(Native.ParticleType.hugeexplosion, coords.x + 0.5, coords.y + 0.5, coords.z + 0.5, 0, 0.1, 0, 0);
  World.playSound(coords.x, coords.y, coords.z, "random.explode", 3)
  World.destroyBlock(coords.x, coords.y, coords.z, 1)
  
}
});













// file: Hexxit Core/Dimensions/THE TWILIGHT FOREST/Mob/naga.js

Callback.addCallback("ItemUse", function(coords, item, block) {
  if (item.id==ItemID.keyNaga && block.id== BlockID.na1) {
  World.setBlock(coords.x, coords.y, coords.z, 0, 0) 
Entity.spawnAddon (coords.x, coords.y+1, coords.z+5, "ms:nj");
World.setBlock(coords.x-13,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x-13,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x-13,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x-13,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x-13,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x-13,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x-13,coords.y-3,  coords.z-13, 98, 1);
       //
       World.setBlock(coords.x-13,coords.y+3,  coords.z-12, 98, 1);
       World.setBlock(coords.x-13,coords.y+2,  coords.z-12, 98, 1);
       World.setBlock(coords.x-13,coords.y+1,  coords.z-12, 98, 1);
       World.setBlock(coords.x-13,coords.y,  coords.z-12, 98, 1);
       World.setBlock(coords.x-13,coords.y-1,  coords.z-12, 98, 1);
       World.setBlock(coords.x-13,coords.y-2,  coords.z-12, 98, 1);
       World.setBlock(coords.x-13,coords.y-3,  coords.z-12, 98, 1);
       //
       World.setBlock(coords.x-13,coords.y+3,  coords.z-11, 98, 1);
       World.setBlock(coords.x-13,coords.y+2,  coords.z-11, 98, 1);
       World.setBlock(coords.x-13,coords.y+1,  coords.z-11, 98, 1);
       World.setBlock(coords.x-13,coords.y,  coords.z-11, 98, 1);
       World.setBlock(coords.x-13,coords.y-1,  coords.z-11, 98, 1);
       World.setBlock(coords.x-13,coords.y-2,  coords.z-11, 98, 1);
       World.setBlock(coords.x-13,coords.y-3,  coords.z-11, 98, 1);
//
World.setBlock(coords.x-13,coords.y+3,  coords.z-10, 98, 1);
       World.setBlock(coords.x-13,coords.y+2,  coords.z-10, 98, 1);
       World.setBlock(coords.x-13,coords.y+1,  coords.z-10, 98, 1);
       World.setBlock(coords.x-13,coords.y,  coords.z-10, 98, 1);
       World.setBlock(coords.x-13,coords.y-1,  coords.z-10, 98, 1);
       World.setBlock(coords.x-13,coords.y-2,  coords.z-10, 98, 1);
       World.setBlock(coords.x-13,coords.y-3,  coords.z-10, 98, 1);
//
World.setBlock(coords.x-13,coords.y+3,  coords.z-9, 98, 1);
       World.setBlock(coords.x-13,coords.y+2,  coords.z-9, 98, 1);
       World.setBlock(coords.x-13,coords.y+1,  coords.z-9, 98, 1);
       World.setBlock(coords.x-13,coords.y,  coords.z-9, 98, 1);
       World.setBlock(coords.x-13,coords.y-1,  coords.z-9, 98, 1);
       World.setBlock(coords.x-13,coords.y-2,  coords.z-9, 98, 1);
       World.setBlock(coords.x-13,coords.y-3,  coords.z-9, 98, 1);
//
World.setBlock(coords.x-13,coords.y+3,  coords.z-8, 98, 1);
       World.setBlock(coords.x-13,coords.y+2,  coords.z-8, 98, 1);
       World.setBlock(coords.x-13,coords.y+1,  coords.z-8, 98, 1);
       World.setBlock(coords.x-13,coords.y,  coords.z-8, 98, 1);
       World.setBlock(coords.x-13,coords.y-1,  coords.z-8, 98, 1);
       World.setBlock(coords.x-13,coords.y-2,  coords.z-8, 98, 1);
       World.setBlock(coords.x-13,coords.y-3,  coords.z-8, 98, 1);
       //
       World.setBlock(coords.x-13,coords.y+3,  coords.z-7, 98, 1);
       World.setBlock(coords.x-13,coords.y+2,  coords.z-7, 98, 1);
       World.setBlock(coords.x-13,coords.y+1,  coords.z-7, 98, 1);
       World.setBlock(coords.x-13,coords.y,  coords.z-7, 98, 1);
       World.setBlock(coords.x-13,coords.y-1,  coords.z-7, 98, 1);
       World.setBlock(coords.x-13,coords.y-2,  coords.z-7, 98, 1);
       World.setBlock(coords.x-13,coords.y-3,  coords.z-7, 98, 1);
       //
       World.setBlock(coords.x-13,coords.y+3,  coords.z-6, 98, 1);
       World.setBlock(coords.x-13,coords.y+2,  coords.z-6, 98, 1);
       World.setBlock(coords.x-13,coords.y+1,  coords.z-6, 98, 1);
       World.setBlock(coords.x-13,coords.y,  coords.z-6, 98, 1);
       World.setBlock(coords.x-13,coords.y-1,  coords.z-6, 98, 1);
       World.setBlock(coords.x-13,coords.y-2,  coords.z-6, 98, 1);
       World.setBlock(coords.x-13,coords.y-3,  coords.z-6, 98, 1);
       //
       World.setBlock(coords.x-13,coords.y+3,  coords.z-5, 98, 1);
       World.setBlock(coords.x-13,coords.y+2,  coords.z-5, 98, 1);
       World.setBlock(coords.x-13,coords.y+1,  coords.z-5, 98, 1);
       World.setBlock(coords.x-13,coords.y,  coords.z-5, 98, 1);
       World.setBlock(coords.x-13,coords.y-1,  coords.z-5, 98, 1);
       World.setBlock(coords.x-13,coords.y-2,  coords.z-5, 98, 1);
       World.setBlock(coords.x-13,coords.y-3,  coords.z-5, 98, 1);
       //
       World.setBlock(coords.x-13,coords.y+3,  coords.z-4, 98, 1);
       World.setBlock(coords.x-13,coords.y+2,  coords.z-4, 98, 1);
       World.setBlock(coords.x-13,coords.y+1,  coords.z-4, 98, 1);
       World.setBlock(coords.x-13,coords.y,  coords.z-4, 98, 1);
       World.setBlock(coords.x-13,coords.y-1,  coords.z-4, 98, 1);
       World.setBlock(coords.x-13,coords.y-2,  coords.z-4, 98, 1);
       World.setBlock(coords.x-13,coords.y-3,  coords.z-4, 98, 1);
       //
       World.setBlock(coords.x-13,coords.y+3,  coords.z-3, 98, 1);
       World.setBlock(coords.x-13,coords.y+2,  coords.z-3, 98, 1);
       World.setBlock(coords.x-13,coords.y+1,  coords.z-3, 98, 1);
       World.setBlock(coords.x-13,coords.y,  coords.z-3, 98, 1);
       World.setBlock(coords.x-13,coords.y-1,  coords.z-3, 98, 1);
       World.setBlock(coords.x-13,coords.y-2,  coords.z-3, 98, 1);
       World.setBlock(coords.x-13,coords.y-3,  coords.z-3, 98, 1);
       //
       World.setBlock(coords.x-13,coords.y+3,  coords.z-2, 98, 1);
       World.setBlock(coords.x-13,coords.y+2,  coords.z-2, 98, 1);
       World.setBlock(coords.x-13,coords.y+1,  coords.z-2, 98, 1);
       World.setBlock(coords.x-13,coords.y,  coords.z-2, 98, 1);
       World.setBlock(coords.x-13,coords.y-1,  coords.z-2, 98, 1);
       World.setBlock(coords.x-13,coords.y-2,  coords.z-2, 98, 1);
       World.setBlock(coords.x-13,coords.y-3,  coords.z-2, 98, 1);
       //
       World.setBlock(coords.x-13,coords.y+3,  coords.z-1, 98, 1);
       World.setBlock(coords.x-13,coords.y+2,  coords.z-1, 98, 1);
       World.setBlock(coords.x-13,coords.y+1,  coords.z-1, 98, 1);
       World.setBlock(coords.x-13,coords.y,  coords.z-1, 98, 1);
       World.setBlock(coords.x-13,coords.y-1,  coords.z-1, 98, 1);
       World.setBlock(coords.x-13,coords.y-2,  coords.z-1, 98, 1);
       World.setBlock(coords.x-13,coords.y-3,  coords.z-1, 98, 1);
       
       World.setBlock(coords.x-13,coords.y+3,  coords.z, 98, 1);
       World.setBlock(coords.x-13,coords.y+2,  coords.z, 98, 1);
       World.setBlock(coords.x-13,coords.y+1,  coords.z, 98, 1);
       World.setBlock(coords.x-13,coords.y,  coords.z, 98, 1);
       World.setBlock(coords.x-13,coords.y-1,  coords.z, 98, 1);
       World.setBlock(coords.x-13,coords.y-2,  coords.z, 98, 1);
       World.setBlock(coords.x-13,coords.y-3,  coords.z, 98, 1);
       //
       World.setBlock(coords.x-13,coords.y+3,  coords.z+1, 98, 1);
       World.setBlock(coords.x-13,coords.y+2,  coords.z+1, 98, 1);
       World.setBlock(coords.x-13,coords.y+1,  coords.z+1, 98, 1);
       World.setBlock(coords.x-13,coords.y,  coords.z+1, 98, 1);
       World.setBlock(coords.x-13,coords.y-1,  coords.z+1, 98, 1);
       World.setBlock(coords.x-13,coords.y-2,  coords.z+1, 98, 1);
       World.setBlock(coords.x-13,coords.y-3,  coords.z+1, 98, 1);
       World.setBlock(coords.x-13,coords.y+3,  coords.z+2, 98, 1);
       World.setBlock(coords.x-13,coords.y+2,  coords.z+2, 98, 1);
       World.setBlock(coords.x-13,coords.y+1,  coords.z+2, 98, 1);
       World.setBlock(coords.x-13,coords.y,  coords.z+2, 98, 1);
       World.setBlock(coords.x-13,coords.y-1,  coords.z+2, 98, 1);
       World.setBlock(coords.x-13,coords.y-2,  coords.z+2, 98, 1);
       World.setBlock(coords.x-13,coords.y-3,  coords.z+2, 98, 1);
       World.setBlock(coords.x-13,coords.y+3,  coords.z+3, 98, 1);
       World.setBlock(coords.x-13,coords.y+2,  coords.z+3, 98, 1);
       World.setBlock(coords.x-13,coords.y+1,  coords.z+3, 98, 1);
       World.setBlock(coords.x-13,coords.y,  coords.z+3, 98, 1);
       World.setBlock(coords.x-13,coords.y-1,  coords.z+3, 98, 1);
       World.setBlock(coords.x-13,coords.y-2,  coords.z+3, 98, 1);
       World.setBlock(coords.x-13,coords.y-3,  coords.z+3, 98, 1);
       World.setBlock(coords.x-13,coords.y+3,  coords.z+4, 98, 1);
       World.setBlock(coords.x-13,coords.y+2,  coords.z+4, 98, 1);
       World.setBlock(coords.x-13,coords.y+1,  coords.z+4, 98, 1);
       World.setBlock(coords.x-13,coords.y,  coords.z+4, 98, 1);
       World.setBlock(coords.x-13,coords.y-1,  coords.z+4, 98, 1);
       World.setBlock(coords.x-13,coords.y-2,  coords.z+4, 98, 1);
       World.setBlock(coords.x-13,coords.y-3,  coords.z+4, 98, 1);
       World.setBlock(coords.x-13,coords.y+3,  coords.z+5, 98, 1);
       World.setBlock(coords.x-13,coords.y+2,  coords.z+5, 98, 1);
       World.setBlock(coords.x-13,coords.y+1,  coords.z+5, 98, 1);
       World.setBlock(coords.x-13,coords.y,  coords.z+5, 98, 1);
       World.setBlock(coords.x-13,coords.y-1,  coords.z+5, 98, 1);
       World.setBlock(coords.x-13,coords.y-2,  coords.z+5, 98, 1);
       World.setBlock(coords.x-13,coords.y-3,  coords.z+5, 98, 1);
       World.setBlock(coords.x-13,coords.y+3,  coords.z+6, 98, 1);
       World.setBlock(coords.x-13,coords.y+2,  coords.z+6, 98, 1);
       World.setBlock(coords.x-13,coords.y+1,  coords.z+6, 98, 1);
       World.setBlock(coords.x-13,coords.y,  coords.z+6, 98, 1);
       World.setBlock(coords.x-13,coords.y-1,  coords.z+6, 98, 1);
       World.setBlock(coords.x-13,coords.y-2,  coords.z+6, 98, 1);
       World.setBlock(coords.x-13,coords.y-3,  coords.z+6, 98, 1);
       World.setBlock(coords.x-13,coords.y+3,  coords.z+7, 98, 1);
       World.setBlock(coords.x-13,coords.y+2,  coords.z+7, 98, 1);
       World.setBlock(coords.x-13,coords.y+1,  coords.z+7, 98, 1);
       World.setBlock(coords.x-13,coords.y,  coords.z+7, 98, 1);
       World.setBlock(coords.x-13,coords.y-1,  coords.z+7, 98, 1);
       World.setBlock(coords.x-13,coords.y-2,  coords.z+7, 98, 1);
       World.setBlock(coords.x-13,coords.y-3,  coords.z+7, 98, 1);
       World.setBlock(coords.x-13,coords.y+3,  coords.z+8, 98, 1);
       World.setBlock(coords.x-13,coords.y+2,  coords.z+8, 98, 1);
       World.setBlock(coords.x-13,coords.y+1,  coords.z+8, 98, 1);
       World.setBlock(coords.x-13,coords.y,  coords.z+8, 98, 1);
       World.setBlock(coords.x-13,coords.y-1,  coords.z+8, 98, 1);
       World.setBlock(coords.x-13,coords.y-2,  coords.z+8, 98, 1);
       World.setBlock(coords.x-13,coords.y-3,  coords.z+8, 98, 1);
       World.setBlock(coords.x-13,coords.y+3,  coords.z+9, 98, 1);
       World.setBlock(coords.x-13,coords.y+2,  coords.z+9, 98, 1);
       World.setBlock(coords.x-13,coords.y+1,  coords.z+9, 98, 1);
       World.setBlock(coords.x-13,coords.y,  coords.z+9, 98, 1);
       World.setBlock(coords.x-13,coords.y-1,  coords.z+9, 98, 1);
       World.setBlock(coords.x-13,coords.y-2,  coords.z+9, 98, 1);
       World.setBlock(coords.x-13,coords.y-3,  coords.z+9, 98, 1);
       World.setBlock(coords.x-13,coords.y+3,  coords.z+10, 98, 1);
       World.setBlock(coords.x-13,coords.y+2,  coords.z+10, 98, 1);
       World.setBlock(coords.x-13,coords.y+1,  coords.z+10, 98, 1);
       World.setBlock(coords.x-13,coords.y,  coords.z+10, 98, 1);
       World.setBlock(coords.x-13,coords.y-1,  coords.z+10, 98, 1);
       World.setBlock(coords.x-13,coords.y-2,  coords.z+10, 98, 1);
       World.setBlock(coords.x-13,coords.y-3,  coords.z+10, 98, 1);
       World.setBlock(coords.x-13,coords.y+3,  coords.z+11, 98, 1);
       World.setBlock(coords.x-13,coords.y+2,  coords.z+11, 98, 1);
       World.setBlock(coords.x-13,coords.y+1,  coords.z+11, 98, 1);
       World.setBlock(coords.x-13,coords.y,  coords.z+11, 98, 1);
       World.setBlock(coords.x-13,coords.y-1,  coords.z+11, 98, 1);
       World.setBlock(coords.x-13,coords.y-2,  coords.z+11, 98, 1);
       World.setBlock(coords.x-13,coords.y-3,  coords.z+11, 98, 1);
       World.setBlock(coords.x-13,coords.y+3,  coords.z+12, 98, 1);
       World.setBlock(coords.x-13,coords.y+2,  coords.z+12, 98, 1);
       World.setBlock(coords.x-13,coords.y+1,  coords.z+12, 98, 1);
       World.setBlock(coords.x-13,coords.y,  coords.z+12, 98, 1);
       World.setBlock(coords.x-13,coords.y-1,  coords.z+12, 98, 1);
       World.setBlock(coords.x-13,coords.y-2,  coords.z+12, 98, 1);
       World.setBlock(coords.x-13,coords.y-3,  coords.z+12, 98, 1);
       World.setBlock(coords.x-13,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x-13,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x-13,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x-13,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x-13,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x-13,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x-13,coords.y-3,  coords.z+13, 98, 1);
       
      //2
      World.setBlock(coords.x-12,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x-12,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x-12,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x-12,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x-12,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x-12,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x-12,coords.y-3,  coords.z+13, 98, 1);
      World.setBlock(coords.x-11,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x-11,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x-11,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x-11,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x-11,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x-11,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x-11,coords.y-3,  coords.z+13, 98, 1);
      World.setBlock(coords.x-10,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x-10,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x-10,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x-10,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x-10,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x-10,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x-10,coords.y-3,  coords.z+13, 98, 1);
      World.setBlock(coords.x-9,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x-9,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x-9,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x-9,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x-9,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x-9,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x-9,coords.y-3,  coords.z+13, 98, 1);
      World.setBlock(coords.x-8,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x-8,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x-8,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x-8,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x-8,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x-8,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x-8,coords.y-3,  coords.z+13, 98, 1);
      World.setBlock(coords.x-7,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x-7,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x-7,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x-7,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x-7,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x-7,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x-7,coords.y-3,  coords.z+13, 98, 1);
      World.setBlock(coords.x-6,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x-6,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x-6,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x-6,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x-6,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x-6,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x-6,coords.y-3,  coords.z+13, 98, 1);
      World.setBlock(coords.x-5,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x-5,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x-5,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x-5,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x-5,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x-5,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x-5,coords.y-3,  coords.z+13, 98, 1);
      World.setBlock(coords.x-4,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x-4,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x-4,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x-4,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x-4,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x-4,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x-4,coords.y-3,  coords.z+13, 98, 1);
      World.setBlock(coords.x-3,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x-3,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x-3,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x-3,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x-3,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x-3,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x-3,coords.y-3,  coords.z+13, 98, 1);
      World.setBlock(coords.x-2,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x-2,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x-2,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x-2,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x-2,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x-2,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x-2,coords.y-3,  coords.z+13, 98, 1);
      World.setBlock(coords.x-1,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x-1,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x-1,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x-1,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x-1,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x-1,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x-1,coords.y-3,  coords.z+13, 98, 1);
      World.setBlock(coords.x,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x,coords.y-3,  coords.z+13, 98, 1);
      World.setBlock(coords.x+1,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x+1,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+1,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+1,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x+1,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+1,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+1,coords.y-3,  coords.z+13, 98, 1);
      World.setBlock(coords.x+2,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x+2,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+2,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+2,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x+2,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+2,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+2,coords.y-3,  coords.z+13, 98, 1);
      World.setBlock(coords.x+3,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x+3,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+3,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+3,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x+3,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+3,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+3,coords.y-3,  coords.z+13, 98, 1);
      World.setBlock(coords.x+4,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x+4,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+4,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+4,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x+4,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+4,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+4,coords.y-3,  coords.z+13, 98, 1);
      World.setBlock(coords.x+5,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x+5,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+5,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+5,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x+5,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+5,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+5,coords.y-3,  coords.z+13, 98, 1);
      World.setBlock(coords.x+6,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x+6,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+6,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+6,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x+6,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+6,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+6,coords.y-3,  coords.z+13, 98, 1);
      World.setBlock(coords.x+7,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x+7,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+7,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+7,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x+7,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+7,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+7,coords.y-3,  coords.z+13, 98, 1);
      World.setBlock(coords.x+8,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x+8,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+8,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+8,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x+8,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+8,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+8,coords.y-3,  coords.z+13, 98, 1);
      World.setBlock(coords.x+9,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x+9,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+9,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+9,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x+9,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+9,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+9,coords.y-3,  coords.z+13, 98, 1);
       World.setBlock(coords.x+10,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x+10,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+10,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+10,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x+10,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+10,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+10,coords.y-3,  coords.z+13, 98, 1);
       World.setBlock(coords.x+11,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x+11,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+11,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+11,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x+11,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+11,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+11,coords.y-3,  coords.z+13, 98, 1);
       World.setBlock(coords.x+12,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x+12,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+12,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+12,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x+12,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+12,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+12,coords.y-3,  coords.z+13, 98, 1);
       World.setBlock(coords.x+13,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z+13, 98, 1);
       //3
       World.setBlock(coords.x+13,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z-13, 98, 1);
       //
       World.setBlock(coords.x+13,coords.y+3,  coords.z-12, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z-12, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z-12, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z-12, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z-12, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z-12, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z-12, 98, 1);
       //
       World.setBlock(coords.x+13,coords.y+3,  coords.z-11, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z-11, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z-11, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z-11, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z-11, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z-11, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z-11, 98, 1);
//
World.setBlock(coords.x+13,coords.y+3,  coords.z-10, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z-10, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z-10, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z-10, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z-10, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z-10, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z-10, 98, 1);
//
World.setBlock(coords.x+13,coords.y+3,  coords.z-9, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z-9, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z-9, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z-9, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z-9, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z-9, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z-9, 98, 1);
//
World.setBlock(coords.x+13,coords.y+3,  coords.z-8, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z-8, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z-8, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z-8, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z-8, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z-8, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z-8, 98, 1);
       //
       World.setBlock(coords.x+13,coords.y+3,  coords.z-7, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z-7, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z-7, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z-7, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z-7, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z-7, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z-7, 98, 1);
       //
       World.setBlock(coords.x+13,coords.y+3,  coords.z-6, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z-6, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z-6, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z-6, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z-6, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z-6, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z-6, 98, 1);
       //
       World.setBlock(coords.x+13,coords.y+3,  coords.z-5, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z-5, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z-5, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z-5, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z-5, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z-5, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z-5, 98, 1);
       //
       World.setBlock(coords.x+13,coords.y+3,  coords.z-4, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z-4, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z-4, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z-4, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z-4, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z-4, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z-4, 98, 1);
       //
       World.setBlock(coords.x+13,coords.y+3,  coords.z-3, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z-3, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z-3, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z-3, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z-3, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z-3, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z-3, 98, 1);
       //
       World.setBlock(coords.x+13,coords.y+3,  coords.z-2, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z-2, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z-2, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z-2, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z-2, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z-2, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z-2, 98, 1);
       //
       World.setBlock(coords.x+13,coords.y+3,  coords.z-1, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z-1, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z-1, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z-1, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z-1, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z-1, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z-1, 98, 1);
       
       World.setBlock(coords.x+13,coords.y+3,  coords.z, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z, 98, 1);
       //
       World.setBlock(coords.x+13,coords.y+3,  coords.z+1, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z+1, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z+1, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z+1, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z+1, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z+1, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z+1, 98, 1);
       World.setBlock(coords.x+13,coords.y+3,  coords.z+2, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z+2, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z+2, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z+2, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z+2, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z+2, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z+2, 98, 1);
       World.setBlock(coords.x+13,coords.y+3,  coords.z+3, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z+3, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z+3, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z+3, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z+3, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z+3, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z+3, 98, 1);
       World.setBlock(coords.x+13,coords.y+3,  coords.z+4, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z+4, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z+4, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z+4, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z+4, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z+4, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z+4, 98, 1);
       World.setBlock(coords.x+13,coords.y+3,  coords.z+5, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z+5, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z+5, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z+5, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z+5, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z+5, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z+5, 98, 1);
       World.setBlock(coords.x+13,coords.y+3,  coords.z+6, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z+6, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z+6, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z+6, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z+6, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z+6, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z+6, 98, 1);
       World.setBlock(coords.x+13,coords.y+3,  coords.z+7, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z+7, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z+7, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z+7, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z+7, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z+7, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z+7, 98, 1);
       World.setBlock(coords.x+13,coords.y+3,  coords.z+8, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z+8, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z+8, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z+8, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z+8, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z+8, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z+8, 98, 1);
       World.setBlock(coords.x+13,coords.y+3,  coords.z+9, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z+9, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z+9, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z+9, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z+9, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z+9, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z+9, 98, 1);
       World.setBlock(coords.x+13,coords.y+3,  coords.z+10, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z+10, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z+10, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z+10, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z+10, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z+10, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z+10, 98, 1);
       World.setBlock(coords.x+13,coords.y+3,  coords.z+11, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z+11, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z+11, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z+11, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z+11, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z+11, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z+11, 98, 1);
       World.setBlock(coords.x+13,coords.y+3,  coords.z+12, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z+12, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z+12, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z+12, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z+12, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z+12, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z+12, 98, 1);
       World.setBlock(coords.x+13,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z+13, 98, 1);
//
World.setBlock(coords.x-12,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x-12,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x-12,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x-12,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x-12,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x-12,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x-12,coords.y-3,  coords.z-13, 98, 1);
      World.setBlock(coords.x-11,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x-11,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x-11,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x-11,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x-11,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x-11,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x-11,coords.y-3,  coords.z-13, 98, 1);
      World.setBlock(coords.x-10,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x-10,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x-10,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x-10,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x-10,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x-10,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x-10,coords.y-3,  coords.z-13, 98, 1);
      World.setBlock(coords.x-9,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x-9,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x-9,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x-9,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x-9,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x-9,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x-9,coords.y-3,  coords.z-13, 98, 1);
      World.setBlock(coords.x-8,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x-8,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x-8,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x-8,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x-8,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x-8,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x-8,coords.y-3,  coords.z-13, 98, 1);
      World.setBlock(coords.x-7,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x-7,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x-7,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x-7,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x-7,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x-7,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x-7,coords.y-3,  coords.z-13, 98, 1);
      World.setBlock(coords.x-6,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x-6,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x-6,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x-6,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x-6,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x-6,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x-6,coords.y-3,  coords.z-13, 98, 1);
      World.setBlock(coords.x-5,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x-5,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x-5,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x-5,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x-5,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x-5,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x-5,coords.y-3,  coords.z-13, 98, 1);
      World.setBlock(coords.x-4,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x-4,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x-4,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x-4,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x-4,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x-4,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x-4,coords.y-3,  coords.z-13, 98, 1);
      World.setBlock(coords.x-3,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x-3,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x-3,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x-3,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x-3,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x-3,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x-3,coords.y-3,  coords.z-13, 98, 1);
      World.setBlock(coords.x-2,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x-2,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x-2,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x-2,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x-2,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x-2,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x-2,coords.y-3,  coords.z-13, 98, 1);
      World.setBlock(coords.x-1,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x-1,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x-1,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x-1,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x-1,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x-1,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x-1,coords.y-3,  coords.z-13, 98, 1);
      World.setBlock(coords.x,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x,coords.y-3,  coords.z-13, 98, 1);
      World.setBlock(coords.x+1,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x+1,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+1,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+1,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x+1,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+1,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+1,coords.y-3,  coords.z-13, 98, 1);
      World.setBlock(coords.x+2,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x+2,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+2,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+2,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x+2,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+2,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+2,coords.y-3,  coords.z-13, 98, 1);
      World.setBlock(coords.x+3,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x+3,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+3,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+3,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x+3,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+3,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+3,coords.y-3,  coords.z-13, 98, 1);
      World.setBlock(coords.x+4,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x+4,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+4,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+4,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x+4,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+4,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+4,coords.y-3,  coords.z-13, 98, 1);
      World.setBlock(coords.x+5,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x+5,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+5,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+5,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x+5,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+5,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+5,coords.y-3,  coords.z-13, 98, 1);
      World.setBlock(coords.x+6,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x+6,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+6,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+6,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x+6,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+6,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+6,coords.y-3,  coords.z-13, 98, 1);
      World.setBlock(coords.x+7,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x+7,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+7,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+7,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x+7,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+7,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+7,coords.y-3,  coords.z-13, 98, 1);
      World.setBlock(coords.x+8,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x+8,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+8,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+8,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x+8,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+8,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+8,coords.y-3,  coords.z-13, 98, 1);
      World.setBlock(coords.x+9,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x+9,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+9,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+9,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x+9,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+9,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+9,coords.y-3,  coords.z-13, 98, 1);
       World.setBlock(coords.x+10,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x+10,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+10,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+10,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x+10,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+10,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+10,coords.y-3,  coords.z-13, 98, 1);
       World.setBlock(coords.x+11,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x+11,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+11,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+11,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x+11,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+11,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+11,coords.y-3,  coords.z-13, 98, 1);
       World.setBlock(coords.x+12,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x+12,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+12,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+12,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x+12,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+12,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+12,coords.y-3,  coords.z-13, 98, 1);
       World.setBlock(coords.x+13,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z-13, 98, 1);
       
  Player.decreaseCarriedItem(1)
  Particles.addParticle(Native.ParticleType.hugeexplosion, coords.x + 0.5, coords.y + 0.5, coords.z + 0.5, 0, 0.1, 0, 0);
  World.playSound(coords.x, coords.y, coords.z, "random.explode", 3)
  World.destroyBlock(coords.x, coords.y, coords.z, 1)
  
}
});




// file: Hexxit Core/Dimensions/THE TWILIGHT FOREST/Mob/lich.js

Callback.addCallback("ItemUse", function(coords, item, block) {
  if (item.id==ItemID.keyLich && block.id== BlockID.o) {
  World.setBlock(coords.x, coords.y, coords.z, 0, 0) 
Entity.spawnAddon (coords.x, coords.y+1, coords.z+5, "twilightforest:lich");
Entity.spawn(coords.x, coords.y+1, coords.z+3, 34); 
Entity.spawn(coords.x, coords.y+1, coords.z, 34); 
Entity.spawn(coords.x, coords.y+1, coords.z+5, 34); 
Entity.spawn(coords.x, coords.y+1, coords.z+6, 34); 
Entity.spawn(coords.x, coords.y+1, coords.z+5, 34); 

World.setBlock(coords.x-13,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x-13,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x-13,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x-13,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x-13,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x-13,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x-13,coords.y-3,  coords.z-13, 98, 1);
       //
       World.setBlock(coords.x-13,coords.y+3,  coords.z-12, 98, 1);
       World.setBlock(coords.x-13,coords.y+2,  coords.z-12, 98, 1);
       World.setBlock(coords.x-13,coords.y+1,  coords.z-12, 98, 1);
       World.setBlock(coords.x-13,coords.y,  coords.z-12, 98, 1);
       World.setBlock(coords.x-13,coords.y-1,  coords.z-12, 98, 1);
       World.setBlock(coords.x-13,coords.y-2,  coords.z-12, 98, 1);
       World.setBlock(coords.x-13,coords.y-3,  coords.z-12, 98, 1);
       //
       World.setBlock(coords.x-13,coords.y+3,  coords.z-11, 98, 1);
       World.setBlock(coords.x-13,coords.y+2,  coords.z-11, 98, 1);
       World.setBlock(coords.x-13,coords.y+1,  coords.z-11, 98, 1);
       World.setBlock(coords.x-13,coords.y,  coords.z-11, 98, 1);
       World.setBlock(coords.x-13,coords.y-1,  coords.z-11, 98, 1);
       World.setBlock(coords.x-13,coords.y-2,  coords.z-11, 98, 1);
       World.setBlock(coords.x-13,coords.y-3,  coords.z-11, 98, 1);
//
World.setBlock(coords.x-13,coords.y+3,  coords.z-10, 98, 1);
       World.setBlock(coords.x-13,coords.y+2,  coords.z-10, 98, 1);
       World.setBlock(coords.x-13,coords.y+1,  coords.z-10, 98, 1);
       World.setBlock(coords.x-13,coords.y,  coords.z-10, 98, 1);
       World.setBlock(coords.x-13,coords.y-1,  coords.z-10, 98, 1);
       World.setBlock(coords.x-13,coords.y-2,  coords.z-10, 98, 1);
       World.setBlock(coords.x-13,coords.y-3,  coords.z-10, 98, 1);
//
World.setBlock(coords.x-13,coords.y+3,  coords.z-9, 98, 1);
       World.setBlock(coords.x-13,coords.y+2,  coords.z-9, 98, 1);
       World.setBlock(coords.x-13,coords.y+1,  coords.z-9, 98, 1);
       World.setBlock(coords.x-13,coords.y,  coords.z-9, 98, 1);
       World.setBlock(coords.x-13,coords.y-1,  coords.z-9, 98, 1);
       World.setBlock(coords.x-13,coords.y-2,  coords.z-9, 98, 1);
       World.setBlock(coords.x-13,coords.y-3,  coords.z-9, 98, 1);
//
World.setBlock(coords.x-13,coords.y+3,  coords.z-8, 98, 1);
       World.setBlock(coords.x-13,coords.y+2,  coords.z-8, 98, 1);
       World.setBlock(coords.x-13,coords.y+1,  coords.z-8, 98, 1);
       World.setBlock(coords.x-13,coords.y,  coords.z-8, 98, 1);
       World.setBlock(coords.x-13,coords.y-1,  coords.z-8, 98, 1);
       World.setBlock(coords.x-13,coords.y-2,  coords.z-8, 98, 1);
       World.setBlock(coords.x-13,coords.y-3,  coords.z-8, 98, 1);
       //
       World.setBlock(coords.x-13,coords.y+3,  coords.z-7, 98, 1);
       World.setBlock(coords.x-13,coords.y+2,  coords.z-7, 98, 1);
       World.setBlock(coords.x-13,coords.y+1,  coords.z-7, 98, 1);
       World.setBlock(coords.x-13,coords.y,  coords.z-7, 98, 1);
       World.setBlock(coords.x-13,coords.y-1,  coords.z-7, 98, 1);
       World.setBlock(coords.x-13,coords.y-2,  coords.z-7, 98, 1);
       World.setBlock(coords.x-13,coords.y-3,  coords.z-7, 98, 1);
       //
       World.setBlock(coords.x-13,coords.y+3,  coords.z-6, 98, 1);
       World.setBlock(coords.x-13,coords.y+2,  coords.z-6, 98, 1);
       World.setBlock(coords.x-13,coords.y+1,  coords.z-6, 98, 1);
       World.setBlock(coords.x-13,coords.y,  coords.z-6, 98, 1);
       World.setBlock(coords.x-13,coords.y-1,  coords.z-6, 98, 1);
       World.setBlock(coords.x-13,coords.y-2,  coords.z-6, 98, 1);
       World.setBlock(coords.x-13,coords.y-3,  coords.z-6, 98, 1);
       //
       World.setBlock(coords.x-13,coords.y+3,  coords.z-5, 98, 1);
       World.setBlock(coords.x-13,coords.y+2,  coords.z-5, 98, 1);
       World.setBlock(coords.x-13,coords.y+1,  coords.z-5, 98, 1);
       World.setBlock(coords.x-13,coords.y,  coords.z-5, 98, 1);
       World.setBlock(coords.x-13,coords.y-1,  coords.z-5, 98, 1);
       World.setBlock(coords.x-13,coords.y-2,  coords.z-5, 98, 1);
       World.setBlock(coords.x-13,coords.y-3,  coords.z-5, 98, 1);
       //
       World.setBlock(coords.x-13,coords.y+3,  coords.z-4, 98, 1);
       World.setBlock(coords.x-13,coords.y+2,  coords.z-4, 98, 1);
       World.setBlock(coords.x-13,coords.y+1,  coords.z-4, 98, 1);
       World.setBlock(coords.x-13,coords.y,  coords.z-4, 98, 1);
       World.setBlock(coords.x-13,coords.y-1,  coords.z-4, 98, 1);
       World.setBlock(coords.x-13,coords.y-2,  coords.z-4, 98, 1);
       World.setBlock(coords.x-13,coords.y-3,  coords.z-4, 98, 1);
       //
       World.setBlock(coords.x-13,coords.y+3,  coords.z-3, 98, 1);
       World.setBlock(coords.x-13,coords.y+2,  coords.z-3, 98, 1);
       World.setBlock(coords.x-13,coords.y+1,  coords.z-3, 98, 1);
       World.setBlock(coords.x-13,coords.y,  coords.z-3, 98, 1);
       World.setBlock(coords.x-13,coords.y-1,  coords.z-3, 98, 1);
       World.setBlock(coords.x-13,coords.y-2,  coords.z-3, 98, 1);
       World.setBlock(coords.x-13,coords.y-3,  coords.z-3, 98, 1);
       //
       World.setBlock(coords.x-13,coords.y+3,  coords.z-2, 98, 1);
       World.setBlock(coords.x-13,coords.y+2,  coords.z-2, 98, 1);
       World.setBlock(coords.x-13,coords.y+1,  coords.z-2, 98, 1);
       World.setBlock(coords.x-13,coords.y,  coords.z-2, 98, 1);
       World.setBlock(coords.x-13,coords.y-1,  coords.z-2, 98, 1);
       World.setBlock(coords.x-13,coords.y-2,  coords.z-2, 98, 1);
       World.setBlock(coords.x-13,coords.y-3,  coords.z-2, 98, 1);
       //
       World.setBlock(coords.x-13,coords.y+3,  coords.z-1, 98, 1);
       World.setBlock(coords.x-13,coords.y+2,  coords.z-1, 98, 1);
       World.setBlock(coords.x-13,coords.y+1,  coords.z-1, 98, 1);
       World.setBlock(coords.x-13,coords.y,  coords.z-1, 98, 1);
       World.setBlock(coords.x-13,coords.y-1,  coords.z-1, 98, 1);
       World.setBlock(coords.x-13,coords.y-2,  coords.z-1, 98, 1);
       World.setBlock(coords.x-13,coords.y-3,  coords.z-1, 98, 1);
       
       World.setBlock(coords.x-13,coords.y+3,  coords.z, 98, 1);
       World.setBlock(coords.x-13,coords.y+2,  coords.z, 98, 1);
       World.setBlock(coords.x-13,coords.y+1,  coords.z, 98, 1);
       World.setBlock(coords.x-13,coords.y,  coords.z, 98, 1);
       World.setBlock(coords.x-13,coords.y-1,  coords.z, 98, 1);
       World.setBlock(coords.x-13,coords.y-2,  coords.z, 98, 1);
       World.setBlock(coords.x-13,coords.y-3,  coords.z, 98, 1);
       //
       World.setBlock(coords.x-13,coords.y+3,  coords.z+1, 98, 1);
       World.setBlock(coords.x-13,coords.y+2,  coords.z+1, 98, 1);
       World.setBlock(coords.x-13,coords.y+1,  coords.z+1, 98, 1);
       World.setBlock(coords.x-13,coords.y,  coords.z+1, 98, 1);
       World.setBlock(coords.x-13,coords.y-1,  coords.z+1, 98, 1);
       World.setBlock(coords.x-13,coords.y-2,  coords.z+1, 98, 1);
       World.setBlock(coords.x-13,coords.y-3,  coords.z+1, 98, 1);
       World.setBlock(coords.x-13,coords.y+3,  coords.z+2, 98, 1);
       World.setBlock(coords.x-13,coords.y+2,  coords.z+2, 98, 1);
       World.setBlock(coords.x-13,coords.y+1,  coords.z+2, 98, 1);
       World.setBlock(coords.x-13,coords.y,  coords.z+2, 98, 1);
       World.setBlock(coords.x-13,coords.y-1,  coords.z+2, 98, 1);
       World.setBlock(coords.x-13,coords.y-2,  coords.z+2, 98, 1);
       World.setBlock(coords.x-13,coords.y-3,  coords.z+2, 98, 1);
       World.setBlock(coords.x-13,coords.y+3,  coords.z+3, 98, 1);
       World.setBlock(coords.x-13,coords.y+2,  coords.z+3, 98, 1);
       World.setBlock(coords.x-13,coords.y+1,  coords.z+3, 98, 1);
       World.setBlock(coords.x-13,coords.y,  coords.z+3, 98, 1);
       World.setBlock(coords.x-13,coords.y-1,  coords.z+3, 98, 1);
       World.setBlock(coords.x-13,coords.y-2,  coords.z+3, 98, 1);
       World.setBlock(coords.x-13,coords.y-3,  coords.z+3, 98, 1);
       World.setBlock(coords.x-13,coords.y+3,  coords.z+4, 98, 1);
       World.setBlock(coords.x-13,coords.y+2,  coords.z+4, 98, 1);
       World.setBlock(coords.x-13,coords.y+1,  coords.z+4, 98, 1);
       World.setBlock(coords.x-13,coords.y,  coords.z+4, 98, 1);
       World.setBlock(coords.x-13,coords.y-1,  coords.z+4, 98, 1);
       World.setBlock(coords.x-13,coords.y-2,  coords.z+4, 98, 1);
       World.setBlock(coords.x-13,coords.y-3,  coords.z+4, 98, 1);
       World.setBlock(coords.x-13,coords.y+3,  coords.z+5, 98, 1);
       World.setBlock(coords.x-13,coords.y+2,  coords.z+5, 98, 1);
       World.setBlock(coords.x-13,coords.y+1,  coords.z+5, 98, 1);
       World.setBlock(coords.x-13,coords.y,  coords.z+5, 98, 1);
       World.setBlock(coords.x-13,coords.y-1,  coords.z+5, 98, 1);
       World.setBlock(coords.x-13,coords.y-2,  coords.z+5, 98, 1);
       World.setBlock(coords.x-13,coords.y-3,  coords.z+5, 98, 1);
       World.setBlock(coords.x-13,coords.y+3,  coords.z+6, 98, 1);
       World.setBlock(coords.x-13,coords.y+2,  coords.z+6, 98, 1);
       World.setBlock(coords.x-13,coords.y+1,  coords.z+6, 98, 1);
       World.setBlock(coords.x-13,coords.y,  coords.z+6, 98, 1);
       World.setBlock(coords.x-13,coords.y-1,  coords.z+6, 98, 1);
       World.setBlock(coords.x-13,coords.y-2,  coords.z+6, 98, 1);
       World.setBlock(coords.x-13,coords.y-3,  coords.z+6, 98, 1);
       World.setBlock(coords.x-13,coords.y+3,  coords.z+7, 98, 1);
       World.setBlock(coords.x-13,coords.y+2,  coords.z+7, 98, 1);
       World.setBlock(coords.x-13,coords.y+1,  coords.z+7, 98, 1);
       World.setBlock(coords.x-13,coords.y,  coords.z+7, 98, 1);
       World.setBlock(coords.x-13,coords.y-1,  coords.z+7, 98, 1);
       World.setBlock(coords.x-13,coords.y-2,  coords.z+7, 98, 1);
       World.setBlock(coords.x-13,coords.y-3,  coords.z+7, 98, 1);
       World.setBlock(coords.x-13,coords.y+3,  coords.z+8, 98, 1);
       World.setBlock(coords.x-13,coords.y+2,  coords.z+8, 98, 1);
       World.setBlock(coords.x-13,coords.y+1,  coords.z+8, 98, 1);
       World.setBlock(coords.x-13,coords.y,  coords.z+8, 98, 1);
       World.setBlock(coords.x-13,coords.y-1,  coords.z+8, 98, 1);
       World.setBlock(coords.x-13,coords.y-2,  coords.z+8, 98, 1);
       World.setBlock(coords.x-13,coords.y-3,  coords.z+8, 98, 1);
       World.setBlock(coords.x-13,coords.y+3,  coords.z+9, 98, 1);
       World.setBlock(coords.x-13,coords.y+2,  coords.z+9, 98, 1);
       World.setBlock(coords.x-13,coords.y+1,  coords.z+9, 98, 1);
       World.setBlock(coords.x-13,coords.y,  coords.z+9, 98, 1);
       World.setBlock(coords.x-13,coords.y-1,  coords.z+9, 98, 1);
       World.setBlock(coords.x-13,coords.y-2,  coords.z+9, 98, 1);
       World.setBlock(coords.x-13,coords.y-3,  coords.z+9, 98, 1);
       World.setBlock(coords.x-13,coords.y+3,  coords.z+10, 98, 1);
       World.setBlock(coords.x-13,coords.y+2,  coords.z+10, 98, 1);
       World.setBlock(coords.x-13,coords.y+1,  coords.z+10, 98, 1);
       World.setBlock(coords.x-13,coords.y,  coords.z+10, 98, 1);
       World.setBlock(coords.x-13,coords.y-1,  coords.z+10, 98, 1);
       World.setBlock(coords.x-13,coords.y-2,  coords.z+10, 98, 1);
       World.setBlock(coords.x-13,coords.y-3,  coords.z+10, 98, 1);
       World.setBlock(coords.x-13,coords.y+3,  coords.z+11, 98, 1);
       World.setBlock(coords.x-13,coords.y+2,  coords.z+11, 98, 1);
       World.setBlock(coords.x-13,coords.y+1,  coords.z+11, 98, 1);
       World.setBlock(coords.x-13,coords.y,  coords.z+11, 98, 1);
       World.setBlock(coords.x-13,coords.y-1,  coords.z+11, 98, 1);
       World.setBlock(coords.x-13,coords.y-2,  coords.z+11, 98, 1);
       World.setBlock(coords.x-13,coords.y-3,  coords.z+11, 98, 1);
       World.setBlock(coords.x-13,coords.y+3,  coords.z+12, 98, 1);
       World.setBlock(coords.x-13,coords.y+2,  coords.z+12, 98, 1);
       World.setBlock(coords.x-13,coords.y+1,  coords.z+12, 98, 1);
       World.setBlock(coords.x-13,coords.y,  coords.z+12, 98, 1);
       World.setBlock(coords.x-13,coords.y-1,  coords.z+12, 98, 1);
       World.setBlock(coords.x-13,coords.y-2,  coords.z+12, 98, 1);
       World.setBlock(coords.x-13,coords.y-3,  coords.z+12, 98, 1);
       World.setBlock(coords.x-13,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x-13,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x-13,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x-13,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x-13,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x-13,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x-13,coords.y-3,  coords.z+13, 98, 1);
       
      //2
      World.setBlock(coords.x-12,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x-12,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x-12,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x-12,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x-12,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x-12,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x-12,coords.y-3,  coords.z+13, 98, 1);
      World.setBlock(coords.x-11,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x-11,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x-11,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x-11,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x-11,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x-11,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x-11,coords.y-3,  coords.z+13, 98, 1);
      World.setBlock(coords.x-10,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x-10,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x-10,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x-10,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x-10,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x-10,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x-10,coords.y-3,  coords.z+13, 98, 1);
      World.setBlock(coords.x-9,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x-9,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x-9,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x-9,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x-9,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x-9,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x-9,coords.y-3,  coords.z+13, 98, 1);
      World.setBlock(coords.x-8,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x-8,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x-8,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x-8,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x-8,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x-8,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x-8,coords.y-3,  coords.z+13, 98, 1);
      World.setBlock(coords.x-7,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x-7,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x-7,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x-7,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x-7,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x-7,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x-7,coords.y-3,  coords.z+13, 98, 1);
      World.setBlock(coords.x-6,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x-6,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x-6,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x-6,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x-6,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x-6,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x-6,coords.y-3,  coords.z+13, 98, 1);
      World.setBlock(coords.x-5,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x-5,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x-5,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x-5,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x-5,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x-5,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x-5,coords.y-3,  coords.z+13, 98, 1);
      World.setBlock(coords.x-4,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x-4,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x-4,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x-4,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x-4,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x-4,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x-4,coords.y-3,  coords.z+13, 98, 1);
      World.setBlock(coords.x-3,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x-3,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x-3,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x-3,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x-3,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x-3,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x-3,coords.y-3,  coords.z+13, 98, 1);
      World.setBlock(coords.x-2,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x-2,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x-2,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x-2,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x-2,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x-2,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x-2,coords.y-3,  coords.z+13, 98, 1);
      World.setBlock(coords.x-1,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x-1,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x-1,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x-1,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x-1,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x-1,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x-1,coords.y-3,  coords.z+13, 98, 1);
      World.setBlock(coords.x,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x,coords.y-3,  coords.z+13, 98, 1);
      World.setBlock(coords.x+1,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x+1,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+1,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+1,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x+1,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+1,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+1,coords.y-3,  coords.z+13, 98, 1);
      World.setBlock(coords.x+2,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x+2,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+2,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+2,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x+2,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+2,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+2,coords.y-3,  coords.z+13, 98, 1);
      World.setBlock(coords.x+3,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x+3,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+3,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+3,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x+3,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+3,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+3,coords.y-3,  coords.z+13, 98, 1);
      World.setBlock(coords.x+4,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x+4,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+4,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+4,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x+4,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+4,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+4,coords.y-3,  coords.z+13, 98, 1);
      World.setBlock(coords.x+5,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x+5,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+5,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+5,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x+5,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+5,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+5,coords.y-3,  coords.z+13, 98, 1);
      World.setBlock(coords.x+6,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x+6,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+6,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+6,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x+6,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+6,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+6,coords.y-3,  coords.z+13, 98, 1);
      World.setBlock(coords.x+7,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x+7,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+7,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+7,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x+7,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+7,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+7,coords.y-3,  coords.z+13, 98, 1);
      World.setBlock(coords.x+8,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x+8,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+8,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+8,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x+8,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+8,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+8,coords.y-3,  coords.z+13, 98, 1);
      World.setBlock(coords.x+9,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x+9,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+9,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+9,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x+9,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+9,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+9,coords.y-3,  coords.z+13, 98, 1);
       World.setBlock(coords.x+10,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x+10,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+10,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+10,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x+10,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+10,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+10,coords.y-3,  coords.z+13, 98, 1);
       World.setBlock(coords.x+11,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x+11,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+11,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+11,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x+11,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+11,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+11,coords.y-3,  coords.z+13, 98, 1);
       World.setBlock(coords.x+12,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x+12,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+12,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+12,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x+12,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+12,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+12,coords.y-3,  coords.z+13, 98, 1);
       World.setBlock(coords.x+13,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z+13, 98, 1);
       //3
       World.setBlock(coords.x+13,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z-13, 98, 1);
       //
       World.setBlock(coords.x+13,coords.y+3,  coords.z-12, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z-12, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z-12, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z-12, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z-12, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z-12, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z-12, 98, 1);
       //
       World.setBlock(coords.x+13,coords.y+3,  coords.z-11, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z-11, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z-11, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z-11, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z-11, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z-11, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z-11, 98, 1);
//
World.setBlock(coords.x+13,coords.y+3,  coords.z-10, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z-10, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z-10, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z-10, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z-10, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z-10, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z-10, 98, 1);
//
World.setBlock(coords.x+13,coords.y+3,  coords.z-9, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z-9, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z-9, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z-9, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z-9, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z-9, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z-9, 98, 1);
//
World.setBlock(coords.x+13,coords.y+3,  coords.z-8, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z-8, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z-8, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z-8, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z-8, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z-8, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z-8, 98, 1);
       //
       World.setBlock(coords.x+13,coords.y+3,  coords.z-7, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z-7, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z-7, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z-7, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z-7, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z-7, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z-7, 98, 1);
       //
       World.setBlock(coords.x+13,coords.y+3,  coords.z-6, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z-6, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z-6, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z-6, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z-6, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z-6, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z-6, 98, 1);
       //
       World.setBlock(coords.x+13,coords.y+3,  coords.z-5, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z-5, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z-5, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z-5, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z-5, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z-5, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z-5, 98, 1);
       //
       World.setBlock(coords.x+13,coords.y+3,  coords.z-4, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z-4, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z-4, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z-4, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z-4, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z-4, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z-4, 98, 1);
       //
       World.setBlock(coords.x+13,coords.y+3,  coords.z-3, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z-3, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z-3, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z-3, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z-3, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z-3, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z-3, 98, 1);
       //
       World.setBlock(coords.x+13,coords.y+3,  coords.z-2, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z-2, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z-2, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z-2, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z-2, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z-2, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z-2, 98, 1);
       //
       World.setBlock(coords.x+13,coords.y+3,  coords.z-1, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z-1, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z-1, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z-1, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z-1, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z-1, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z-1, 98, 1);
       
       World.setBlock(coords.x+13,coords.y+3,  coords.z, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z, 98, 1);
       //
       World.setBlock(coords.x+13,coords.y+3,  coords.z+1, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z+1, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z+1, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z+1, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z+1, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z+1, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z+1, 98, 1);
       World.setBlock(coords.x+13,coords.y+3,  coords.z+2, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z+2, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z+2, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z+2, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z+2, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z+2, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z+2, 98, 1);
       World.setBlock(coords.x+13,coords.y+3,  coords.z+3, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z+3, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z+3, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z+3, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z+3, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z+3, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z+3, 98, 1);
       World.setBlock(coords.x+13,coords.y+3,  coords.z+4, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z+4, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z+4, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z+4, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z+4, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z+4, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z+4, 98, 1);
       World.setBlock(coords.x+13,coords.y+3,  coords.z+5, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z+5, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z+5, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z+5, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z+5, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z+5, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z+5, 98, 1);
       World.setBlock(coords.x+13,coords.y+3,  coords.z+6, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z+6, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z+6, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z+6, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z+6, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z+6, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z+6, 98, 1);
       World.setBlock(coords.x+13,coords.y+3,  coords.z+7, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z+7, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z+7, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z+7, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z+7, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z+7, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z+7, 98, 1);
       World.setBlock(coords.x+13,coords.y+3,  coords.z+8, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z+8, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z+8, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z+8, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z+8, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z+8, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z+8, 98, 1);
       World.setBlock(coords.x+13,coords.y+3,  coords.z+9, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z+9, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z+9, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z+9, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z+9, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z+9, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z+9, 98, 1);
       World.setBlock(coords.x+13,coords.y+3,  coords.z+10, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z+10, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z+10, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z+10, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z+10, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z+10, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z+10, 98, 1);
       World.setBlock(coords.x+13,coords.y+3,  coords.z+11, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z+11, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z+11, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z+11, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z+11, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z+11, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z+11, 98, 1);
       World.setBlock(coords.x+13,coords.y+3,  coords.z+12, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z+12, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z+12, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z+12, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z+12, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z+12, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z+12, 98, 1);
       World.setBlock(coords.x+13,coords.y+3,  coords.z+13, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z+13, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z+13, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z+13, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z+13, 98, 1);
//
World.setBlock(coords.x-12,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x-12,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x-12,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x-12,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x-12,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x-12,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x-12,coords.y-3,  coords.z-13, 98, 1);
      World.setBlock(coords.x-11,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x-11,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x-11,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x-11,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x-11,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x-11,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x-11,coords.y-3,  coords.z-13, 98, 1);
      World.setBlock(coords.x-10,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x-10,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x-10,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x-10,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x-10,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x-10,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x-10,coords.y-3,  coords.z-13, 98, 1);
      World.setBlock(coords.x-9,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x-9,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x-9,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x-9,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x-9,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x-9,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x-9,coords.y-3,  coords.z-13, 98, 1);
      World.setBlock(coords.x-8,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x-8,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x-8,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x-8,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x-8,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x-8,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x-8,coords.y-3,  coords.z-13, 98, 1);
      World.setBlock(coords.x-7,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x-7,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x-7,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x-7,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x-7,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x-7,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x-7,coords.y-3,  coords.z-13, 98, 1);
      World.setBlock(coords.x-6,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x-6,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x-6,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x-6,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x-6,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x-6,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x-6,coords.y-3,  coords.z-13, 98, 1);
      World.setBlock(coords.x-5,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x-5,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x-5,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x-5,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x-5,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x-5,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x-5,coords.y-3,  coords.z-13, 98, 1);
      World.setBlock(coords.x-4,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x-4,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x-4,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x-4,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x-4,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x-4,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x-4,coords.y-3,  coords.z-13, 98, 1);
      World.setBlock(coords.x-3,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x-3,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x-3,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x-3,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x-3,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x-3,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x-3,coords.y-3,  coords.z-13, 98, 1);
      World.setBlock(coords.x-2,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x-2,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x-2,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x-2,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x-2,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x-2,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x-2,coords.y-3,  coords.z-13, 98, 1);
      World.setBlock(coords.x-1,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x-1,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x-1,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x-1,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x-1,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x-1,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x-1,coords.y-3,  coords.z-13, 98, 1);
      World.setBlock(coords.x,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x,coords.y-3,  coords.z-13, 98, 1);
      World.setBlock(coords.x+1,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x+1,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+1,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+1,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x+1,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+1,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+1,coords.y-3,  coords.z-13, 98, 1);
      World.setBlock(coords.x+2,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x+2,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+2,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+2,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x+2,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+2,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+2,coords.y-3,  coords.z-13, 98, 1);
      World.setBlock(coords.x+3,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x+3,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+3,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+3,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x+3,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+3,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+3,coords.y-3,  coords.z-13, 98, 1);
      World.setBlock(coords.x+4,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x+4,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+4,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+4,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x+4,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+4,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+4,coords.y-3,  coords.z-13, 98, 1);
      World.setBlock(coords.x+5,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x+5,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+5,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+5,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x+5,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+5,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+5,coords.y-3,  coords.z-13, 98, 1);
      World.setBlock(coords.x+6,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x+6,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+6,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+6,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x+6,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+6,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+6,coords.y-3,  coords.z-13, 98, 1);
      World.setBlock(coords.x+7,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x+7,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+7,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+7,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x+7,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+7,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+7,coords.y-3,  coords.z-13, 98, 1);
      World.setBlock(coords.x+8,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x+8,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+8,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+8,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x+8,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+8,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+8,coords.y-3,  coords.z-13, 98, 1);
      World.setBlock(coords.x+9,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x+9,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+9,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+9,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x+9,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+9,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+9,coords.y-3,  coords.z-13, 98, 1);
       World.setBlock(coords.x+10,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x+10,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+10,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+10,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x+10,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+10,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+10,coords.y-3,  coords.z-13, 98, 1);
       World.setBlock(coords.x+11,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x+11,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+11,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+11,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x+11,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+11,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+11,coords.y-3,  coords.z-13, 98, 1);
       World.setBlock(coords.x+12,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x+12,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+12,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+12,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x+12,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+12,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+12,coords.y-3,  coords.z-13, 98, 1);
       World.setBlock(coords.x+13,coords.y+3,  coords.z-13, 98, 1);
       World.setBlock(coords.x+13,coords.y+2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+13,coords.y+1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+13,coords.y,  coords.z-13, 98, 1);
       World.setBlock(coords.x+13,coords.y-1,  coords.z-13, 98, 1);
       World.setBlock(coords.x+13,coords.y-2,  coords.z-13, 98, 1);
       World.setBlock(coords.x+13,coords.y-3,  coords.z-13, 98, 1);
       
  Player.decreaseCarriedItem(1)
  Particles.addParticle(Native.ParticleType.hugeexplosion, coords.x + 0.5, coords.y + 0.5, coords.z + 0.5, 0, 0.1, 0, 0);
  World.playSound(coords.x, coords.y, coords.z, "random.explode", 3)
  World.destroyBlock(coords.x, coords.y, coords.z, 1)
  
}
});




// file: Hexxit Core/Dimensions/THE TWILIGHT FOREST/Mob/snowqueen.js

Callback.addCallback("ItemUse", function(coords, item, block) {
  if (item.id==ItemID.keySnowQueen && block.id== BlockID.snowQueenOn) {
  World.setBlock(coords.x, coords.y, coords.z, 0, 0) 
Entity.spawnAddon (coords.x, coords.y+1, coords.z+5, "ms:bxnw");
Entity.spawnAddon (coords.x, coords.y+1, coords.z+5, "ms:bj");
Entity.spawnAddon (coords.x, coords.y+1, coords.z+5, "ms:bj"); 
Entity.spawnAddon (coords.x, coords.y+1, coords.z+5, "ms:bj");
Entity.spawnAddon (coords.x, coords.y+1, coords.z+5, "ms:bj");




World.setBlock(coords.x-13,coords.y+3,  coords.z-13, 174, 0);
       World.setBlock(coords.x-13,coords.y+2,  coords.z-13, 174, 0);
       World.setBlock(coords.x-13,coords.y+1,  coords.z-13, 174, 0);
       World.setBlock(coords.x-13,coords.y,  coords.z-13, 174, 0);
       World.setBlock(coords.x-13,coords.y-1,  coords.z-13, 174, 0);
       World.setBlock(coords.x-13,coords.y-2,  coords.z-13, 174, 0);
       World.setBlock(coords.x-13,coords.y-3,  coords.z-13, 174, 0);
       //
       World.setBlock(coords.x-13,coords.y+3,  coords.z-12, 174, 0);
       World.setBlock(coords.x-13,coords.y+2,  coords.z-12, 174, 0);
       World.setBlock(coords.x-13,coords.y+1,  coords.z-12, 174, 0);
       World.setBlock(coords.x-13,coords.y,  coords.z-12, 174, 0);
       World.setBlock(coords.x-13,coords.y-1,  coords.z-12, 174, 0);
       World.setBlock(coords.x-13,coords.y-2,  coords.z-12, 174, 0);
       World.setBlock(coords.x-13,coords.y-3,  coords.z-12, 174, 0);
       //
       World.setBlock(coords.x-13,coords.y+3,  coords.z-11, 174, 0);
       World.setBlock(coords.x-13,coords.y+2,  coords.z-11, 174, 0);
       World.setBlock(coords.x-13,coords.y+1,  coords.z-11, 174, 0);
       World.setBlock(coords.x-13,coords.y,  coords.z-11, 174, 0);
       World.setBlock(coords.x-13,coords.y-1,  coords.z-11, 174, 0);
       World.setBlock(coords.x-13,coords.y-2,  coords.z-11, 174, 0);
       World.setBlock(coords.x-13,coords.y-3,  coords.z-11, 174, 0);
//
World.setBlock(coords.x-13,coords.y+3,  coords.z-10, 174, 0);
       World.setBlock(coords.x-13,coords.y+2,  coords.z-10, 174, 0);
       World.setBlock(coords.x-13,coords.y+1,  coords.z-10, 174, 0);
       World.setBlock(coords.x-13,coords.y,  coords.z-10, 174, 0);
       World.setBlock(coords.x-13,coords.y-1,  coords.z-10, 174, 0);
       World.setBlock(coords.x-13,coords.y-2,  coords.z-10, 174, 0);
       World.setBlock(coords.x-13,coords.y-3,  coords.z-10, 174, 0);
//
World.setBlock(coords.x-13,coords.y+3,  coords.z-9, 174, 0);
       World.setBlock(coords.x-13,coords.y+2,  coords.z-9, 174, 0);
       World.setBlock(coords.x-13,coords.y+1,  coords.z-9, 174, 0);
       World.setBlock(coords.x-13,coords.y,  coords.z-9, 174, 0);
       World.setBlock(coords.x-13,coords.y-1,  coords.z-9, 174, 0);
       World.setBlock(coords.x-13,coords.y-2,  coords.z-9, 174, 0);
       World.setBlock(coords.x-13,coords.y-3,  coords.z-9, 174, 0);
//
World.setBlock(coords.x-13,coords.y+3,  coords.z-8, 174, 0);
       World.setBlock(coords.x-13,coords.y+2,  coords.z-8, 174, 0);
       World.setBlock(coords.x-13,coords.y+1,  coords.z-8, 174, 0);
       World.setBlock(coords.x-13,coords.y,  coords.z-8, 174, 0);
       World.setBlock(coords.x-13,coords.y-1,  coords.z-8, 174, 0);
       World.setBlock(coords.x-13,coords.y-2,  coords.z-8, 174, 0);
       World.setBlock(coords.x-13,coords.y-3,  coords.z-8, 174, 0);
       //
       World.setBlock(coords.x-13,coords.y+3,  coords.z-7, 174, 0);
       World.setBlock(coords.x-13,coords.y+2,  coords.z-7, 174, 0);
       World.setBlock(coords.x-13,coords.y+1,  coords.z-7, 174, 0);
       World.setBlock(coords.x-13,coords.y,  coords.z-7, 174, 0);
       World.setBlock(coords.x-13,coords.y-1,  coords.z-7, 174, 0);
       World.setBlock(coords.x-13,coords.y-2,  coords.z-7, 174, 0);
       World.setBlock(coords.x-13,coords.y-3,  coords.z-7, 174, 0);
       //
       World.setBlock(coords.x-13,coords.y+3,  coords.z-6, 174, 0);
       World.setBlock(coords.x-13,coords.y+2,  coords.z-6, 174, 0);
       World.setBlock(coords.x-13,coords.y+1,  coords.z-6, 174, 0);
       World.setBlock(coords.x-13,coords.y,  coords.z-6, 174, 0);
       World.setBlock(coords.x-13,coords.y-1,  coords.z-6, 174, 0);
       World.setBlock(coords.x-13,coords.y-2,  coords.z-6, 174, 0);
       World.setBlock(coords.x-13,coords.y-3,  coords.z-6, 174, 0);
       //
       World.setBlock(coords.x-13,coords.y+3,  coords.z-5, 174, 0);
       World.setBlock(coords.x-13,coords.y+2,  coords.z-5, 174, 0);
       World.setBlock(coords.x-13,coords.y+1,  coords.z-5, 174, 0);
       World.setBlock(coords.x-13,coords.y,  coords.z-5, 174, 0);
       World.setBlock(coords.x-13,coords.y-1,  coords.z-5, 174, 0);
       World.setBlock(coords.x-13,coords.y-2,  coords.z-5, 174, 0);
       World.setBlock(coords.x-13,coords.y-3,  coords.z-5, 174, 0);
       //
       World.setBlock(coords.x-13,coords.y+3,  coords.z-4, 174, 0);
       World.setBlock(coords.x-13,coords.y+2,  coords.z-4, 174, 0);
       World.setBlock(coords.x-13,coords.y+1,  coords.z-4, 174, 0);
       World.setBlock(coords.x-13,coords.y,  coords.z-4, 174, 0);
       World.setBlock(coords.x-13,coords.y-1,  coords.z-4, 174, 0);
       World.setBlock(coords.x-13,coords.y-2,  coords.z-4, 174, 0);
       World.setBlock(coords.x-13,coords.y-3,  coords.z-4, 174, 0);
       //
       World.setBlock(coords.x-13,coords.y+3,  coords.z-3, 174, 0);
       World.setBlock(coords.x-13,coords.y+2,  coords.z-3, 174, 0);
       World.setBlock(coords.x-13,coords.y+1,  coords.z-3, 174, 0);
       World.setBlock(coords.x-13,coords.y,  coords.z-3, 174, 0);
       World.setBlock(coords.x-13,coords.y-1,  coords.z-3, 174, 0);
       World.setBlock(coords.x-13,coords.y-2,  coords.z-3, 174, 0);
       World.setBlock(coords.x-13,coords.y-3,  coords.z-3, 174, 0);
       //
       World.setBlock(coords.x-13,coords.y+3,  coords.z-2, 174, 0);
       World.setBlock(coords.x-13,coords.y+2,  coords.z-2, 174, 0);
       World.setBlock(coords.x-13,coords.y+1,  coords.z-2, 174, 0);
       World.setBlock(coords.x-13,coords.y,  coords.z-2, 174, 0);
       World.setBlock(coords.x-13,coords.y-1,  coords.z-2, 174, 0);
       World.setBlock(coords.x-13,coords.y-2,  coords.z-2, 174, 0);
       World.setBlock(coords.x-13,coords.y-3,  coords.z-2, 174, 0);
       //
       World.setBlock(coords.x-13,coords.y+3,  coords.z-1, 174, 0);
       World.setBlock(coords.x-13,coords.y+2,  coords.z-1, 174, 0);
       World.setBlock(coords.x-13,coords.y+1,  coords.z-1, 174, 0);
       World.setBlock(coords.x-13,coords.y,  coords.z-1, 174, 0);
       World.setBlock(coords.x-13,coords.y-1,  coords.z-1, 174, 0);
       World.setBlock(coords.x-13,coords.y-2,  coords.z-1, 174, 0);
       World.setBlock(coords.x-13,coords.y-3,  coords.z-1, 174, 0);
       
       World.setBlock(coords.x-13,coords.y+3,  coords.z, 174, 0);
       World.setBlock(coords.x-13,coords.y+2,  coords.z, 174, 0);
       World.setBlock(coords.x-13,coords.y+1,  coords.z, 174, 0);
       World.setBlock(coords.x-13,coords.y,  coords.z, 174, 0);
       World.setBlock(coords.x-13,coords.y-1,  coords.z, 174, 0);
       World.setBlock(coords.x-13,coords.y-2,  coords.z, 174, 0);
       World.setBlock(coords.x-13,coords.y-3,  coords.z, 174, 0);
       //
       World.setBlock(coords.x-13,coords.y+3,  coords.z+1, 174, 0);
       World.setBlock(coords.x-13,coords.y+2,  coords.z+1, 174, 0);
       World.setBlock(coords.x-13,coords.y+1,  coords.z+1, 174, 0);
       World.setBlock(coords.x-13,coords.y,  coords.z+1, 174, 0);
       World.setBlock(coords.x-13,coords.y-1,  coords.z+1, 174, 0);
       World.setBlock(coords.x-13,coords.y-2,  coords.z+1, 174, 0);
       World.setBlock(coords.x-13,coords.y-3,  coords.z+1, 174, 0);
       World.setBlock(coords.x-13,coords.y+3,  coords.z+2, 174, 0);
       World.setBlock(coords.x-13,coords.y+2,  coords.z+2, 174, 0);
       World.setBlock(coords.x-13,coords.y+1,  coords.z+2, 174, 0);
       World.setBlock(coords.x-13,coords.y,  coords.z+2, 174, 0);
       World.setBlock(coords.x-13,coords.y-1,  coords.z+2, 174, 0);
       World.setBlock(coords.x-13,coords.y-2,  coords.z+2, 174, 0);
       World.setBlock(coords.x-13,coords.y-3,  coords.z+2, 174, 0);
       World.setBlock(coords.x-13,coords.y+3,  coords.z+3, 174, 0);
       World.setBlock(coords.x-13,coords.y+2,  coords.z+3, 174, 0);
       World.setBlock(coords.x-13,coords.y+1,  coords.z+3, 174, 0);
       World.setBlock(coords.x-13,coords.y,  coords.z+3, 174, 0);
       World.setBlock(coords.x-13,coords.y-1,  coords.z+3, 174, 0);
       World.setBlock(coords.x-13,coords.y-2,  coords.z+3, 174, 0);
       World.setBlock(coords.x-13,coords.y-3,  coords.z+3, 174, 0);
       World.setBlock(coords.x-13,coords.y+3,  coords.z+4, 174, 0);
       World.setBlock(coords.x-13,coords.y+2,  coords.z+4, 174, 0);
       World.setBlock(coords.x-13,coords.y+1,  coords.z+4, 174, 0);
       World.setBlock(coords.x-13,coords.y,  coords.z+4, 174, 0);
       World.setBlock(coords.x-13,coords.y-1,  coords.z+4, 174, 0);
       World.setBlock(coords.x-13,coords.y-2,  coords.z+4, 174, 0);
       World.setBlock(coords.x-13,coords.y-3,  coords.z+4, 174, 0);
       World.setBlock(coords.x-13,coords.y+3,  coords.z+5, 174, 0);
       World.setBlock(coords.x-13,coords.y+2,  coords.z+5, 174, 0);
       World.setBlock(coords.x-13,coords.y+1,  coords.z+5, 174, 0);
       World.setBlock(coords.x-13,coords.y,  coords.z+5, 174, 0);
       World.setBlock(coords.x-13,coords.y-1,  coords.z+5, 174, 0);
       World.setBlock(coords.x-13,coords.y-2,  coords.z+5, 174, 0);
       World.setBlock(coords.x-13,coords.y-3,  coords.z+5, 174, 0);
       World.setBlock(coords.x-13,coords.y+3,  coords.z+6, 174, 0);
       World.setBlock(coords.x-13,coords.y+2,  coords.z+6, 174, 0);
       World.setBlock(coords.x-13,coords.y+1,  coords.z+6, 174, 0);
       World.setBlock(coords.x-13,coords.y,  coords.z+6, 174, 0);
       World.setBlock(coords.x-13,coords.y-1,  coords.z+6, 174, 0);
       World.setBlock(coords.x-13,coords.y-2,  coords.z+6, 174, 0);
       World.setBlock(coords.x-13,coords.y-3,  coords.z+6, 174, 0);
       World.setBlock(coords.x-13,coords.y+3,  coords.z+7, 174, 0);
       World.setBlock(coords.x-13,coords.y+2,  coords.z+7, 174, 0);
       World.setBlock(coords.x-13,coords.y+1,  coords.z+7, 174, 0);
       World.setBlock(coords.x-13,coords.y,  coords.z+7, 174, 0);
       World.setBlock(coords.x-13,coords.y-1,  coords.z+7, 174, 0);
       World.setBlock(coords.x-13,coords.y-2,  coords.z+7, 174, 0);
       World.setBlock(coords.x-13,coords.y-3,  coords.z+7, 174, 0);
       World.setBlock(coords.x-13,coords.y+3,  coords.z+8, 174, 0);
       World.setBlock(coords.x-13,coords.y+2,  coords.z+8, 174, 0);
       World.setBlock(coords.x-13,coords.y+1,  coords.z+8, 174, 0);
       World.setBlock(coords.x-13,coords.y,  coords.z+8, 174, 0);
       World.setBlock(coords.x-13,coords.y-1,  coords.z+8, 174, 0);
       World.setBlock(coords.x-13,coords.y-2,  coords.z+8, 174, 0);
       World.setBlock(coords.x-13,coords.y-3,  coords.z+8, 174, 0);
       World.setBlock(coords.x-13,coords.y+3,  coords.z+9, 174, 0);
       World.setBlock(coords.x-13,coords.y+2,  coords.z+9, 174, 0);
       World.setBlock(coords.x-13,coords.y+1,  coords.z+9, 174, 0);
       World.setBlock(coords.x-13,coords.y,  coords.z+9, 174, 0);
       World.setBlock(coords.x-13,coords.y-1,  coords.z+9, 174, 0);
       World.setBlock(coords.x-13,coords.y-2,  coords.z+9, 174, 0);
       World.setBlock(coords.x-13,coords.y-3,  coords.z+9, 174, 0);
       World.setBlock(coords.x-13,coords.y+3,  coords.z+10, 174, 0);
       World.setBlock(coords.x-13,coords.y+2,  coords.z+10, 174, 0);
       World.setBlock(coords.x-13,coords.y+1,  coords.z+10, 174, 0);
       World.setBlock(coords.x-13,coords.y,  coords.z+10, 174, 0);
       World.setBlock(coords.x-13,coords.y-1,  coords.z+10, 174, 0);
       World.setBlock(coords.x-13,coords.y-2,  coords.z+10, 174, 0);
       World.setBlock(coords.x-13,coords.y-3,  coords.z+10, 174, 0);
       World.setBlock(coords.x-13,coords.y+3,  coords.z+11, 174, 0);
       World.setBlock(coords.x-13,coords.y+2,  coords.z+11, 174, 0);
       World.setBlock(coords.x-13,coords.y+1,  coords.z+11, 174, 0);
       World.setBlock(coords.x-13,coords.y,  coords.z+11, 174, 0);
       World.setBlock(coords.x-13,coords.y-1,  coords.z+11, 174, 0);
       World.setBlock(coords.x-13,coords.y-2,  coords.z+11, 174, 0);
       World.setBlock(coords.x-13,coords.y-3,  coords.z+11, 174, 0);
       World.setBlock(coords.x-13,coords.y+3,  coords.z+12, 174, 0);
       World.setBlock(coords.x-13,coords.y+2,  coords.z+12, 174, 0);
       World.setBlock(coords.x-13,coords.y+1,  coords.z+12, 174, 0);
       World.setBlock(coords.x-13,coords.y,  coords.z+12, 174, 0);
       World.setBlock(coords.x-13,coords.y-1,  coords.z+12, 174, 0);
       World.setBlock(coords.x-13,coords.y-2,  coords.z+12, 174, 0);
       World.setBlock(coords.x-13,coords.y-3,  coords.z+12, 174, 0);
       World.setBlock(coords.x-13,coords.y+3,  coords.z+13, 174, 0);
       World.setBlock(coords.x-13,coords.y+2,  coords.z+13, 174, 0);
       World.setBlock(coords.x-13,coords.y+1,  coords.z+13, 174, 0);
       World.setBlock(coords.x-13,coords.y,  coords.z+13, 174, 0);
       World.setBlock(coords.x-13,coords.y-1,  coords.z+13, 174, 0);
       World.setBlock(coords.x-13,coords.y-2,  coords.z+13, 174, 0);
       World.setBlock(coords.x-13,coords.y-3,  coords.z+13, 174, 0);
       
      //2
      World.setBlock(coords.x-12,coords.y+3,  coords.z+13, 174, 0);
       World.setBlock(coords.x-12,coords.y+2,  coords.z+13, 174, 0);
       World.setBlock(coords.x-12,coords.y+1,  coords.z+13, 174, 0);
       World.setBlock(coords.x-12,coords.y,  coords.z+13, 174, 0);
       World.setBlock(coords.x-12,coords.y-1,  coords.z+13, 174, 0);
       World.setBlock(coords.x-12,coords.y-2,  coords.z+13, 174, 0);
       World.setBlock(coords.x-12,coords.y-3,  coords.z+13, 174, 0);
      World.setBlock(coords.x-11,coords.y+3,  coords.z+13, 174, 0);
       World.setBlock(coords.x-11,coords.y+2,  coords.z+13, 174, 0);
       World.setBlock(coords.x-11,coords.y+1,  coords.z+13, 174, 0);
       World.setBlock(coords.x-11,coords.y,  coords.z+13, 174, 0);
       World.setBlock(coords.x-11,coords.y-1,  coords.z+13, 174, 0);
       World.setBlock(coords.x-11,coords.y-2,  coords.z+13, 174, 0);
       World.setBlock(coords.x-11,coords.y-3,  coords.z+13, 174, 0);
      World.setBlock(coords.x-10,coords.y+3,  coords.z+13, 174, 0);
       World.setBlock(coords.x-10,coords.y+2,  coords.z+13, 174, 0);
       World.setBlock(coords.x-10,coords.y+1,  coords.z+13, 174, 0);
       World.setBlock(coords.x-10,coords.y,  coords.z+13, 174, 0);
       World.setBlock(coords.x-10,coords.y-1,  coords.z+13, 174, 0);
       World.setBlock(coords.x-10,coords.y-2,  coords.z+13, 174, 0);
       World.setBlock(coords.x-10,coords.y-3,  coords.z+13, 174, 0);
      World.setBlock(coords.x-9,coords.y+3,  coords.z+13, 174, 0);
       World.setBlock(coords.x-9,coords.y+2,  coords.z+13, 174, 0);
       World.setBlock(coords.x-9,coords.y+1,  coords.z+13, 174, 0);
       World.setBlock(coords.x-9,coords.y,  coords.z+13, 174, 0);
       World.setBlock(coords.x-9,coords.y-1,  coords.z+13, 174, 0);
       World.setBlock(coords.x-9,coords.y-2,  coords.z+13, 174, 0);
       World.setBlock(coords.x-9,coords.y-3,  coords.z+13, 174, 0);
      World.setBlock(coords.x-8,coords.y+3,  coords.z+13, 174, 0);
       World.setBlock(coords.x-8,coords.y+2,  coords.z+13, 174, 0);
       World.setBlock(coords.x-8,coords.y+1,  coords.z+13, 174, 0);
       World.setBlock(coords.x-8,coords.y,  coords.z+13, 174, 0);
       World.setBlock(coords.x-8,coords.y-1,  coords.z+13, 174, 0);
       World.setBlock(coords.x-8,coords.y-2,  coords.z+13, 174, 0);
       World.setBlock(coords.x-8,coords.y-3,  coords.z+13, 174, 0);
      World.setBlock(coords.x-7,coords.y+3,  coords.z+13, 174, 0);
       World.setBlock(coords.x-7,coords.y+2,  coords.z+13, 174, 0);
       World.setBlock(coords.x-7,coords.y+1,  coords.z+13, 174, 0);
       World.setBlock(coords.x-7,coords.y,  coords.z+13, 174, 0);
       World.setBlock(coords.x-7,coords.y-1,  coords.z+13, 174, 0);
       World.setBlock(coords.x-7,coords.y-2,  coords.z+13, 174, 0);
       World.setBlock(coords.x-7,coords.y-3,  coords.z+13, 174, 0);
      World.setBlock(coords.x-6,coords.y+3,  coords.z+13, 174, 0);
       World.setBlock(coords.x-6,coords.y+2,  coords.z+13, 174, 0);
       World.setBlock(coords.x-6,coords.y+1,  coords.z+13, 174, 0);
       World.setBlock(coords.x-6,coords.y,  coords.z+13, 174, 0);
       World.setBlock(coords.x-6,coords.y-1,  coords.z+13, 174, 0);
       World.setBlock(coords.x-6,coords.y-2,  coords.z+13, 174, 0);
       World.setBlock(coords.x-6,coords.y-3,  coords.z+13, 174, 0);
      World.setBlock(coords.x-5,coords.y+3,  coords.z+13, 174, 0);
       World.setBlock(coords.x-5,coords.y+2,  coords.z+13, 174, 0);
       World.setBlock(coords.x-5,coords.y+1,  coords.z+13, 174, 0);
       World.setBlock(coords.x-5,coords.y,  coords.z+13, 174, 0);
       World.setBlock(coords.x-5,coords.y-1,  coords.z+13, 174, 0);
       World.setBlock(coords.x-5,coords.y-2,  coords.z+13, 174, 0);
       World.setBlock(coords.x-5,coords.y-3,  coords.z+13, 174, 0);
      World.setBlock(coords.x-4,coords.y+3,  coords.z+13, 174, 0);
       World.setBlock(coords.x-4,coords.y+2,  coords.z+13, 174, 0);
       World.setBlock(coords.x-4,coords.y+1,  coords.z+13, 174, 0);
       World.setBlock(coords.x-4,coords.y,  coords.z+13, 174, 0);
       World.setBlock(coords.x-4,coords.y-1,  coords.z+13, 174, 0);
       World.setBlock(coords.x-4,coords.y-2,  coords.z+13, 174, 0);
       World.setBlock(coords.x-4,coords.y-3,  coords.z+13, 174, 0);
      World.setBlock(coords.x-3,coords.y+3,  coords.z+13, 174, 0);
       World.setBlock(coords.x-3,coords.y+2,  coords.z+13, 174, 0);
       World.setBlock(coords.x-3,coords.y+1,  coords.z+13, 174, 0);
       World.setBlock(coords.x-3,coords.y,  coords.z+13, 174, 0);
       World.setBlock(coords.x-3,coords.y-1,  coords.z+13, 174, 0);
       World.setBlock(coords.x-3,coords.y-2,  coords.z+13, 174, 0);
       World.setBlock(coords.x-3,coords.y-3,  coords.z+13, 174, 0);
      World.setBlock(coords.x-2,coords.y+3,  coords.z+13, 174, 0);
       World.setBlock(coords.x-2,coords.y+2,  coords.z+13, 174, 0);
       World.setBlock(coords.x-2,coords.y+1,  coords.z+13, 174, 0);
       World.setBlock(coords.x-2,coords.y,  coords.z+13, 174, 0);
       World.setBlock(coords.x-2,coords.y-1,  coords.z+13, 174, 0);
       World.setBlock(coords.x-2,coords.y-2,  coords.z+13, 174, 0);
       World.setBlock(coords.x-2,coords.y-3,  coords.z+13, 174, 0);
      World.setBlock(coords.x-1,coords.y+3,  coords.z+13, 174, 0);
       World.setBlock(coords.x-1,coords.y+2,  coords.z+13, 174, 0);
       World.setBlock(coords.x-1,coords.y+1,  coords.z+13, 174, 0);
       World.setBlock(coords.x-1,coords.y,  coords.z+13, 174, 0);
       World.setBlock(coords.x-1,coords.y-1,  coords.z+13, 174, 0);
       World.setBlock(coords.x-1,coords.y-2,  coords.z+13, 174, 0);
       World.setBlock(coords.x-1,coords.y-3,  coords.z+13, 174, 0);
      World.setBlock(coords.x,coords.y+3,  coords.z+13, 174, 0);
       World.setBlock(coords.x,coords.y+2,  coords.z+13, 174, 0);
       World.setBlock(coords.x,coords.y+1,  coords.z+13, 174, 0);
       World.setBlock(coords.x,coords.y,  coords.z+13, 174, 0);
       World.setBlock(coords.x,coords.y-1,  coords.z+13, 174, 0);
       World.setBlock(coords.x,coords.y-2,  coords.z+13, 174, 0);
       World.setBlock(coords.x,coords.y-3,  coords.z+13, 174, 0);
      World.setBlock(coords.x+1,coords.y+3,  coords.z+13, 174, 0);
       World.setBlock(coords.x+1,coords.y+2,  coords.z+13, 174, 0);
       World.setBlock(coords.x+1,coords.y+1,  coords.z+13, 174, 0);
       World.setBlock(coords.x+1,coords.y,  coords.z+13, 174, 0);
       World.setBlock(coords.x+1,coords.y-1,  coords.z+13, 174, 0);
       World.setBlock(coords.x+1,coords.y-2,  coords.z+13, 174, 0);
       World.setBlock(coords.x+1,coords.y-3,  coords.z+13, 174, 0);
      World.setBlock(coords.x+2,coords.y+3,  coords.z+13, 174, 0);
       World.setBlock(coords.x+2,coords.y+2,  coords.z+13, 174, 0);
       World.setBlock(coords.x+2,coords.y+1,  coords.z+13, 174, 0);
       World.setBlock(coords.x+2,coords.y,  coords.z+13, 174, 0);
       World.setBlock(coords.x+2,coords.y-1,  coords.z+13, 174, 0);
       World.setBlock(coords.x+2,coords.y-2,  coords.z+13, 174, 0);
       World.setBlock(coords.x+2,coords.y-3,  coords.z+13, 174, 0);
      World.setBlock(coords.x+3,coords.y+3,  coords.z+13, 174, 0);
       World.setBlock(coords.x+3,coords.y+2,  coords.z+13, 174, 0);
       World.setBlock(coords.x+3,coords.y+1,  coords.z+13, 174, 0);
       World.setBlock(coords.x+3,coords.y,  coords.z+13, 174, 0);
       World.setBlock(coords.x+3,coords.y-1,  coords.z+13, 174, 0);
       World.setBlock(coords.x+3,coords.y-2,  coords.z+13, 174, 0);
       World.setBlock(coords.x+3,coords.y-3,  coords.z+13, 174, 0);
      World.setBlock(coords.x+4,coords.y+3,  coords.z+13, 174, 0);
       World.setBlock(coords.x+4,coords.y+2,  coords.z+13, 174, 0);
       World.setBlock(coords.x+4,coords.y+1,  coords.z+13, 174, 0);
       World.setBlock(coords.x+4,coords.y,  coords.z+13, 174, 0);
       World.setBlock(coords.x+4,coords.y-1,  coords.z+13, 174, 0);
       World.setBlock(coords.x+4,coords.y-2,  coords.z+13, 174, 0);
       World.setBlock(coords.x+4,coords.y-3,  coords.z+13, 174, 0);
      World.setBlock(coords.x+5,coords.y+3,  coords.z+13, 174, 0);
       World.setBlock(coords.x+5,coords.y+2,  coords.z+13, 174, 0);
       World.setBlock(coords.x+5,coords.y+1,  coords.z+13, 174, 0);
       World.setBlock(coords.x+5,coords.y,  coords.z+13, 174, 0);
       World.setBlock(coords.x+5,coords.y-1,  coords.z+13, 174, 0);
       World.setBlock(coords.x+5,coords.y-2,  coords.z+13, 174, 0);
       World.setBlock(coords.x+5,coords.y-3,  coords.z+13, 174, 0);
      World.setBlock(coords.x+6,coords.y+3,  coords.z+13, 174, 0);
       World.setBlock(coords.x+6,coords.y+2,  coords.z+13, 174, 0);
       World.setBlock(coords.x+6,coords.y+1,  coords.z+13, 174, 0);
       World.setBlock(coords.x+6,coords.y,  coords.z+13, 174, 0);
       World.setBlock(coords.x+6,coords.y-1,  coords.z+13, 174, 0);
       World.setBlock(coords.x+6,coords.y-2,  coords.z+13, 174, 0);
       World.setBlock(coords.x+6,coords.y-3,  coords.z+13, 174, 0);
      World.setBlock(coords.x+7,coords.y+3,  coords.z+13, 174, 0);
       World.setBlock(coords.x+7,coords.y+2,  coords.z+13, 174, 0);
       World.setBlock(coords.x+7,coords.y+1,  coords.z+13, 174, 0);
       World.setBlock(coords.x+7,coords.y,  coords.z+13, 174, 0);
       World.setBlock(coords.x+7,coords.y-1,  coords.z+13, 174, 0);
       World.setBlock(coords.x+7,coords.y-2,  coords.z+13, 174, 0);
       World.setBlock(coords.x+7,coords.y-3,  coords.z+13, 174, 0);
      World.setBlock(coords.x+8,coords.y+3,  coords.z+13, 174, 0);
       World.setBlock(coords.x+8,coords.y+2,  coords.z+13, 174, 0);
       World.setBlock(coords.x+8,coords.y+1,  coords.z+13, 174, 0);
       World.setBlock(coords.x+8,coords.y,  coords.z+13, 174, 0);
       World.setBlock(coords.x+8,coords.y-1,  coords.z+13, 174, 0);
       World.setBlock(coords.x+8,coords.y-2,  coords.z+13, 174, 0);
       World.setBlock(coords.x+8,coords.y-3,  coords.z+13, 174, 0);
      World.setBlock(coords.x+9,coords.y+3,  coords.z+13, 174, 0);
       World.setBlock(coords.x+9,coords.y+2,  coords.z+13, 174, 0);
       World.setBlock(coords.x+9,coords.y+1,  coords.z+13, 174, 0);
       World.setBlock(coords.x+9,coords.y,  coords.z+13, 174, 0);
       World.setBlock(coords.x+9,coords.y-1,  coords.z+13, 174, 0);
       World.setBlock(coords.x+9,coords.y-2,  coords.z+13, 174, 0);
       World.setBlock(coords.x+9,coords.y-3,  coords.z+13, 174, 0);
       World.setBlock(coords.x+10,coords.y+3,  coords.z+13, 174, 0);
       World.setBlock(coords.x+10,coords.y+2,  coords.z+13, 174, 0);
       World.setBlock(coords.x+10,coords.y+1,  coords.z+13, 174, 0);
       World.setBlock(coords.x+10,coords.y,  coords.z+13, 174, 0);
       World.setBlock(coords.x+10,coords.y-1,  coords.z+13, 174, 0);
       World.setBlock(coords.x+10,coords.y-2,  coords.z+13, 174, 0);
       World.setBlock(coords.x+10,coords.y-3,  coords.z+13, 174, 0);
       World.setBlock(coords.x+11,coords.y+3,  coords.z+13, 174, 0);
       World.setBlock(coords.x+11,coords.y+2,  coords.z+13, 174, 0);
       World.setBlock(coords.x+11,coords.y+1,  coords.z+13, 174, 0);
       World.setBlock(coords.x+11,coords.y,  coords.z+13, 174, 0);
       World.setBlock(coords.x+11,coords.y-1,  coords.z+13, 174, 0);
       World.setBlock(coords.x+11,coords.y-2,  coords.z+13, 174, 0);
       World.setBlock(coords.x+11,coords.y-3,  coords.z+13, 174, 0);
       World.setBlock(coords.x+12,coords.y+3,  coords.z+13, 174, 0);
       World.setBlock(coords.x+12,coords.y+2,  coords.z+13, 174, 0);
       World.setBlock(coords.x+12,coords.y+1,  coords.z+13, 174, 0);
       World.setBlock(coords.x+12,coords.y,  coords.z+13, 174, 0);
       World.setBlock(coords.x+12,coords.y-1,  coords.z+13, 174, 0);
       World.setBlock(coords.x+12,coords.y-2,  coords.z+13, 174, 0);
       World.setBlock(coords.x+12,coords.y-3,  coords.z+13, 174, 0);
       World.setBlock(coords.x+13,coords.y+3,  coords.z+13, 174, 0);
       World.setBlock(coords.x+13,coords.y+2,  coords.z+13, 174, 0);
       World.setBlock(coords.x+13,coords.y+1,  coords.z+13, 174, 0);
       World.setBlock(coords.x+13,coords.y,  coords.z+13, 174, 0);
       World.setBlock(coords.x+13,coords.y-1,  coords.z+13, 174, 0);
       World.setBlock(coords.x+13,coords.y-2,  coords.z+13, 174, 0);
       World.setBlock(coords.x+13,coords.y-3,  coords.z+13, 174, 0);
       //3
       World.setBlock(coords.x+13,coords.y+3,  coords.z-13, 174, 0);
       World.setBlock(coords.x+13,coords.y+2,  coords.z-13, 174, 0);
       World.setBlock(coords.x+13,coords.y+1,  coords.z-13, 174, 0);
       World.setBlock(coords.x+13,coords.y,  coords.z-13, 174, 0);
       World.setBlock(coords.x+13,coords.y-1,  coords.z-13, 174, 0);
       World.setBlock(coords.x+13,coords.y-2,  coords.z-13, 174, 0);
       World.setBlock(coords.x+13,coords.y-3,  coords.z-13, 174, 0);
       //
       World.setBlock(coords.x+13,coords.y+3,  coords.z-12, 174, 0);
       World.setBlock(coords.x+13,coords.y+2,  coords.z-12, 174, 0);
       World.setBlock(coords.x+13,coords.y+1,  coords.z-12, 174, 0);
       World.setBlock(coords.x+13,coords.y,  coords.z-12, 174, 0);
       World.setBlock(coords.x+13,coords.y-1,  coords.z-12, 174, 0);
       World.setBlock(coords.x+13,coords.y-2,  coords.z-12, 174, 0);
       World.setBlock(coords.x+13,coords.y-3,  coords.z-12, 174, 0);
       //
       World.setBlock(coords.x+13,coords.y+3,  coords.z-11, 174, 0);
       World.setBlock(coords.x+13,coords.y+2,  coords.z-11, 174, 0);
       World.setBlock(coords.x+13,coords.y+1,  coords.z-11, 174, 0);
       World.setBlock(coords.x+13,coords.y,  coords.z-11, 174, 0);
       World.setBlock(coords.x+13,coords.y-1,  coords.z-11, 174, 0);
       World.setBlock(coords.x+13,coords.y-2,  coords.z-11, 174, 0);
       World.setBlock(coords.x+13,coords.y-3,  coords.z-11, 174, 0);
//
World.setBlock(coords.x+13,coords.y+3,  coords.z-10, 174, 0);
       World.setBlock(coords.x+13,coords.y+2,  coords.z-10, 174, 0);
       World.setBlock(coords.x+13,coords.y+1,  coords.z-10, 174, 0);
       World.setBlock(coords.x+13,coords.y,  coords.z-10, 174, 0);
       World.setBlock(coords.x+13,coords.y-1,  coords.z-10, 174, 0);
       World.setBlock(coords.x+13,coords.y-2,  coords.z-10, 174, 0);
       World.setBlock(coords.x+13,coords.y-3,  coords.z-10, 174, 0);
//
World.setBlock(coords.x+13,coords.y+3,  coords.z-9, 174, 0);
       World.setBlock(coords.x+13,coords.y+2,  coords.z-9, 174, 0);
       World.setBlock(coords.x+13,coords.y+1,  coords.z-9, 174, 0);
       World.setBlock(coords.x+13,coords.y,  coords.z-9, 174, 0);
       World.setBlock(coords.x+13,coords.y-1,  coords.z-9, 174, 0);
       World.setBlock(coords.x+13,coords.y-2,  coords.z-9, 174, 0);
       World.setBlock(coords.x+13,coords.y-3,  coords.z-9, 174, 0);
//
World.setBlock(coords.x+13,coords.y+3,  coords.z-8, 174, 0);
       World.setBlock(coords.x+13,coords.y+2,  coords.z-8, 174, 0);
       World.setBlock(coords.x+13,coords.y+1,  coords.z-8, 174, 0);
       World.setBlock(coords.x+13,coords.y,  coords.z-8, 174, 0);
       World.setBlock(coords.x+13,coords.y-1,  coords.z-8, 174, 0);
       World.setBlock(coords.x+13,coords.y-2,  coords.z-8, 174, 0);
       World.setBlock(coords.x+13,coords.y-3,  coords.z-8, 174, 0);
       //
       World.setBlock(coords.x+13,coords.y+3,  coords.z-7, 174, 0);
       World.setBlock(coords.x+13,coords.y+2,  coords.z-7, 174, 0);
       World.setBlock(coords.x+13,coords.y+1,  coords.z-7, 174, 0);
       World.setBlock(coords.x+13,coords.y,  coords.z-7, 174, 0);
       World.setBlock(coords.x+13,coords.y-1,  coords.z-7, 174, 0);
       World.setBlock(coords.x+13,coords.y-2,  coords.z-7, 174, 0);
       World.setBlock(coords.x+13,coords.y-3,  coords.z-7, 174, 0);
       //
       World.setBlock(coords.x+13,coords.y+3,  coords.z-6, 174, 0);
       World.setBlock(coords.x+13,coords.y+2,  coords.z-6, 174, 0);
       World.setBlock(coords.x+13,coords.y+1,  coords.z-6, 174, 0);
       World.setBlock(coords.x+13,coords.y,  coords.z-6, 174, 0);
       World.setBlock(coords.x+13,coords.y-1,  coords.z-6, 174, 0);
       World.setBlock(coords.x+13,coords.y-2,  coords.z-6, 174, 0);
       World.setBlock(coords.x+13,coords.y-3,  coords.z-6, 174, 0);
       //
       World.setBlock(coords.x+13,coords.y+3,  coords.z-5, 174, 0);
       World.setBlock(coords.x+13,coords.y+2,  coords.z-5, 174, 0);
       World.setBlock(coords.x+13,coords.y+1,  coords.z-5, 174, 0);
       World.setBlock(coords.x+13,coords.y,  coords.z-5, 174, 0);
       World.setBlock(coords.x+13,coords.y-1,  coords.z-5, 174, 0);
       World.setBlock(coords.x+13,coords.y-2,  coords.z-5, 174, 0);
       World.setBlock(coords.x+13,coords.y-3,  coords.z-5, 174, 0);
       //
       World.setBlock(coords.x+13,coords.y+3,  coords.z-4, 174, 0);
       World.setBlock(coords.x+13,coords.y+2,  coords.z-4, 174, 0);
       World.setBlock(coords.x+13,coords.y+1,  coords.z-4, 174, 0);
       World.setBlock(coords.x+13,coords.y,  coords.z-4, 174, 0);
       World.setBlock(coords.x+13,coords.y-1,  coords.z-4, 174, 0);
       World.setBlock(coords.x+13,coords.y-2,  coords.z-4, 174, 0);
       World.setBlock(coords.x+13,coords.y-3,  coords.z-4, 174, 0);
       //
       World.setBlock(coords.x+13,coords.y+3,  coords.z-3, 174, 0);
       World.setBlock(coords.x+13,coords.y+2,  coords.z-3, 174, 0);
       World.setBlock(coords.x+13,coords.y+1,  coords.z-3, 174, 0);
       World.setBlock(coords.x+13,coords.y,  coords.z-3, 174, 0);
       World.setBlock(coords.x+13,coords.y-1,  coords.z-3, 174, 0);
       World.setBlock(coords.x+13,coords.y-2,  coords.z-3, 174, 0);
       World.setBlock(coords.x+13,coords.y-3,  coords.z-3, 174, 0);
       //
       World.setBlock(coords.x+13,coords.y+3,  coords.z-2, 174, 0);
       World.setBlock(coords.x+13,coords.y+2,  coords.z-2, 174, 0);
       World.setBlock(coords.x+13,coords.y+1,  coords.z-2, 174, 0);
       World.setBlock(coords.x+13,coords.y,  coords.z-2, 174, 0);
       World.setBlock(coords.x+13,coords.y-1,  coords.z-2, 174, 0);
       World.setBlock(coords.x+13,coords.y-2,  coords.z-2, 174, 0);
       World.setBlock(coords.x+13,coords.y-3,  coords.z-2, 174, 0);
       //
       World.setBlock(coords.x+13,coords.y+3,  coords.z-1, 174, 0);
       World.setBlock(coords.x+13,coords.y+2,  coords.z-1, 174, 0);
       World.setBlock(coords.x+13,coords.y+1,  coords.z-1, 174, 0);
       World.setBlock(coords.x+13,coords.y,  coords.z-1, 174, 0);
       World.setBlock(coords.x+13,coords.y-1,  coords.z-1, 174, 0);
       World.setBlock(coords.x+13,coords.y-2,  coords.z-1, 174, 0);
       World.setBlock(coords.x+13,coords.y-3,  coords.z-1, 174, 0);
       
       World.setBlock(coords.x+13,coords.y+3,  coords.z, 174, 0);
       World.setBlock(coords.x+13,coords.y+2,  coords.z, 174, 0);
       World.setBlock(coords.x+13,coords.y+1,  coords.z, 174, 0);
       World.setBlock(coords.x+13,coords.y,  coords.z, 174, 0);
       World.setBlock(coords.x+13,coords.y-1,  coords.z, 174, 0);
       World.setBlock(coords.x+13,coords.y-2,  coords.z, 174, 0);
       World.setBlock(coords.x+13,coords.y-3,  coords.z, 174, 0);
       //
       World.setBlock(coords.x+13,coords.y+3,  coords.z+1, 174, 0);
       World.setBlock(coords.x+13,coords.y+2,  coords.z+1, 174, 0);
       World.setBlock(coords.x+13,coords.y+1,  coords.z+1, 174, 0);
       World.setBlock(coords.x+13,coords.y,  coords.z+1, 174, 0);
       World.setBlock(coords.x+13,coords.y-1,  coords.z+1, 174, 0);
       World.setBlock(coords.x+13,coords.y-2,  coords.z+1, 174, 0);
       World.setBlock(coords.x+13,coords.y-3,  coords.z+1, 174, 0);
       World.setBlock(coords.x+13,coords.y+3,  coords.z+2, 174, 0);
       World.setBlock(coords.x+13,coords.y+2,  coords.z+2, 174, 0);
       World.setBlock(coords.x+13,coords.y+1,  coords.z+2, 174, 0);
       World.setBlock(coords.x+13,coords.y,  coords.z+2, 174, 0);
       World.setBlock(coords.x+13,coords.y-1,  coords.z+2, 174, 0);
       World.setBlock(coords.x+13,coords.y-2,  coords.z+2, 174, 0);
       World.setBlock(coords.x+13,coords.y-3,  coords.z+2, 174, 0);
       World.setBlock(coords.x+13,coords.y+3,  coords.z+3, 174, 0);
       World.setBlock(coords.x+13,coords.y+2,  coords.z+3, 174, 0);
       World.setBlock(coords.x+13,coords.y+1,  coords.z+3, 174, 0);
       World.setBlock(coords.x+13,coords.y,  coords.z+3, 174, 0);
       World.setBlock(coords.x+13,coords.y-1,  coords.z+3, 174, 0);
       World.setBlock(coords.x+13,coords.y-2,  coords.z+3, 174, 0);
       World.setBlock(coords.x+13,coords.y-3,  coords.z+3, 174, 0);
       World.setBlock(coords.x+13,coords.y+3,  coords.z+4, 174, 0);
       World.setBlock(coords.x+13,coords.y+2,  coords.z+4, 174, 0);
       World.setBlock(coords.x+13,coords.y+1,  coords.z+4, 174, 0);
       World.setBlock(coords.x+13,coords.y,  coords.z+4, 174, 0);
       World.setBlock(coords.x+13,coords.y-1,  coords.z+4, 174, 0);
       World.setBlock(coords.x+13,coords.y-2,  coords.z+4, 174, 0);
       World.setBlock(coords.x+13,coords.y-3,  coords.z+4, 174, 0);
       World.setBlock(coords.x+13,coords.y+3,  coords.z+5, 174, 0);
       World.setBlock(coords.x+13,coords.y+2,  coords.z+5, 174, 0);
       World.setBlock(coords.x+13,coords.y+1,  coords.z+5, 174, 0);
       World.setBlock(coords.x+13,coords.y,  coords.z+5, 174, 0);
       World.setBlock(coords.x+13,coords.y-1,  coords.z+5, 174, 0);
       World.setBlock(coords.x+13,coords.y-2,  coords.z+5, 174, 0);
       World.setBlock(coords.x+13,coords.y-3,  coords.z+5, 174, 0);
       World.setBlock(coords.x+13,coords.y+3,  coords.z+6, 174, 0);
       World.setBlock(coords.x+13,coords.y+2,  coords.z+6, 174, 0);
       World.setBlock(coords.x+13,coords.y+1,  coords.z+6, 174, 0);
       World.setBlock(coords.x+13,coords.y,  coords.z+6, 174, 0);
       World.setBlock(coords.x+13,coords.y-1,  coords.z+6, 174, 0);
       World.setBlock(coords.x+13,coords.y-2,  coords.z+6, 174, 0);
       World.setBlock(coords.x+13,coords.y-3,  coords.z+6, 174, 0);
       World.setBlock(coords.x+13,coords.y+3,  coords.z+7, 174, 0);
       World.setBlock(coords.x+13,coords.y+2,  coords.z+7, 174, 0);
       World.setBlock(coords.x+13,coords.y+1,  coords.z+7, 174, 0);
       World.setBlock(coords.x+13,coords.y,  coords.z+7, 174, 0);
       World.setBlock(coords.x+13,coords.y-1,  coords.z+7, 174, 0);
       World.setBlock(coords.x+13,coords.y-2,  coords.z+7, 174, 0);
       World.setBlock(coords.x+13,coords.y-3,  coords.z+7, 174, 0);
       World.setBlock(coords.x+13,coords.y+3,  coords.z+8, 174, 0);
       World.setBlock(coords.x+13,coords.y+2,  coords.z+8, 174, 0);
       World.setBlock(coords.x+13,coords.y+1,  coords.z+8, 174, 0);
       World.setBlock(coords.x+13,coords.y,  coords.z+8, 174, 0);
       World.setBlock(coords.x+13,coords.y-1,  coords.z+8, 174, 0);
       World.setBlock(coords.x+13,coords.y-2,  coords.z+8, 174, 0);
       World.setBlock(coords.x+13,coords.y-3,  coords.z+8, 174, 0);
       World.setBlock(coords.x+13,coords.y+3,  coords.z+9, 174, 0);
       World.setBlock(coords.x+13,coords.y+2,  coords.z+9, 174, 0);
       World.setBlock(coords.x+13,coords.y+1,  coords.z+9, 174, 0);
       World.setBlock(coords.x+13,coords.y,  coords.z+9, 174, 0);
       World.setBlock(coords.x+13,coords.y-1,  coords.z+9, 174, 0);
       World.setBlock(coords.x+13,coords.y-2,  coords.z+9, 174, 0);
       World.setBlock(coords.x+13,coords.y-3,  coords.z+9, 174, 0);
       World.setBlock(coords.x+13,coords.y+3,  coords.z+10, 174, 0);
       World.setBlock(coords.x+13,coords.y+2,  coords.z+10, 174, 0);
       World.setBlock(coords.x+13,coords.y+1,  coords.z+10, 174, 0);
       World.setBlock(coords.x+13,coords.y,  coords.z+10, 174, 0);
       World.setBlock(coords.x+13,coords.y-1,  coords.z+10, 174, 0);
       World.setBlock(coords.x+13,coords.y-2,  coords.z+10, 174, 0);
       World.setBlock(coords.x+13,coords.y-3,  coords.z+10, 174, 0);
       World.setBlock(coords.x+13,coords.y+3,  coords.z+11, 174, 0);
       World.setBlock(coords.x+13,coords.y+2,  coords.z+11, 174, 0);
       World.setBlock(coords.x+13,coords.y+1,  coords.z+11, 174, 0);
       World.setBlock(coords.x+13,coords.y,  coords.z+11, 174, 0);
       World.setBlock(coords.x+13,coords.y-1,  coords.z+11, 174, 0);
       World.setBlock(coords.x+13,coords.y-2,  coords.z+11, 174, 0);
       World.setBlock(coords.x+13,coords.y-3,  coords.z+11, 174, 0);
       World.setBlock(coords.x+13,coords.y+3,  coords.z+12, 174, 0);
       World.setBlock(coords.x+13,coords.y+2,  coords.z+12, 174, 0);
       World.setBlock(coords.x+13,coords.y+1,  coords.z+12, 174, 0);
       World.setBlock(coords.x+13,coords.y,  coords.z+12, 174, 0);
       World.setBlock(coords.x+13,coords.y-1,  coords.z+12, 174, 0);
       World.setBlock(coords.x+13,coords.y-2,  coords.z+12, 174, 0);
       World.setBlock(coords.x+13,coords.y-3,  coords.z+12, 174, 0);
       World.setBlock(coords.x+13,coords.y+3,  coords.z+13, 174, 0);
       World.setBlock(coords.x+13,coords.y+2,  coords.z+13, 174, 0);
       World.setBlock(coords.x+13,coords.y+1,  coords.z+13, 174, 0);
       World.setBlock(coords.x+13,coords.y,  coords.z+13, 174, 0);
       World.setBlock(coords.x+13,coords.y-1,  coords.z+13, 174, 0);
       World.setBlock(coords.x+13,coords.y-2,  coords.z+13, 174, 0);
       World.setBlock(coords.x+13,coords.y-3,  coords.z+13, 174, 0);
//
World.setBlock(coords.x-12,coords.y+3,  coords.z-13, 174, 0);
       World.setBlock(coords.x-12,coords.y+2,  coords.z-13, 174, 0);
       World.setBlock(coords.x-12,coords.y+1,  coords.z-13, 174, 0);
       World.setBlock(coords.x-12,coords.y,  coords.z-13, 174, 0);
       World.setBlock(coords.x-12,coords.y-1,  coords.z-13, 174, 0);
       World.setBlock(coords.x-12,coords.y-2,  coords.z-13, 174, 0);
       World.setBlock(coords.x-12,coords.y-3,  coords.z-13, 174, 0);
      World.setBlock(coords.x-11,coords.y+3,  coords.z-13, 174, 0);
       World.setBlock(coords.x-11,coords.y+2,  coords.z-13, 174, 0);
       World.setBlock(coords.x-11,coords.y+1,  coords.z-13, 174, 0);
       World.setBlock(coords.x-11,coords.y,  coords.z-13, 174, 0);
       World.setBlock(coords.x-11,coords.y-1,  coords.z-13, 174, 0);
       World.setBlock(coords.x-11,coords.y-2,  coords.z-13, 174, 0);
       World.setBlock(coords.x-11,coords.y-3,  coords.z-13, 174, 0);
      World.setBlock(coords.x-10,coords.y+3,  coords.z-13, 174, 0);
       World.setBlock(coords.x-10,coords.y+2,  coords.z-13, 174, 0);
       World.setBlock(coords.x-10,coords.y+1,  coords.z-13, 174, 0);
       World.setBlock(coords.x-10,coords.y,  coords.z-13, 174, 0);
       World.setBlock(coords.x-10,coords.y-1,  coords.z-13, 174, 0);
       World.setBlock(coords.x-10,coords.y-2,  coords.z-13, 174, 0);
       World.setBlock(coords.x-10,coords.y-3,  coords.z-13, 174, 0);
      World.setBlock(coords.x-9,coords.y+3,  coords.z-13, 174, 0);
       World.setBlock(coords.x-9,coords.y+2,  coords.z-13, 174, 0);
       World.setBlock(coords.x-9,coords.y+1,  coords.z-13, 174, 0);
       World.setBlock(coords.x-9,coords.y,  coords.z-13, 174, 0);
       World.setBlock(coords.x-9,coords.y-1,  coords.z-13, 174, 0);
       World.setBlock(coords.x-9,coords.y-2,  coords.z-13, 174, 0);
       World.setBlock(coords.x-9,coords.y-3,  coords.z-13, 174, 0);
      World.setBlock(coords.x-8,coords.y+3,  coords.z-13, 174, 0);
       World.setBlock(coords.x-8,coords.y+2,  coords.z-13, 174, 0);
       World.setBlock(coords.x-8,coords.y+1,  coords.z-13, 174, 0);
       World.setBlock(coords.x-8,coords.y,  coords.z-13, 174, 0);
       World.setBlock(coords.x-8,coords.y-1,  coords.z-13, 174, 0);
       World.setBlock(coords.x-8,coords.y-2,  coords.z-13, 174, 0);
       World.setBlock(coords.x-8,coords.y-3,  coords.z-13, 174, 0);
      World.setBlock(coords.x-7,coords.y+3,  coords.z-13, 174, 0);
       World.setBlock(coords.x-7,coords.y+2,  coords.z-13, 174, 0);
       World.setBlock(coords.x-7,coords.y+1,  coords.z-13, 174, 0);
       World.setBlock(coords.x-7,coords.y,  coords.z-13, 174, 0);
       World.setBlock(coords.x-7,coords.y-1,  coords.z-13, 174, 0);
       World.setBlock(coords.x-7,coords.y-2,  coords.z-13, 174, 0);
       World.setBlock(coords.x-7,coords.y-3,  coords.z-13, 174, 0);
      World.setBlock(coords.x-6,coords.y+3,  coords.z-13, 174, 0);
       World.setBlock(coords.x-6,coords.y+2,  coords.z-13, 174, 0);
       World.setBlock(coords.x-6,coords.y+1,  coords.z-13, 174, 0);
       World.setBlock(coords.x-6,coords.y,  coords.z-13, 174, 0);
       World.setBlock(coords.x-6,coords.y-1,  coords.z-13, 174, 0);
       World.setBlock(coords.x-6,coords.y-2,  coords.z-13, 174, 0);
       World.setBlock(coords.x-6,coords.y-3,  coords.z-13, 174, 0);
      World.setBlock(coords.x-5,coords.y+3,  coords.z-13, 174, 0);
       World.setBlock(coords.x-5,coords.y+2,  coords.z-13, 174, 0);
       World.setBlock(coords.x-5,coords.y+1,  coords.z-13, 174, 0);
       World.setBlock(coords.x-5,coords.y,  coords.z-13, 174, 0);
       World.setBlock(coords.x-5,coords.y-1,  coords.z-13, 174, 0);
       World.setBlock(coords.x-5,coords.y-2,  coords.z-13, 174, 0);
       World.setBlock(coords.x-5,coords.y-3,  coords.z-13, 174, 0);
      World.setBlock(coords.x-4,coords.y+3,  coords.z-13, 174, 0);
       World.setBlock(coords.x-4,coords.y+2,  coords.z-13, 174, 0);
       World.setBlock(coords.x-4,coords.y+1,  coords.z-13, 174, 0);
       World.setBlock(coords.x-4,coords.y,  coords.z-13, 174, 0);
       World.setBlock(coords.x-4,coords.y-1,  coords.z-13, 174, 0);
       World.setBlock(coords.x-4,coords.y-2,  coords.z-13, 174, 0);
       World.setBlock(coords.x-4,coords.y-3,  coords.z-13, 174, 0);
      World.setBlock(coords.x-3,coords.y+3,  coords.z-13, 174, 0);
       World.setBlock(coords.x-3,coords.y+2,  coords.z-13, 174, 0);
       World.setBlock(coords.x-3,coords.y+1,  coords.z-13, 174, 0);
       World.setBlock(coords.x-3,coords.y,  coords.z-13, 174, 0);
       World.setBlock(coords.x-3,coords.y-1,  coords.z-13, 174, 0);
       World.setBlock(coords.x-3,coords.y-2,  coords.z-13, 174, 0);
       World.setBlock(coords.x-3,coords.y-3,  coords.z-13, 174, 0);
      World.setBlock(coords.x-2,coords.y+3,  coords.z-13, 174, 0);
       World.setBlock(coords.x-2,coords.y+2,  coords.z-13, 174, 0);
       World.setBlock(coords.x-2,coords.y+1,  coords.z-13, 174, 0);
       World.setBlock(coords.x-2,coords.y,  coords.z-13, 174, 0);
       World.setBlock(coords.x-2,coords.y-1,  coords.z-13, 174, 0);
       World.setBlock(coords.x-2,coords.y-2,  coords.z-13, 174, 0);
       World.setBlock(coords.x-2,coords.y-3,  coords.z-13, 174, 0);
      World.setBlock(coords.x-1,coords.y+3,  coords.z-13, 174, 0);
       World.setBlock(coords.x-1,coords.y+2,  coords.z-13, 174, 0);
       World.setBlock(coords.x-1,coords.y+1,  coords.z-13, 174, 0);
       World.setBlock(coords.x-1,coords.y,  coords.z-13, 174, 0);
       World.setBlock(coords.x-1,coords.y-1,  coords.z-13, 174, 0);
       World.setBlock(coords.x-1,coords.y-2,  coords.z-13, 174, 0);
       World.setBlock(coords.x-1,coords.y-3,  coords.z-13, 174, 0);
      World.setBlock(coords.x,coords.y+3,  coords.z-13, 174, 0);
       World.setBlock(coords.x,coords.y+2,  coords.z-13, 174, 0);
       World.setBlock(coords.x,coords.y+1,  coords.z-13, 174, 0);
       World.setBlock(coords.x,coords.y,  coords.z-13, 174, 0);
       World.setBlock(coords.x,coords.y-1,  coords.z-13, 174, 0);
       World.setBlock(coords.x,coords.y-2,  coords.z-13, 174, 0);
       World.setBlock(coords.x,coords.y-3,  coords.z-13, 174, 0);
      World.setBlock(coords.x+1,coords.y+3,  coords.z-13, 174, 0);
       World.setBlock(coords.x+1,coords.y+2,  coords.z-13, 174, 0);
       World.setBlock(coords.x+1,coords.y+1,  coords.z-13, 174, 0);
       World.setBlock(coords.x+1,coords.y,  coords.z-13, 174, 0);
       World.setBlock(coords.x+1,coords.y-1,  coords.z-13, 174, 0);
       World.setBlock(coords.x+1,coords.y-2,  coords.z-13, 174, 0);
       World.setBlock(coords.x+1,coords.y-3,  coords.z-13, 174, 0);
      World.setBlock(coords.x+2,coords.y+3,  coords.z-13, 174, 0);
       World.setBlock(coords.x+2,coords.y+2,  coords.z-13, 174, 0);
       World.setBlock(coords.x+2,coords.y+1,  coords.z-13, 174, 0);
       World.setBlock(coords.x+2,coords.y,  coords.z-13, 174, 0);
       World.setBlock(coords.x+2,coords.y-1,  coords.z-13, 174, 0);
       World.setBlock(coords.x+2,coords.y-2,  coords.z-13, 174, 0);
       World.setBlock(coords.x+2,coords.y-3,  coords.z-13, 174, 0);
      World.setBlock(coords.x+3,coords.y+3,  coords.z-13, 174, 0);
       World.setBlock(coords.x+3,coords.y+2,  coords.z-13, 174, 0);
       World.setBlock(coords.x+3,coords.y+1,  coords.z-13, 174, 0);
       World.setBlock(coords.x+3,coords.y,  coords.z-13, 174, 0);
       World.setBlock(coords.x+3,coords.y-1,  coords.z-13, 174, 0);
       World.setBlock(coords.x+3,coords.y-2,  coords.z-13, 174, 0);
       World.setBlock(coords.x+3,coords.y-3,  coords.z-13, 174, 0);
      World.setBlock(coords.x+4,coords.y+3,  coords.z-13, 174, 0);
       World.setBlock(coords.x+4,coords.y+2,  coords.z-13, 174, 0);
       World.setBlock(coords.x+4,coords.y+1,  coords.z-13, 174, 0);
       World.setBlock(coords.x+4,coords.y,  coords.z-13, 174, 0);
       World.setBlock(coords.x+4,coords.y-1,  coords.z-13, 174, 0);
       World.setBlock(coords.x+4,coords.y-2,  coords.z-13, 174, 0);
       World.setBlock(coords.x+4,coords.y-3,  coords.z-13, 174, 0);
      World.setBlock(coords.x+5,coords.y+3,  coords.z-13, 174, 0);
       World.setBlock(coords.x+5,coords.y+2,  coords.z-13, 174, 0);
       World.setBlock(coords.x+5,coords.y+1,  coords.z-13, 174, 0);
       World.setBlock(coords.x+5,coords.y,  coords.z-13, 174, 0);
       World.setBlock(coords.x+5,coords.y-1,  coords.z-13, 174, 0);
       World.setBlock(coords.x+5,coords.y-2,  coords.z-13, 174, 0);
       World.setBlock(coords.x+5,coords.y-3,  coords.z-13, 174, 0);
      World.setBlock(coords.x+6,coords.y+3,  coords.z-13, 174, 0);
       World.setBlock(coords.x+6,coords.y+2,  coords.z-13, 174, 0);
       World.setBlock(coords.x+6,coords.y+1,  coords.z-13, 174, 0);
       World.setBlock(coords.x+6,coords.y,  coords.z-13, 174, 0);
       World.setBlock(coords.x+6,coords.y-1,  coords.z-13, 174, 0);
       World.setBlock(coords.x+6,coords.y-2,  coords.z-13, 174, 0);
       World.setBlock(coords.x+6,coords.y-3,  coords.z-13, 174, 0);
      World.setBlock(coords.x+7,coords.y+3,  coords.z-13, 174, 0);
       World.setBlock(coords.x+7,coords.y+2,  coords.z-13, 174, 0);
       World.setBlock(coords.x+7,coords.y+1,  coords.z-13, 174, 0);
       World.setBlock(coords.x+7,coords.y,  coords.z-13, 174, 0);
       World.setBlock(coords.x+7,coords.y-1,  coords.z-13, 174, 0);
       World.setBlock(coords.x+7,coords.y-2,  coords.z-13, 174, 0);
       World.setBlock(coords.x+7,coords.y-3,  coords.z-13, 174, 0);
      World.setBlock(coords.x+8,coords.y+3,  coords.z-13, 174, 0);
       World.setBlock(coords.x+8,coords.y+2,  coords.z-13, 174, 0);
       World.setBlock(coords.x+8,coords.y+1,  coords.z-13, 174, 0);
       World.setBlock(coords.x+8,coords.y,  coords.z-13, 174, 0);
       World.setBlock(coords.x+8,coords.y-1,  coords.z-13, 174, 0);
       World.setBlock(coords.x+8,coords.y-2,  coords.z-13, 174, 0);
       World.setBlock(coords.x+8,coords.y-3,  coords.z-13, 174, 0);
      World.setBlock(coords.x+9,coords.y+3,  coords.z-13, 174, 0);
       World.setBlock(coords.x+9,coords.y+2,  coords.z-13, 174, 0);
       World.setBlock(coords.x+9,coords.y+1,  coords.z-13, 174, 0);
       World.setBlock(coords.x+9,coords.y,  coords.z-13, 174, 0);
       World.setBlock(coords.x+9,coords.y-1,  coords.z-13, 174, 0);
       World.setBlock(coords.x+9,coords.y-2,  coords.z-13, 174, 0);
       World.setBlock(coords.x+9,coords.y-3,  coords.z-13, 174, 0);
       World.setBlock(coords.x+10,coords.y+3,  coords.z-13, 174, 0);
       World.setBlock(coords.x+10,coords.y+2,  coords.z-13, 174, 0);
       World.setBlock(coords.x+10,coords.y+1,  coords.z-13, 174, 0);
       World.setBlock(coords.x+10,coords.y,  coords.z-13, 174, 0);
       World.setBlock(coords.x+10,coords.y-1,  coords.z-13, 174, 0);
       World.setBlock(coords.x+10,coords.y-2,  coords.z-13, 174, 0);
       World.setBlock(coords.x+10,coords.y-3,  coords.z-13, 174, 0);
       World.setBlock(coords.x+11,coords.y+3,  coords.z-13, 174, 0);
       World.setBlock(coords.x+11,coords.y+2,  coords.z-13, 174, 0);
       World.setBlock(coords.x+11,coords.y+1,  coords.z-13, 174, 0);
       World.setBlock(coords.x+11,coords.y,  coords.z-13, 174, 0);
       World.setBlock(coords.x+11,coords.y-1,  coords.z-13, 174, 0);
       World.setBlock(coords.x+11,coords.y-2,  coords.z-13, 174, 0);
       World.setBlock(coords.x+11,coords.y-3,  coords.z-13, 174, 0);
       World.setBlock(coords.x+12,coords.y+3,  coords.z-13, 174, 0);
       World.setBlock(coords.x+12,coords.y+2,  coords.z-13, 174, 0);
       World.setBlock(coords.x+12,coords.y+1,  coords.z-13, 174, 0);
       World.setBlock(coords.x+12,coords.y,  coords.z-13, 174, 0);
       World.setBlock(coords.x+12,coords.y-1,  coords.z-13, 174, 0);
       World.setBlock(coords.x+12,coords.y-2,  coords.z-13, 174, 0);
       World.setBlock(coords.x+12,coords.y-3,  coords.z-13, 174, 0);
       World.setBlock(coords.x+13,coords.y+3,  coords.z-13, 174, 0);
       World.setBlock(coords.x+13,coords.y+2,  coords.z-13, 174, 0);
       World.setBlock(coords.x+13,coords.y+1,  coords.z-13, 174, 0);
       World.setBlock(coords.x+13,coords.y,  coords.z-13, 174, 0);
       World.setBlock(coords.x+13,coords.y-1,  coords.z-13, 174, 0);
       World.setBlock(coords.x+13,coords.y-2,  coords.z-13, 174, 0);
       World.setBlock(coords.x+13,coords.y-3,  coords.z-13, 174, 0);
       




  Player.decreaseCarriedItem(1)
  Particles.addParticle(Native.ParticleType.hugeexplosion, coords.x + 0.5, coords.y + 0.5, coords.z + 0.5, 0, 0.1, 0, 0);
  World.playSound(coords.x, coords.y, coords.z, "random.explode", 3)
  World.destroyBlock(coords.x, coords.y, coords.z, 1)
  
}
});




// file: Hexxit Core/Dimensions/THE TWILIGHT FOREST/Mob/minoshroom.js





// file: Hexxit Core/Dimensions/THE TWILIGHT FOREST/Mob/ughast.js





// file: Hexxit Core/Recipe Mod/Recipe Wooden Giant Sword.js

Recipes.addShaped({id: ItemID.wooden_giant_sword, count: 1, data: 0}, [
		"oqq",
		"qqq",
		"mqa"
	], ['o', ItemID.page, 0,'m', 280, 0,'q', 5, 1]);

Recipes.addShaped({id: ItemID.wooden_giant_sword, count: 1, data: 0}, [
		"oqq",
		"qqq",
		"mqa"
	], ['o', ItemID.page, 0,'m', 280, 0,'q', 5, 2]);
	
	 Recipes.addShaped({id: ItemID.wooden_giant_sword, count: 1, data: 0}, [
		"oqq",
		"qqq",
		"mqa"
	], ['o', ItemID.page, 0,'m', 280, 0,'q', 5, 3]);
	
	 Recipes.addShaped({id: ItemID.wooden_giant_sword, count: 1, data: 0}, [
		"oqq",
		"qqq",
		"mqa"
	], ['o', ItemID.page, 0,'m', 280, 0,'q', 5, 4]);
	
	 Recipes.addShaped({id: ItemID.wooden_giant_sword, count: 1, data: 0}, [
		"oqq",
		"qqq",
		"mqa"
	], ['o', ItemID.page, 0,'m', 280, 0,'q', 5, 5]);


//stm




// file: Hexxit Core/Recipe Mod/Recipe Stick.js

Recipes.addShaped({id: 280, count: 4, data: 0}, [
		"axx",
		"axx",
		"xxx"
	], ['a', BlockID.tw_planks_sort, 0]);
	//
	 Recipes.addShaped({id: 280, count: 4, data: 0}, [
		"axx",
		"axx",
		"xxx"
	], ['a', BlockID.tw_planks_time, 0]);
	//
	 Recipes.addShaped({id: 280, count: 4, data: 0}, [
		 "axx",
		"axx",
		"xxx"
	], ['a', BlockID.tw_planks_trans, 0]);
	 Recipes.addShaped({id: 280, count: 4, data: 0}, [
		 "axx",
		"axx",
		"xxx"
	], ['a', BlockID.tw_planks_dark_wood, 0]);
	// 
       Recipes.addShaped({id: 280, count: 4, data: 0}, [
		 "axx",
		"axx",
		"xxx"
	], ['a', BlockID.tw_planks_mangrove, 0]);
	// 
     Recipes.addShaped({id: 280, count: 4, data: 0}, [
		 "axx",
		"axx",
		"xxx"
	], ['a', BlockID.tw_planks_canopy, 0]);
	// 
      Recipes.addShaped({id: 280, count: 4, data: 0}, [
		 "axx",
		"axx",
		"xxx"
	], ['a', BlockID.tw_planks_twilight_oak, 0]);
	// 
     Recipes.addShaped({id: 280, count: 4, data: 0}, [
		 "axx",
		"axx",
		"xxx"
	], ['a', BlockID.tw_planks_mine, 0]);
	//
	 Recipes.addShaped({id: ItemID.fint, count: 4, data: 0}, [
		 "ab",
		"ccc",
		"xxx"
	], ['a', ItemID.fieryblood, 0,'b', 265, 0]);




// file: Vanlila Minecraft Recipe/block mod.js

VanillaRecipe.addCraftingRecipe("infinity_ingot", {
        type: "shapeless",
        ingredients: [
            { item: "block:infBlock" }
        ],
        result: {
            item: "item:infinityingot",
            count: 9
        }
    }, true);




// file: Vanlila Minecraft Recipe/log and plank.js

VanillaRecipe.addCraftingRecipe("plank_dark", {
        type: "shapeless",
        ingredients: [
            { item: "block:twDarkLog" }
        ],
        result: {
            item: "block:tw_planks_dark_wood",
            count: 4
        }
    }, true);
    //
    VanillaRecipe.addCraftingRecipe("plank_mangrove", {
        type: "shapeless",
        ingredients: [
            { item: "block:twMangroveLog" }
        ],
        result: {
            item: "block:tw_planks_mangrove",
            count: 4
        }
    }, true);
    //
    VanillaRecipe.addCraftingRecipe("plank_canopy", {
        type: "shapeless",
        ingredients: [
            { item: "block:twCanopyLog" }
        ],
        result: {
            item: "block:tw_planks_canopy",
            count: 4
        }
    }, true);
    //
    VanillaRecipe.addCraftingRecipe("plank_oak", {
        type: "shapeless",
        ingredients: [
            { item: "block:twTwilightOakLog" }
        ],
        result: {
            item: "block:tw_planks_twilight_oak",
            count: 4
        }
    }, true);
    //
    VanillaRecipe.addCraftingRecipe("plank_mine", {
        type: "shapeless",
        ingredients: [
            { item: "block:twMiningLog" }
        ],
        result: {
            item: "block:tw_planks_mine",
            count: 4
        }
    }, true);
    //
    VanillaRecipe.addCraftingRecipe("plank_sort", {
        type: "shapeless",
        ingredients: [
            { item: "block:twSortingLog" }
        ],
        result: {
            item: "block:tw_planks_sort",
            count: 4
        }
    }, true);
    //
    VanillaRecipe.addCraftingRecipe("plank_time", {
        type: "shapeless",
        ingredients: [
            { item: "block:twTimeLog" }
        ],
        result: {
            item: "block:tw_planks_time",
            count: 4
        }
    }, true);
    //
    VanillaRecipe.addCraftingRecipe("plank_trans", {
        type: "shapeless",
        ingredients: [
            { item: "block:twTransformationLog" }
        ],
        result: {
            item: "block:tw_planks_trans",
            count: 4
        }
    }, true);
    //
    //
    //
    




// file: Vanlila Minecraft Recipe/infinity tools.js

VanillaRecipe.addCraftingRecipe("inf_1", {
        type: "shapeless",
        ingredients: [
            { item: "item:cosmPickaxe" }
        ],
        result: {
            item: "item:cosmhammer",
            count: 1
        }
    }, true);
    
    VanillaRecipe.addCraftingRecipe("inf_2", {
        type: "shapeless",
        ingredients: [
            { item: "item:cosmhammer" }
        ],
        result: {
            item: "item:cosmPickaxe",
            count: 1
        }
    }, true);
   
   VanillaRecipe.addCraftingRecipe("inf_3", {
        type: "shapeless",
        ingredients: [
            { item: "item:cosmPickaxe" }
        ],
        result: {
            item: "item:cosmdes",
            count: 1
        }
    }, true);
    VanillaRecipe.addCraftingRecipe("inf_4", {
        type: "shapeless",
        ingredients: [
            { item: "item:cosmdes" }
        ],
        result: {
            item: "item:cosmPickaxe",
            count: 1
        }
    }, true);
    
    VanillaRecipe.addCraftingRecipe("inf_5", {
        type: "shapeless",
        ingredients: [
            { item: "item:cosmdes" }
        ],
        result: {
            item: "item:cosmhammer",
            count: 1
        }
    }, true);
    
    VanillaRecipe.addCraftingRecipe("inf_6", {
        type: "shapeless",
        ingredients: [
            { item: "item:cosmhammer" }
        ],
        result: {
            item: "item:cosmdes",
            count: 1
        }
    }, true);
    
    




// file: Hexxit Core/Tools Mode Skill Lv/Ice Skill/Tools Legend Ice.js

IDRegistry.genItemID( "wooden_giant_sword_ice_legend" );
Item.createItem("wooden_giant_sword_ice_legend", "§6Wooden Giant Sword \n Rarity: Craftable \n Lv: Legend \n Skill: Ice Legend \n Damage: +8", {
         name: "wooden_sword_giant", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("oak planks", {durability: 340, level: 1, efficiency: 4, damage: 8, enchantability: 30});
ToolAPI.setTool(ItemID.wooden_giant_sword_ice_legend, "oak planks", ToolType.sword);





IDRegistry.genItemID( "cobblestone_giant_sword_ice_legend" );
Item.createItem("cobblestone_giant_sword_ice_legend", "§6Stone Giant Sword \n Rarity: Craftable \n Lv: Legend \n Skill: Ice Legend \n Damage: +9", {
    name: "stone_sword_giant", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("stone", {durability: 700, level: 2, efficiency: 4, damage: 9, enchantability: 30});
ToolAPI.setTool(ItemID.cobblestone_giant_sword_ice_legend, "stone", ToolType.sword);


	


IDRegistry.genItemID( "iron_giant_sword_ice_legend" );
Item.createItem("iron_giant_sword_ice_legend", "§6Iron Giant Sword  \n Rarity: Craftable \n Lv: Legend \n Skill: Ice Legend \n Damage: +10", {
name: "iron_sword_giant", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("iron ingot", {durability: 970, level: 3, efficiency: 4, damage: 10, enchantability: 30});
ToolAPI.setTool(ItemID.iron_giant_sword_ice_legend, "iron ingot", ToolType.sword);




IDRegistry.genItemID( "gold_giant_sword_ice_legend" );
Item.createItem("gold_giant_sword_ice_legend", "§6Gold Giant Sword \n Rarity: Craftable \n Lv: Legend \n Skill: Ice Legend \n Damage: +8", {
name: "gold_sword_giant", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("gold ingot", {durability: 340, level: 3, efficiency: 4, damage: 8, enchantability: 30});
ToolAPI.setTool(ItemID.gold_giant_sword_ice_legend, "gold ingot", ToolType.sword);


	


IDRegistry.genItemID( "diamond_giant_sword_ice_legend" );
Item.createItem("diamond_giant_sword_ice_legend", "§6Diamond Giant Sword \n Rarity: Craftable \n Lv: Legend \n Skill: Ice Legend \n Damage: +14", {
      name: "diamond_sword_giant", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("diamond", {durability: 2500, level: 4, efficiency: 4, damage: 14, enchantability: 30});
ToolAPI.setTool(ItemID.diamond_giant_sword_ice_legend, "diamond", ToolType.sword);




IDRegistry.genItemID( "emerald_giant_sword_ice_legend" );
Item.createItem("emerald_giant_sword_ice_legend", "§6Emeral Giant Sword \n Rarity: Craftable \n Lv: Legend \n Skill: Ice Legend \n Damage: +17", {
    name: "emerald_sword_giant", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("emerald", {durability: 2600, level: 4, efficiency: 4, damage: 17, enchantability: 30});
ToolAPI.setTool(ItemID.emerald_giant_sword_ice_legend, "emerald", ToolType.sword);


	


IDRegistry.genItemID( "ender_giant_sword_ice_legend" );
Item.createItem("ender_giant_sword_ice_legend", "§6Ender Giant Sword \n Rarity: Craftable \n Lv: Legend \n Skill: Ice Legend \n Damage: +20", {
    name: "ender_sword_giant", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("diamond", {durability: 2800, level: 4, efficiency: 4, damage: 20, enchantability: 30});
ToolAPI.setTool(ItemID.ender_giant_sword_ice_legend, "diamond", ToolType.sword);





IDRegistry.genItemID( "livingmetal_giant_sword_ice_legend" );
Item.createItem("livingmetal_giant_sword_ice_legend", " §6Living Metal Giant Sword \n Rarity: Craftable \n Lv: Legend \n Skill: Ice Legend \n Damage: +23", {
     name: "livingmetal_sword_giant", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("livingmetal", {durability: 3200, level: 4, efficiency: 4, damage: 23, enchantability: 30});
ToolAPI.setTool(ItemID.livingmetal_giant_sword_ice_legend, "livingmetal", ToolType.sword);




	
	
	
	
	IDRegistry.genItemID( "quartz_giant_sword_ice_legend" );
Item.createItem("quartz_giant_sword_ice_legend", "§6Quartz Giant Sword \n Rarity: Craftable \n Lv: Legend \nSkill: Ice Legend \n Damage: +9", {
     name: "quartz_giant_sword", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("bone", {durability: 500, level: 4, efficiency: 4, damage: 9, enchantability: 30});
ToolAPI.setTool(ItemID.quartz_giant_sword_ice_legend, "bone", ToolType.sword);
	
	
	
	
	
	
	
	IDRegistry.genItemID( "netherrack_giant_sword_ice_legend" );
Item.createItem("netherrack_giant_sword_ice_legend", "§6Netherrack Giant Sword \n Rarity: Craftable \n Lv: Legend \n Skill: Ice Legend \n Damage: +9", {
     name: "netherrack_giant_sword", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("bone", {durability: 700, level: 4, efficiency: 4, damage: 9, enchantability: 30});
ToolAPI.setTool(ItemID.netherrack_giant_sword_ice_legend, "bone", ToolType.sword);
	
	
	
	
	
	
	IDRegistry.genItemID( "bone_giant_sword_ice_legend" );
Item.createItem("bone_giant_sword_ice_legend", "§6Bone Giant Sword \n Rarity: Craftable \n Lv: Legend \n Skill: Ice Legend \n Damage: +16", {
    name: "bone_giant_sword", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("bone", {durability: 790, level: 4, efficiency: 4, damage: 16, enchantability: 30});
ToolAPI.setTool(ItemID.bone_giant_sword_ice_legend, "bone", ToolType.sword);
	
	
	
	
	

	IDRegistry.genItemID( "obsidian_giant_sword_ice_legend" );
Item.createItem("obsidian_giant_sword_ice_legend", "§6Obsidian Giant Sword \n Rarity: Craftable \n Lv: Legend \n Skill: Ice Legend \n Damage: +18", {
     name: "obsidian_giant_sword", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("bone", {durability: 2000, level: 4, efficiency: 4, damage: 18, enchantability: 30});
ToolAPI.setTool(ItemID.obsidian_giant_sword_ice_legend, "bone", ToolType.sword);


	
	
IDRegistry.genItemID( "netherite_giant_sword_ice_legend" );
Item.createItem("netherite_giant_sword_ice_legend", "§6Netherite Giant Sword \n Rarity: Craftable \n Lv: Legend \n Skill: Ice Legend \n Damage: +21", {
     name: "netherite_giant_sword", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("bone", {durability: 2000, level: 4, efficiency: 4, damage: 21, enchantability: 30});
ToolAPI.setTool(ItemID.netherite_giant_sword_ice_legend, "bone", ToolType.sword);

IDRegistry.genItemID( "wither_giant_sword_ice_legend" );
Item.createItem("wither_giant_sword_ice_legend", "§6Wither Giant Sword \n Rarity: Craftable \n Lv: Legend \n Skill: Ice Legend \n Damage: +46", {
     name: "wither_giant_sword", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("bone", {durability: 790, level: 4, efficiency: 4, damage: 46, enchantability: 30});
ToolAPI.setTool(ItemID.wither_giant_sword_ice_legend, "bone", ToolType.sword);
	
	
	
	
	
	
	
	
	
	
	IDRegistry.genItemID( "dragon_giant_sword_ice_legend" );
Item.createItem("dragon_giant_sword_ice_legend", "§6Dragon Giant Sword \n Rarity: Craftable \n Lv: Legend \n Skill: Ice Legend \n Damage: +73", {
    name: "dragon_giant_sword", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("bone", {durability: 3000, level: 4, efficiency: 4, damage: 73, enchantability: 30});
ToolAPI.setTool(ItemID.dragon_giant_sword_ice_legend, "bone", ToolType.sword);
	
	 // giấy bạc
	
	
	 Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.wooden_giant_sword_ice_legend){ 
Entity.addEffect(victim, Native.PotionEffect.movementSlowdown, 20, 20, true, true); 
}
});




Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.cobblestone_giant_sword_ice_legend){ 
Entity.addEffect(victim, Native.PotionEffect.movementSlowdown, 20, 20, true, true); 
}
});
	
	
	
	
	Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.iron_giant_sword_ice_legend){ 
Entity.addEffect(victim, Native.PotionEffect.movementSlowdown, 20, 20, true, true); 
}
});
	
	
	 Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.gold_giant_sword_ice_legend){ 
Entity.addEffect(victim, Native.PotionEffect.movementSlowdown, 20, 20, true, true); 
}
});
	
	
	
	 Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.diamond_giant_sword_ice_legend){ 
Entity.addEffect(victim, Native.PotionEffect.movementSlowdown, 20, 20, true, true); 
}
});
	
	
	
	 Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.emerald_giant_sword_ice_legend){ 
Entity.addEffect(victim, Native.PotionEffect.movementSlowdown, 20, 20, true, true); 
}
});
	
	
	
	 Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.ender_giant_sword_ice_legend){ 
Entity.addEffect(victim, Native.PotionEffect.movementSlowdown, 20, 20, true, true); 
}
});
	
	
	
	 Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.livingmetal_giant_sword_ice_legend){ 
Entity.addEffect(victim, Native.PotionEffect.movementSlowdown, 20, 20, true, true); 
}
});
	
	
	
	 Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.quartz_giant_sword_ice_legend){ 
Entity.addEffect(victim, Native.PotionEffect.movementSlowdown, 20, 20, true, true); 
}
});
	
	
	
	 Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.netherrack_giant_sword_ice_legend){ 
Entity.addEffect(victim, Native.PotionEffect.movementSlowdown, 20, 20, true, true); 
}
});
	
	
	
	 Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.bone_giant_sword_ice_legend){ 
Entity.addEffect(victim, Native.PotionEffect.movementSlowdown, 20, 20, true, true); 
}
});
	
	
	
	 Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.obsidian_giant_sword_ice_legend){ 
Entity.addEffect(victim, Native.PotionEffect.movementSlowdown, 20, 20, true, true); 
}
});
	

	 Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.netherite_giant_sword_ice_legend){ 
Entity.addEffect(victim, Native.PotionEffect.movementSlowdown, 20, 20, true, true); 
}
});
	
	
	
	 Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.wither_giant_sword_ice_legend){ 
Entity.addEffect(victim, Native.PotionEffect.movementSlowdown, 20, 20, true, true); 
}
});
	
	
	
	 Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.dragon_giant_sword_ice_legend){ 
Entity.addEffect(victim, Native.PotionEffect.movementSlowdown, 20, 20, true, true); 
}
});
	
	
	
	
	
	
	
	




// file: Hexxit Core/Tools Mode Skill Lv/Ice Skill/Tools Untimed Ice.js

IDRegistry.genItemID( "wooden_giant_sword_ice_untimed" );
Item.createItem("wooden_giant_sword_ice_untimed", "§dWooden Giant Sword \n Rarity: Craftable \n Lv: Untimed \n Skill: Ice Untimed \n Damage: +10", {
         name: "wooden_sword_giant", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("oak planks", {durability: 340, level: 1, efficiency: 4, damage: 10, enchantability: 30});
ToolAPI.setTool(ItemID.wooden_giant_sword_ice_untimed, "oak planks", ToolType.sword);





IDRegistry.genItemID( "stone_giant_sword_ice_untimed" );
Item.createItem("stone_giant_sword_ice_untimed", "§dStone Giant Sword \n Rarity: Craftable \n Lv: Untimed \n Skill: Ice Untimed \n Damage: +11", {
    name: "stone_sword_giant", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("stone", {durability: 700, level: 2, efficiency: 4, damage: 11, enchantability: 30});
ToolAPI.setTool(ItemID.stone_giant_sword_ice_untimed, "stone", ToolType.sword);


	


IDRegistry.genItemID( "iron_giant_sword_ice_untimed" );
Item.createItem("iron_giant_sword_ice_untimed", "§dIron Giant Sword  \n Rarity: Craftable \n Lv: Untimed \n Skill: Ice Untimed \n Damage: +12", {
name: "iron_sword_giant", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("iron ingot", {durability: 970, level: 3, efficiency: 4, damage: 12, enchantability: 30});
ToolAPI.setTool(ItemID.iron_giant_sword_ice_untimed, "iron ingot", ToolType.sword);




IDRegistry.genItemID( "gold_giant_sword_ice_untimed" );
Item.createItem("gold_giant_sword_ice_untimed", "§dGold Giant Sword \n Rarity: Craftable \n Lv: Untimed \n Skill: Ice Untimed \n Damage: +10", {
name: "gold_sword_giant", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("gold ingot", {durability: 340, level: 3, efficiency: 4, damage: 10, enchantability: 30});
ToolAPI.setTool(ItemID.gold_giant_sword_ice_untimed, "gold ingot", ToolType.sword);


	


IDRegistry.genItemID( "diamond_giant_sword_ice_untimed" );
Item.createItem("diamond_giant_sword_ice_untimed", "§dDiamond Giant Sword \n Rarity: Craftable \n Lv: Untimed \n Skill: Ice Untimed \n Damage: +16", {
      name: "diamond_sword_giant", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("diamond", {durability: 2500, level: 4, efficiency: 4, damage: 16, enchantability: 30});
ToolAPI.setTool(ItemID.diamond_giant_sword_ice_untimed, "diamond", ToolType.sword);




IDRegistry.genItemID( "emerald_giant_sword_ice_untimed" );
Item.createItem("emerald_giant_sword_ice_untimed", "§dEmeral Giant Sword \n Rarity: Craftable \n Lv: Untimed \n Skill: Ice Untimed \n Damage: +19", {
    name: "emerald_sword_giant", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("emerald", {durability: 2600, level: 4, efficiency: 4, damage: 19, enchantability: 30});
ToolAPI.setTool(ItemID.emerald_giant_sword_ice_untimed, "emerald", ToolType.sword);


	


IDRegistry.genItemID( "ender_giant_sword_ice_untimed" );
Item.createItem("ender_giant_sword_ice_untimed", "§dEnder Giant Sword \n Rarity: Craftable \n Lv: Untimed \n Skill: Ice Untimed \n Damage: +22", {
    name: "ender_sword_giant", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("diamond", {durability: 2800, level: 4, efficiency: 4, damage: 22, enchantability: 30});
ToolAPI.setTool(ItemID.ender_giant_sword_ice_untimed, "diamond", ToolType.sword);





IDRegistry.genItemID( "livingmetal_giant_sword_ice_untimed" );
Item.createItem("livingmetal_giant_sword_ice_untimed", " §dLiving Metal Giant Sword \n Rarity: Craftable \n Lv: Untimed \n Skill: Ice Untimed \n Damage: +25", {
     name: "livingmetal_sword_giant", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("livingmetal", {durability: 3200, level: 4, efficiency: 4, damage: 25, enchantability: 30});
ToolAPI.setTool(ItemID.livingmetal_giant_sword_ice_untimed, "livingmetal", ToolType.sword);




	
	
	
	
	IDRegistry.genItemID( "quartz_giant_sword_ice_untimed" );
Item.createItem("quartz_giant_sword_ice_untimed", "§dQuartz Giant Sword \n Rarity: Craftable \n Lv: Untimed \nSkill: Ice Untimed \n Damage: +11", {
     name: "quartz_giant_sword", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("bone", {durability: 500, level: 4, efficiency: 4, damage: 11, enchantability: 30});
ToolAPI.setTool(ItemID.quartz_giant_sword_ice_untimed, "bone", ToolType.sword);
	
	
	
	
	
	
	
	IDRegistry.genItemID( "netherrack_giant_sword_ice_untimed" );
Item.createItem("netherrack_giant_sword_ice_untimed", "§dNetherrack Giant Sword \n Rarity: Craftable \n Lv: Untimed \n Skill: Ice Untimed \n Damage: +11", {
     name: "netherrack_giant_sword", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("bone", {durability: 700, level: 4, efficiency: 4, damage: 11, enchantability: 30});
ToolAPI.setTool(ItemID.netherrack_giant_sword_ice_untimed, "bone", ToolType.sword);
	
	
	
	
	
	
	IDRegistry.genItemID( "bone_giant_sword_ice_untimed" );
Item.createItem("bone_giant_sword_ice_untimed", "§dBone Giant Sword \n Rarity: Craftable \n Lv: Untimed \n Skill: Ice Untimed \n Damage: +18", {
    name: "bone_giant_sword", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("bone", {durability: 790, level: 4, efficiency: 4, damage: 18, enchantability: 30});
ToolAPI.setTool(ItemID.bone_giant_sword_ice_untimed, "bone", ToolType.sword);
	
	
	
	
	

	IDRegistry.genItemID( "obsidian_giant_sword_ice_untimed" );
Item.createItem("obsidian_giant_sword_ice_untimed", "§dObsidian Giant Sword \n Rarity: Craftable \n Lv: Untimed \n Skill: Ice Untimed \n Damage: +20", {
     name: "obsidian_giant_sword", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("bone", {durability: 2000, level: 4, efficiency: 4, damage: 20, enchantability: 30});
ToolAPI.setTool(ItemID.obsidian_giant_sword_ice_untimed, "bone", ToolType.sword);


	
	
IDRegistry.genItemID( "netherite_giant_sword_ice_untimed" );
Item.createItem("netherite_giant_sword_ice_untimed", "§dNetherite Giant Sword \n Rarity: Craftable \n Lv: Untimed \n Skill: Ice Untimed \n Damage: +23", {
     name: "netherite_giant_sword", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("bone", {durability: 2000, level: 4, efficiency: 4, damage: 23, enchantability: 30});
ToolAPI.setTool(ItemID.netherite_giant_sword_ice_untimed, "bone", ToolType.sword);

IDRegistry.genItemID( "wither_giant_sword_ice_untimed" );
Item.createItem("wither_giant_sword_ice_untimed", "§dWither Giant Sword \n Rarity: Craftable \n Lv: Untimed \n Skill: Ice Untimed \n Damage: +49", {
     name: "wither_giant_sword", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("bone", {durability: 790, level: 4, efficiency: 4, damage: 49, enchantability: 30});
ToolAPI.setTool(ItemID.wither_giant_sword_ice_untimed, "bone", ToolType.sword);
	
	
	
	
	
	
	
	
	
	
	IDRegistry.genItemID( "dragon_giant_sword_ice_untimed" );
Item.createItem("dragon_giant_sword_ice_untimed", "§dDragon Giant Sword \n Rarity: Craftable \n Lv: Untimed \n Skill: Ice Untimed \n Damage: +75", {
    name: "dragon_giant_sword", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("bone", {durability: 3000, level: 4, efficiency: 4, damage: 75, enchantability: 30});
ToolAPI.setTool(ItemID.dragon_giant_sword_ice_untimed, "bone", ToolType.sword);
	
	 // giấy bạc
	
	
	 Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.wooden_giant_sword_ice_untimed){ 
Entity.addEffect(victim, Native.PotionEffect.movementSlowdown, 100, 100, true, true); 
}
});




Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.stone_giant_sword_ice_untimed){ 
Entity.addEffect(victim, Native.PotionEffect.movementSlowdown, 100, 100, true, true); 
}
});
	
	
	
	
	Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.iron_giant_sword_ice_untimed){ 
Entity.addEffect(victim, Native.PotionEffect.movementSlowdown, 100, 100, true, true); 
}
});
	
	
	 Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.gold_giant_sword_ice_untimed){ 
Entity.addEffect(victim, Native.PotionEffect.movementSlowdown, 100, 100, true, true); 
}
});
	
	
	
	 Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.diamond_giant_sword_ice_untimed){ 
Entity.addEffect(victim, Native.PotionEffect.movementSlowdown, 100, 100, true, true); 
}
});
	
	
	
	 Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.emerald_giant_sword_ice_untimed){ 
Entity.addEffect(victim, Native.PotionEffect.movementSlowdown, 100, 100, true, true); 
}
});
	
	
	
	 Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.ender_giant_sword_ice_untimed){ 
Entity.addEffect(victim, Native.PotionEffect.movementSlowdown, 100, 100, true, true); 
}
});
	
	
	
	 Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.livingmetal_giant_sword_ice_untimed){ 
Entity.addEffect(victim, Native.PotionEffect.movementSlowdown, 100, 100, true, true); 
}
});
	
	
	
	 Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.quartz_giant_sword_ice_untimed){ 
Entity.addEffect(victim, Native.PotionEffect.movementSlowdown, 100, 100, true, true); 
}
});
	
	
	
	 Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.netherrack_giant_sword_ice_untimed){ 
Entity.addEffect(victim, Native.PotionEffect.movementSlowdown, 100, 100, true, true); 
}
});
	
	
	
	 Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.bone_giant_sword_ice_untimed){ 
Entity.addEffect(victim, Native.PotionEffect.movementSlowdown, 100, 100, true, true); 
}
});
	
	
	
	 Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.obsidian_giant_sword_ice_untimed){ 
Entity.addEffect(victim, Native.PotionEffect.movementSlowdown, 100, 100, true, true); 
}
});
	

	 Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.netherite_giant_sword_ice_untimed){ 
Entity.addEffect(victim, Native.PotionEffect.movementSlowdown, 100, 100, true, true); 
}
});
	
	
	
	 Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.wither_giant_sword_ice_untimed){ 
Entity.addEffect(victim, Native.PotionEffect.movementSlowdown, 100, 100, true, true); 
}
});
	
	
	
	 Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.dragon_giant_sword_ice_untimed){ 
Entity.addEffect(victim, Native.PotionEffect.movementSlowdown, 100, 100, true, true); 
}
});
	





// file: Hexxit Core/Tools Mode Skill Lv/Fire Skill/Tools Legend Fire.js

IDRegistry.genItemID( "wooden_giant_sword_fire_legend" );
Item.createItem("wooden_giant_sword_fire_legend", "§6Wooden Giant Sword \n Rarity: Craftable \n Lv: Legend \n Skill: Fire Legend \n Damage: +8", {
         name: "wooden_sword_giant", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("oak planks", {durability: 340, level: 1, efficiency: 4, damage: 8, enchantability: 30});
ToolAPI.setTool(ItemID.wooden_giant_sword_fire_legend, "oak planks", ToolType.sword);





IDRegistry.genItemID( "cobblestone_giant_sword_fire_legend" );
Item.createItem("cobblestone_giant_sword_fire_legend", "§6Stone Giant Sword \n Rarity: Craftable \n Lv: Legend \n Skill: Fire Legend \n Damage: +9", {
    name: "stone_sword_giant", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("stone", {durability: 700, level: 2, efficiency: 4, damage: 9, enchantability: 30});
ToolAPI.setTool(ItemID.cobblestone_giant_sword_fire_legend, "stone", ToolType.sword);


	


IDRegistry.genItemID( "iron_giant_sword_fire_legend" );
Item.createItem("iron_giant_sword_fire_legend", "§6Iron Giant Sword  \n Rarity: Craftable \n Lv: Legend \n Skill: Fire Legend \n Damage: +10", {
name: "iron_sword_giant", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("iron ingot", {durability: 970, level: 3, efficiency: 4, damage: 10, enchantability: 30});
ToolAPI.setTool(ItemID.iron_giant_sword_fire_legend, "iron ingot", ToolType.sword);




IDRegistry.genItemID( "gold_giant_sword_fire_legend" );
Item.createItem("gold_giant_sword_fire_legend", "§6Gold Giant Sword \n Rarity: Craftable \n Lv: Legend \n Skill: Fire Legend \n Damage: +8", {
name: "gold_sword_giant", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("gold ingot", {durability: 340, level: 3, efficiency: 4, damage: 8, enchantability: 30});
ToolAPI.setTool(ItemID.gold_giant_sword_fire_legend, "gold ingot", ToolType.sword);


	


IDRegistry.genItemID( "diamond_giant_sword_fire_legend" );
Item.createItem("diamond_giant_sword_fire_legend", "§6Diamond Giant Sword \n Rarity: Craftable \n Lv: Legend \n Skill: Fire Legend \n Damage: +14", {
      name: "diamond_sword_giant", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("diamond", {durability: 2500, level: 4, efficiency: 4, damage: 14, enchantability: 30});
ToolAPI.setTool(ItemID.diamond_giant_sword_fire_legend, "diamond", ToolType.sword);




IDRegistry.genItemID( "emerald_giant_sword_fire_legend" );
Item.createItem("emerald_giant_sword_fire_legend", "§6Emeral Giant Sword \n Rarity: Craftable \n Lv: Legend \n Skill: Fire Legend \n Damage: +17", {
    name: "emerald_sword_giant", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("emerald", {durability: 2600, level: 4, efficiency: 4, damage: 17, enchantability: 30});
ToolAPI.setTool(ItemID.emerald_giant_sword_fire_legend, "emerald", ToolType.sword);


	


IDRegistry.genItemID( "ender_giant_sword_fire_legend" );
Item.createItem("ender_giant_sword_fire_legend", "§6Ender Giant Sword \n Rarity: Craftable \n Lv: Legend \n Skill: Fire Legend \n Damage: +20", {
    name: "ender_sword_giant", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("diamond", {durability: 2800, level: 4, efficiency: 4, damage: 20, enchantability: 30});
ToolAPI.setTool(ItemID.ender_giant_sword_fire_legend, "diamond", ToolType.sword);





IDRegistry.genItemID( "livingmetal_giant_sword_fire_legend" );
Item.createItem("livingmetal_giant_sword_fire_legend", " §6Living Metal Giant Sword \n Rarity: Craftable \n Lv: Legend \n Skill: Fire Legend \n Damage: +23", {
     name: "livingmetal_sword_giant", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("livingmetal", {durability: 3200, level: 4, efficiency: 4, damage: 23, enchantability: 30});
ToolAPI.setTool(ItemID.livingmetal_giant_sword_fire_legend, "livingmetal", ToolType.sword);




	
	
	
	
	IDRegistry.genItemID( "quartz_giant_sword_fire_legend" );
Item.createItem("quartz_giant_sword_fire_legend", "§6Quartz Giant Sword \n Rarity: Craftable \n Lv: Legend \nSkill: Fire Legend \n Damage: +9", {
     name: "quartz_giant_sword", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("bone", {durability: 500, level: 4, efficiency: 4, damage: 9, enchantability: 30});
ToolAPI.setTool(ItemID.quartz_giant_sword_fire_legend, "bone", ToolType.sword);
	
	
	
	
	
	
	
	IDRegistry.genItemID( "netherrack_giant_sword_fire_legend" );
Item.createItem("netherrack_giant_sword_fire_legend", "§6Netherrack Giant Sword \n Rarity: Craftable \n Lv: Legend \n Skill: Fire Legend \n Damage: +9", {
     name: "netherrack_giant_sword", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("bone", {durability: 700, level: 4, efficiency: 4, damage: 9, enchantability: 30});
ToolAPI.setTool(ItemID.netherrack_giant_sword_fire_legend, "bone", ToolType.sword);
	
	
	
	
	
	
	IDRegistry.genItemID( "bone_giant_sword_fire_legend" );
Item.createItem("bone_giant_sword_fire_legend", "§6Bone Giant Sword \n Rarity: Craftable \n Lv: Legend \n Skill: Fire Legend \n Damage: +16", {
    name: "bone_giant_sword", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("bone", {durability: 790, level: 4, efficiency: 4, damage: 16, enchantability: 30});
ToolAPI.setTool(ItemID.bone_giant_sword_fire_legend, "bone", ToolType.sword);
	
	
	
	
	

	IDRegistry.genItemID( "obsidian_giant_sword_fire_legend" );
Item.createItem("obsidian_giant_sword_fire_legend", "§6Obsidian Giant Sword \n Rarity: Craftable \n Lv: Legend \n Skill: Fire Legend \n Damage: +18", {
     name: "obsidian_giant_sword", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("bone", {durability: 2000, level: 4, efficiency: 4, damage: 18, enchantability: 30});
ToolAPI.setTool(ItemID.obsidian_giant_sword_fire_legend, "bone", ToolType.sword);


	
	
IDRegistry.genItemID( "netherite_giant_sword_fire_legend" );
Item.createItem("netherite_giant_sword_fire_legend", "§6Netherite Giant Sword \n Rarity: Craftable \n Lv: Legend \n Skill: Fire Legend \n Damage: +21", {
     name: "netherite_giant_sword", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("bone", {durability: 2000, level: 4, efficiency: 4, damage: 21, enchantability: 30});
ToolAPI.setTool(ItemID.netherite_giant_sword_fire_legend, "bone", ToolType.sword);

IDRegistry.genItemID( "wither_giant_sword_fire_legend" );
Item.createItem("wither_giant_sword_fire_legend", "§6Wither Giant Sword \n Rarity: Craftable \n Lv: Legend \n Skill: Fire Legend \n Damage: +46", {
     name: "wither_giant_sword", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("bone", {durability: 790, level: 4, efficiency: 4, damage: 46, enchantability: 30});
ToolAPI.setTool(ItemID.wither_giant_sword_fire_legend, "bone", ToolType.sword);
	
	
	
	
	
	
	
	
	
	
	IDRegistry.genItemID( "dragon_giant_sword_fire_legend" );
Item.createItem("dragon_giant_sword_fire_legend", "§6Dragon Giant Sword \n Rarity: Craftable \n Lv: Legend \n Skill: Fire Legend \n Damage: +73", {
    name: "dragon_giant_sword", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("bone", {durability: 3000, level: 4, efficiency: 4, damage: 73, enchantability: 30});
ToolAPI.setTool(ItemID.dragon_giant_sword_fire_legend, "bone", ToolType.sword);
	
	 // giấy bạc
	
	
	 Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.wooden_giant_sword_fire_legend){ 
Entity.setFire(victim, 70, true);
}
});




Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.cobblestone_giant_sword_fire_legend){ 
Entity.setFire(victim, 70, true);
}
});
	
	
	
	
	Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.iron_giant_sword_fire_legend){ 
Entity.setFire(victim, 70, true);
}
});
	
	
	 Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.gold_giant_sword_fire_legend){ 
Entity.setFire(victim, 70, true);
}
});
	
	
	
	 Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.diamond_giant_sword_fire_legend){ 
Entity.setFire(victim, 70, true);
}
});
	
	
	
	 Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.emerald_giant_sword_fire_legend){ 
Entity.setFire(victim, 70, true);
}
});
	
	
	
	 Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.ender_giant_sword_fire_legend){ 
Entity.setFire(victim, 70, true);
}
});
	
	
	
	 Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.livingmetal_giant_sword_fire_legend){ 
Entity.setFire(victim, 70, true);
}
});
	
	
	
	 Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.quartz_giant_sword_fire_legend){ 
Entity.setFire(victim, 70, true);
}
});
	
	
	
	 Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.netherrack_giant_sword_fire_legend){ 
Entity.setFire(victim, 70, true);
}
});
	
	
	
	 Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.bone_giant_sword_fire_legend){ 
Entity.setFire(victim, 70, true);
}
});
	
	
	
	 Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.obsidian_giant_sword_fire_legend){ 
Entity.setFire(victim, 70, true);
}
});
	

	 Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.netherite_giant_sword_fire_legend){ 
Entity.setFire(victim, 70, true);
}
});
	
	
	
	 Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.wither_giant_sword_fire_legend){ 
Entity.setFire(victim, 70, true);
}
});
	
	
	
	 Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.dragon_giant_sword_fire_legend){ 
Entity.setFire(victim, 70, true);
}
});
	
	
	
	
	
	
	
	




// file: Hexxit Core/Tools Mode Skill Lv/Fire Skill/Tools Untimed Fire.js

IDRegistry.genItemID( "wooden_giant_sword_fire_untimed" );
Item.createItem("wooden_giant_sword_fire_untimed", "§dWooden Giant Sword \n Rarity: Craftable \n Lv: Untimed \n Skill: Fire Untimed-FireBall \n Damage: +10", {
         name: "wooden_sword_giant", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("oak planks", {durability: 340, level: 1, efficiency: 4, damage: 10, enchantability: 30});
ToolAPI.setTool(ItemID.wooden_giant_sword_fire_untimed, "oak planks", ToolType.sword);





IDRegistry.genItemID( "stone_giant_sword_fire_untimed" );
Item.createItem("stone_giant_sword_fire_untimed", "§dStone Giant Sword \n Rarity: Craftable \n Lv: Untimed \n Skill: Fire Untimed-FireBall \n Damage: +11", {
    name: "stone_sword_giant", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("stone", {durability: 700, level: 2, efficiency: 4, damage: 11, enchantability: 30});
ToolAPI.setTool(ItemID.stone_giant_sword_fire_untimed, "stone", ToolType.sword);


	


IDRegistry.genItemID( "iron_giant_sword_fire_untimed" );
Item.createItem("iron_giant_sword_fire_untimed", "§dIron Giant Sword  \n Rarity: Craftable \n Lv: Untimed \n Skill: Fire Untimed-FireBall \n Damage: +12", {
name: "iron_sword_giant", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("iron ingot", {durability: 970, level: 3, efficiency: 4, damage: 12, enchantability: 30});
ToolAPI.setTool(ItemID.iron_giant_sword_fire_untimed, "iron ingot", ToolType.sword);




IDRegistry.genItemID( "gold_giant_sword_fire_untimed" );
Item.createItem("gold_giant_sword_fire_untimed", "§dGold Giant Sword \n Rarity: Craftable \n Lv: Untimed \n Skill: Fire Untimed-FireBall \n Damage: +10", {
name: "gold_sword_giant", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("gold ingot", {durability: 340, level: 3, efficiency: 4, damage: 10, enchantability: 30});
ToolAPI.setTool(ItemID.gold_giant_sword_fire_untimed, "gold ingot", ToolType.sword);


	


IDRegistry.genItemID( "diamond_giant_sword_fire_untimed" );
Item.createItem("diamond_giant_sword_fire_untimed", "§dDiamond Giant Sword \n Rarity: Craftable \n Lv: Untimed \n Skill: Fire Untimed-FireBall \n Damage: +16", {
      name: "diamond_sword_giant", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("diamond", {durability: 2500, level: 4, efficiency: 4, damage: 16, enchantability: 30});
ToolAPI.setTool(ItemID.diamond_giant_sword_fire_untimed, "diamond", ToolType.sword);




IDRegistry.genItemID( "emerald_giant_sword_fire_untimed" );
Item.createItem("emerald_giant_sword_fire_untimed", "§dEmeral Giant Sword \n Rarity: Craftable \n Lv: Untimed \n Skill: Fire Untimed-FireBall \n Damage: +19", {
    name: "emerald_sword_giant", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("emerald", {durability: 2600, level: 4, efficiency: 4, damage: 19, enchantability: 30});
ToolAPI.setTool(ItemID.emerald_giant_sword_fire_untimed, "emerald", ToolType.sword);


	


IDRegistry.genItemID( "ender_giant_sword_fire_untimed" );
Item.createItem("ender_giant_sword_fire_untimed", "§dEnder Giant Sword \n Rarity: Craftable \n Lv: Untimed \n Skill: Fire Untimed-FireBall \n Damage: +22", {
    name: "ender_sword_giant", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("diamond", {durability: 2800, level: 4, efficiency: 4, damage: 22, enchantability: 30});
ToolAPI.setTool(ItemID.ender_giant_sword_fire_untimed, "diamond", ToolType.sword);





IDRegistry.genItemID( "livingmetal_giant_sword_fire_untimed" );
Item.createItem("livingmetal_giant_sword_fire_untimed", " §dLiving Metal Giant Sword \n Rarity: Craftable \n Lv: Untimed \n Skill: Fire Untimed-FireBall \n Damage: +25", {
     name: "livingmetal_sword_giant", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("livingmetal", {durability: 3200, level: 4, efficiency: 4, damage: 25, enchantability: 30});
ToolAPI.setTool(ItemID.livingmetal_giant_sword_fire_untimed, "livingmetal", ToolType.sword);




	
	
	
	
	IDRegistry.genItemID( "quartz_giant_sword_fire_untimed" );
Item.createItem("quartz_giant_sword_fire_untimed", "§dQuartz Giant Sword \n Rarity: Craftable \n Lv: Untimed \nSkill: Fire Untimed-FireBall \n Damage: +11", {
     name: "quartz_giant_sword", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("bone", {durability: 500, level: 4, efficiency: 4, damage: 11, enchantability: 30});
ToolAPI.setTool(ItemID.quartz_giant_sword_fire_untimed, "bone", ToolType.sword);
	
	
	
	
	
	
	
	IDRegistry.genItemID( "netherrack_giant_sword_fire_untimed" );
Item.createItem("netherrack_giant_sword_fire_untimed", "§dNetherrack Giant Sword \n Rarity: Craftable \n Lv: Untimed \n Skill: Fire Untimed-FireBall \n Damage: +11", {
     name: "netherrack_giant_sword", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("bone", {durability: 700, level: 4, efficiency: 4, damage: 11, enchantability: 30});
ToolAPI.setTool(ItemID.netherrack_giant_sword_fire_untimed, "bone", ToolType.sword);
	
	
	
	
	
	
	IDRegistry.genItemID( "bone_giant_sword_fire_untimed" );
Item.createItem("bone_giant_sword_fire_untimed", "§dBone Giant Sword \n Rarity: Craftable \n Lv: Untimed \n Skill: Fire Untimed-FireBall \n Damage: +18", {
    name: "bone_giant_sword", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("bone", {durability: 790, level: 4, efficiency: 4, damage: 18, enchantability: 30});
ToolAPI.setTool(ItemID.bone_giant_sword_fire_untimed, "bone", ToolType.sword);
	
	
	
	
	

	IDRegistry.genItemID( "obsidian_giant_sword_fire_untimed" );
Item.createItem("obsidian_giant_sword_fire_untimed", "§dObsidian Giant Sword \n Rarity: Craftable \n Lv: Untimed \n Skill: Fire Untimed-FireBall \n Damage: +20", {
     name: "obsidian_giant_sword", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("bone", {durability: 2000, level: 4, efficiency: 4, damage: 20, enchantability: 30});
ToolAPI.setTool(ItemID.obsidian_giant_sword_fire_untimed, "bone", ToolType.sword);


	
	
IDRegistry.genItemID( "netherite_giant_sword_fire_untimed" );
Item.createItem("netherite_giant_sword_fire_untimed", "§dNetherite Giant Sword \n Rarity: Craftable \n Lv: Untimed \n Skill: Fire Untimed-FireBall \n Damage: +23", {
     name: "netherite_giant_sword", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("bone", {durability: 2000, level: 4, efficiency: 4, damage: 23, enchantability: 30});
ToolAPI.setTool(ItemID.netherite_giant_sword_fire_untimed, "bone", ToolType.sword);

IDRegistry.genItemID( "wither_giant_sword_fire_untimed" );
Item.createItem("wither_giant_sword_fire_untimed", "§dWither Giant Sword \n Rarity: Craftable \n Lv: Untimed \n Skill: Fire Untimed-FireBall \n Damage: +49", {
     name: "wither_giant_sword", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("bone", {durability: 790, level: 4, efficiency: 4, damage: 49, enchantability: 30});
ToolAPI.setTool(ItemID.wither_giant_sword_fire_untimed, "bone", ToolType.sword);
	
	
	
	
	
	
	
	
	
	
	IDRegistry.genItemID( "dragon_giant_sword_fire_untimed" );
Item.createItem("dragon_giant_sword_fire_untimed", "§dDragon Giant Sword \n Rarity: Craftable \n Lv: Untimed \n Skill: Fire Untimed-FireBall \n Damage: +75", {
    name: "dragon_giant_sword", meta: 0
}, {isTech: true, stack: 1});

ToolAPI.addToolMaterial("bone", {durability: 3000, level: 4, efficiency: 4, damage: 75, enchantability: 30});
ToolAPI.setTool(ItemID.dragon_giant_sword_fire_untimed, "bone", ToolType.sword);
	
	 // giấy bạc
	
	
	 Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.wooden_giant_sword_fire_untimed){ 
Entity.setFire(victim, 180, true);
}
});




Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.stone_giant_sword_fire_untimed){ 
Entity.setFire(victim, 180, true);
}
});
	
	
	
	
	Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.iron_giant_sword_fire_untimed){ 
Entity.setFire(victim, 180, true);
}
});
	
	
	 Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.gold_giant_sword_fire_untimed){ 
Entity.setFire(victim, 180, true);
}
});
	
	
	
	 Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.diamond_giant_sword_fire_untimed){ 
Entity.setFire(victim, 180, true);
}
});
	
	
	
	 Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.emerald_giant_sword_fire_untimed){ 
Entity.setFire(victim, 180, true);
}
});
	
	
	
	 Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.ender_giant_sword_fire_untimed){ 
Entity.setFire(victim, 180, true);
}
});
	
	
	
	 Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.livingmetal_giant_sword_fire_untimed){ 
Entity.setFire(victim, 180, true);
}
});
	
	
	
	 Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.quartz_giant_sword_fire_untimed){ 
Entity.setFire(victim, 180, true);
}
});
	
	
	
	 Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.netherrack_giant_sword_fire_untimed){ 
Entity.setFire(victim, 180, true);
}
});
	
	
	
	 Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.bone_giant_sword_fire_untimed){ 
Entity.setFire(victim, 180, true);
}
});
	
	
	
	 Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.obsidian_giant_sword_fire_untimed){ 
Entity.setFire(victim, 180, true);
}
});
	

	 Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.netherite_giant_sword_fire_untimed){ 
Entity.setFire(victim, 180, true);
}
});
	
	
	
	 Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.wither_giant_sword_fire_untimed){ 
Entity.setFire(victim, 180, true);
}
});
	
	
	
	 Callback.addCallback("PlayerAttack", function (player, victim) { 
let item = Player.getCarriedItem();
if (item.id == ItemID.dragon_giant_sword_fire_untimed){ 
Entity.setFire(victim, 180, true);
}
});
	//fireball
	 Item.registerNoTargetUseFunction("wooden_giant_sword_fire_untimed", function(item){
if(item.id == ItemID.wooden_giant_sword_fire_untimed){
 let 子弹 = Player.getPosition();
let 力量 = Entity.getLookVector(Player.get());
//发射的实体
var 子弹1 = Entity.spawn(子弹.x,子弹.y,子弹.z,Native.EntityType.FIREBALL);
Entity.setVelocity(子弹1,8*力量.x,8*力量.y,8*力量.z);
}});
	
	 Item.registerNoTargetUseFunction("stone_giant_sword_fire_untimed", function(item){
if(item.id == ItemID.stone_giant_sword_fire_untimed){
 let 子弹 = Player.getPosition();
let 力量 = Entity.getLookVector(Player.get());
//发射的实体
var 子弹1 = Entity.spawn(子弹.x,子弹.y,子弹.z,Native.EntityType.FIREBALL);
Entity.setVelocity(子弹1,8*力量.x,8*力量.y,8*力量.z);
}});
	 Item.registerNoTargetUseFunction("iron_giant_sword_fire_untimed", function(item){
if(item.id == ItemID.iron_giant_sword_fire_untimed){
 let 子弹 = Player.getPosition();
let 力量 = Entity.getLookVector(Player.get());
//发射的实体
var 子弹1 = Entity.spawn(子弹.x,子弹.y,子弹.z,Native.EntityType.FIREBALL);
Entity.setVelocity(子弹1,8*力量.x,8*力量.y,8*力量.z);
}});
	 Item.registerNoTargetUseFunction("gold_giant_sword_fire_untimed", function(item){
if(item.id == ItemID.gold_giant_sword_fire_untimed){
 let 子弹 = Player.getPosition();
let 力量 = Entity.getLookVector(Player.get());
//发射的实体
var 子弹1 = Entity.spawn(子弹.x,子弹.y,子弹.z,Native.EntityType.FIREBALL);
Entity.setVelocity(子弹1,8*力量.x,8*力量.y,8*力量.z);
}});
	 Item.registerNoTargetUseFunction("diamond_giant_sword_fire_untimed", function(item){
if(item.id == ItemID.diamond_giant_sword_fire_untimed){
 let 子弹 = Player.getPosition();
let 力量 = Entity.getLookVector(Player.get());
//发射的实体
var 子弹1 = Entity.spawn(子弹.x,子弹.y,子弹.z,Native.EntityType.FIREBALL);
Entity.setVelocity(子弹1,8*力量.x,8*力量.y,8*力量.z);
}});
	 Item.registerNoTargetUseFunction("emerald_giant_sword_fire_untimed", function(item){
if(item.id == ItemID.emerald_giant_sword_fire_untimed){
 let 子弹 = Player.getPosition();
let 力量 = Entity.getLookVector(Player.get());
//发射的实体
var 子弹1 = Entity.spawn(子弹.x,子弹.y,子弹.z,Native.EntityType.FIREBALL);
Entity.setVelocity(子弹1,8*力量.x,8*力量.y,8*力量.z);
}});
	 Item.registerNoTargetUseFunction("ender_giant_sword_fire_untimed", function(item){
if(item.id == ItemID.ender_giant_sword_fire_untimed){
 let 子弹 = Player.getPosition();
let 力量 = Entity.getLookVector(Player.get());
//发射的实体
var 子弹1 = Entity.spawn(子弹.x,子弹.y,子弹.z,Native.EntityType.FIREBALL);
Entity.setVelocity(子弹1,8*力量.x,8*力量.y,8*力量.z);
}});
	 Item.registerNoTargetUseFunction("livingmetal_giant_sword_fire_untimed", function(item){
if(item.id == ItemID.livingmetal_giant_sword_fire_untimed){
 let 子弹 = Player.getPosition();
let 力量 = Entity.getLookVector(Player.get());
//发射的实体
var 子弹1 = Entity.spawn(子弹.x,子弹.y,子弹.z,Native.EntityType.FIREBALL);
Entity.setVelocity(子弹1,8*力量.x,8*力量.y,8*力量.z);
}});
	 Item.registerNoTargetUseFunction("quartz_giant_sword_fire_untimed", function(item){
if(item.id == ItemID.quartz_giant_sword_fire_untimed){
 let 子弹 = Player.getPosition();
let 力量 = Entity.getLookVector(Player.get());
//发射的实体
var 子弹1 = Entity.spawn(子弹.x,子弹.y,子弹.z,Native.EntityType.FIREBALL);
Entity.setVelocity(子弹1,8*力量.x,8*力量.y,8*力量.z);
}});
	 Item.registerNoTargetUseFunction("netherrack_giant_sword_fire_untimed", function(item){
if(item.id == ItemID.netherrack_giant_sword_fire_untimed){
 let 子弹 = Player.getPosition();
let 力量 = Entity.getLookVector(Player.get());
//发射的实体
var 子弹1 = Entity.spawn(子弹.x,子弹.y,子弹.z,Native.EntityType.FIREBALL);
Entity.setVelocity(子弹1,8*力量.x,8*力量.y,8*力量.z);
}});
	 Item.registerNoTargetUseFunction("bone_giant_sword_fire_untimed", function(item){
if(item.id == ItemID.bone_giant_sword_fire_untimed){
 let 子弹 = Player.getPosition();
let 力量 = Entity.getLookVector(Player.get());
//发射的实体
var 子弹1 = Entity.spawn(子弹.x,子弹.y,子弹.z,Native.EntityType.FIREBALL);
Entity.setVelocity(子弹1,8*力量.x,8*力量.y,8*力量.z);
}});
	 Item.registerNoTargetUseFunction("obsidian_giant_sword_fire_untimed", function(item){
if(item.id == ItemID.obsidian_giant_sword_fire_untimed){
 let 子弹 = Player.getPosition();
let 力量 = Entity.getLookVector(Player.get());
//发射的实体
var 子弹1 = Entity.spawn(子弹.x,子弹.y,子弹.z,Native.EntityType.FIREBALL);
Entity.setVelocity(子弹1,8*力量.x,8*力量.y,8*力量.z);
}});
	 Item.registerNoTargetUseFunction("netherite_giant_sword_fire_untimed", function(item){
if(item.id == ItemID.netherite_giant_sword_fire_untimed){
 let 子弹 = Player.getPosition();
let 力量 = Entity.getLookVector(Player.get());
//发射的实体
var 子弹1 = Entity.spawn(子弹.x,子弹.y,子弹.z,Native.EntityType.FIREBALL);
Entity.setVelocity(子弹1,8*力量.x,8*力量.y,8*力量.z);
}});
	 Item.registerNoTargetUseFunction("wither_giant_sword_fire_untimed", function(item){
if(item.id == ItemID.wither_giant_sword_fire_untimed){
 let 子弹 = Player.getPosition();
let 力量 = Entity.getLookVector(Player.get());
//发射的实体
var 子弹1 = Entity.spawn(子弹.x,子弹.y,子弹.z,Native.EntityType.FIREBALL);
Entity.setVelocity(子弹1,8*力量.x,8*力量.y,8*力量.z);
}});
	 Item.registerNoTargetUseFunction("dragon_giant_sword_fire_untimed", function(item){
if(item.id == ItemID.dragon_giant_sword_fire_untimed){
 let 子弹 = Player.getPosition();
let 力量 = Entity.getLookVector(Player.get());
//发射的实体
var 子弹1 = Entity.spawn(子弹.x,子弹.y,子弹.z,Native.EntityType.FIREBALL);
Entity.setVelocity(子弹1,8*力量.x,8*力量.y,8*力量.z);
}});
	
	
	
	
	
	
	

 




